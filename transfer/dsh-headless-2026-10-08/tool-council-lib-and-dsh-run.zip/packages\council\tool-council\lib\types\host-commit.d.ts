/** One repository a writer may submit to. */
export interface WriterRepo {
    /** Absolute path of the main checkout; worktrees are added from it. */
    readonly path: string;
    /** Branch on origin the work fast-forwards. */
    readonly target: string;
    /** Commands run in the fresh worktree before any model file is written. */
    readonly setup: readonly (readonly string[])[];
    /** Commands run after the files are written; every one must exit 0. */
    readonly checks: readonly (readonly string[])[];
}
/** Host configuration shared by every writer repository. */
export interface WriterSettings {
    /** Parent of every writer worktree. */
    readonly worktreeRoot: string;
    /** Absolute path of queue-build.mjs. */
    readonly queueScript: string;
    /** Queue file override; queue-build picks its default otherwise. */
    readonly queuePath?: string | undefined;
    /** Per-command limit for git, setup and check commands. */
    readonly commandTimeoutMs: number;
}
/** One submission from an agent. */
export interface SubmitRequest {
    readonly repoKey: string;
    readonly repo: WriterRepo;
    /** JSON object mapping relative paths to full contents, as for stage_work. */
    readonly filesJson: string;
    readonly message: string;
    readonly model: string;
    readonly runId?: string | undefined;
    readonly signal?: AbortSignal | undefined;
}
/** Where a submission ended. */
export interface SubmitOutcome {
    readonly status: 'queued' | 'already-queued' | 'rejected' | 'check-failed' | 'queue-failed';
    readonly report: string;
    readonly worktree?: string | undefined;
    readonly branch?: string | undefined;
    readonly head?: string | undefined;
}
/** Default parent for writer worktrees. */
export declare const DEFAULT_WORKTREE_ROOT: string;
/**
 * Explain why a path may not be written by a model, if it may not.
 *
 * These cover code that runs without review: git internals, hooks, CI,
 * agent rule files, credentials, and manifests or lockfiles that execute at
 * install time and inside the pre-push hook.
 * @param path - repository-relative path with / separators.
 * @returns the reason, or undefined when the path is allowed.
 */
export declare function deniedPath(path: string): string | undefined;
/**
 * Name the first secret-shaped string in a text.
 * @param text - file contents.
 * @returns the kind of secret found, or undefined.
 */
export declare function findSecret(text: string): string | undefined;
/**
 * Validate the identity a commit trailer will carry.
 * @param model - model id as the agent reports it.
 * @returns the same id.
 */
export declare function checkModel(model: string): string;
/**
 * Validate a commit message.
 * @param message - message supplied by the agent.
 * @returns the trimmed message.
 */
export declare function checkMessage(message: string): string;
/**
 * Turn a model id into one git branch path segment.
 * @param model - validated model id.
 * @returns a lowercase slug.
 */
export declare function modelSlug(model: string): string;
/**
 * Make a run id that sorts by time and does not collide.
 * @param now - clock reading.
 * @returns id such as 20260918-094501-a1b2c3.
 */
export declare function newRunId(now?: Date): string;
/** Result of one command. */
export interface CommandResult {
    readonly code: number | null;
    readonly output: string;
    readonly error?: string | undefined;
}
/**
 * Run one argv without a shell.
 *
 * `node` means this Node binary. A Windows `.cmd` shim cannot be spawned
 * without a shell, so a check such as pnpm must be written as node plus the
 * package's .cjs entry.
 * @param argv - command and arguments.
 * @param cwd - working directory.
 * @param timeoutMs - hard limit; the whole process tree is killed after it.
 * @param signal - cancels the command.
 * @returns exit code and combined, tail-trimmed output.
 */
export declare function runCommand(argv: readonly string[], cwd: string, timeoutMs: number, signal?: AbortSignal): Promise<CommandResult>;
/**
 * Commit agent-written files on a fresh worktree and queue them for review.
 *
 * Input problems throw before anything touches disk. After the worktree
 * exists, every outcome is returned: failures before the commit remove the
 * worktree and branch, and a queue failure keeps the commit for a retry.
 * @param settings - host writer settings.
 * @param request - one submission.
 * @returns where the submission ended.
 */
export declare function submitWork(settings: WriterSettings, request: SubmitRequest): Promise<SubmitOutcome>;
//# sourceMappingURL=host-commit.d.ts.map