/**
 * The swarm's bridge to the weight router.
 *
 * `assignWorkers` still decides who runs each unit, because its rules — named
 * provider, earned specialist, cost tier, least loaded — are what every saved
 * run and test already relies on. The router is wired in two places around it:
 *
 *  1. Before assignment, as the hard filter on seat state. A seat the caller
 *     reports as down or out of quota is switched off for this run only, and
 *     the rejection says why.
 *  2. After assignment, in shadow. Each unit is resolved by the router against
 *     the same field, and its pick, factors and rejections are kept beside the
 *     choice actually made. That trace is what makes a route explainable after
 *     the run, and it is the evidence for letting the router decide later.
 *
 * Throughput has never been measured for a seat, so every candidate carries
 * the same placeholder figure and speed cannot separate them. A guessed number
 * would silently decide routing, which the registry exists to prevent.
 */
import type { SubTask } from './decompose.ts';
import type { ModelPrice } from './estimate.ts';
import type { AssignmentPlan, EarnedPreference, Worker } from './roster.ts';
import type { SeatConfig } from './seats.ts';
import type { Candidate, Rejection, RoleRequirement, RoutingPolicy, ScoreFactors } from './router/index.ts';
/** What the caller knows about a seat right now. Absent fields mean "no evidence". */
export interface SeatState {
    readonly available?: boolean | undefined;
    readonly unavailableReason?: string | undefined;
    /** Remaining quota for this window, 0 to 1. */
    readonly quotaHeadroom?: number | undefined;
}
/** One unit: the seat that runs it, what the router would pick, and why. */
export interface UnitRoute {
    readonly taskId: string;
    /** Seat `assignWorkers` chose; undefined when nobody could take it. */
    readonly chosen?: string | undefined;
    /** Seat the router would pick under the run's policy; undefined when it could fill nothing. */
    readonly routerPick?: string | undefined;
    readonly policy: RoutingPolicy;
    /** Factors of the chosen seat, when the router also found it eligible. */
    readonly factors?: ScoreFactors | undefined;
    readonly score?: number | undefined;
    readonly rejections: readonly Rejection[];
}
/** The plan with the routing trace alongside it. */
export interface RoutedPlan {
    readonly plan: AssignmentPlan;
    readonly routes: readonly UnitRoute[];
    /** Seats switched off for this run by the hard filter, with the reason. */
    readonly gated: readonly Rejection[];
}
/**
 * A worker as the router sees it.
 *
 * A kind the worker declares is offered at `high`; a worker that takes `any`
 * offers every other kind at `low`. So a unit's own specialist outranks a
 * generalist on capability, which is the preference `assignWorkers` has.
 * @param worker - the swarm roster entry to render as a routing candidate.
 * @param seat - the worker's matching seat configuration, for its model and locality.
 * @param state - the worker's live availability and quota headroom, when known.
 * @param pricing - OpenRouter price table, consulted for a metered worker's model.
 * @param queueDepth - units already assigned to this worker in the run being planned.
 * @returns the candidate the router's assignment and resolution functions score against.
 */
export declare function workerCandidate(worker: Worker, seat: SeatConfig | undefined, state: SeatState | undefined, pricing: ReadonlyMap<string, ModelPrice>, queueDepth?: number): Candidate;
/**
 * What a unit needs: its inferred kind at `low`, or nothing for `any`.
 * @param task - the decomposed unit of work to classify.
 * @returns the role requirement the router resolves candidates against.
 */
export declare function unitRole(task: SubTask): RoleRequirement;
/**
 * Switch off, for this run only, every enabled seat the caller reports as down
 * or out of quota.
 *
 * This is the reroute: a gated seat is simply not in the field, so whatever
 * would have gone to it goes to the next seat that can take it, and a unit
 * blocks only when no seat is left. Only availability and quota gate here.
 * Capability, budget and the rest are per unit, and `assignWorkers` already
 * applies the per-unit rules it owns.
 * @param roster - workers for this run.
 * @param seats - configured seats, for models and prices.
 * @param pricing - OpenRouter price table.
 * @param state - live seat state keyed by seat id.
 * @returns the roster with gated seats disabled, and why each was gated.
 */
export declare function gateRoster(roster: readonly Worker[], seats: readonly SeatConfig[], pricing: ReadonlyMap<string, ModelPrice>, state?: Readonly<Record<string, SeatState>>): {
    readonly roster: readonly Worker[];
    readonly gated: readonly Rejection[];
};
/**
 * Whether a seat draws on the Claude subscription the status line measures:
 * the plain `claude` CLI, not pointed at a proxy and not declared free.
 * @param seat - the seat configuration to classify.
 * @returns true when the seat is a CLI seat running the unproxied `claude` binary.
 */
export declare function isClaudeSubscriptionSeat(seat: SeatConfig): boolean;
/**
 * Seat state from the evidence a run can gather before it starts.
 * @param seats - configured seats.
 * @param problems - why a probed seat failed, keyed by seat id; a seat that passed is absent.
 * @param sessionPercent - Claude subscription session usage, as the status line last cached it.
 * @param exhausted - why the quota guard holds the Claude subscription account exhausted
 *   (`~/.claude/quota-guard/exhausted.json`), when it does; its seats then take no new work.
 * @returns state keyed by seat id; a seat with no evidence has no entry.
 */
export declare function liveSeatState(seats: readonly SeatConfig[], problems: ReadonlyMap<string, string>, sessionPercent?: number, exhausted?: string): Record<string, SeatState>;
/**
 * Gate the roster on seat state, assign, and resolve each unit in shadow.
 * @param tasks - the decomposition, after any UI pick has named a provider.
 * @param roster - workers for this run.
 * @param seats - configured seats, for models and prices.
 * @param pricing - OpenRouter price table.
 * @param earned - this run's earned preferences, passed to `assignWorkers` unchanged.
 * @param state - live seat state keyed by seat id.
 * @returns the plan `assignWorkers` made on the gated roster, and the trace.
 */
export declare function routeSwarm(tasks: readonly SubTask[], roster: readonly Worker[], seats: readonly SeatConfig[], pricing: ReadonlyMap<string, ModelPrice>, earned?: EarnedPreference, state?: Readonly<Record<string, SeatState>>): RoutedPlan;
/**
 * The routing section of a plan report.
 *
 * Empty when there is nothing to explain: no seat gated out and the router
 * agreeing on every unit. Otherwise one line per gated seat and per unit where
 * the router would have chosen differently.
 * @param routed - the routed plan's per-unit routes and gated-out seats.
 * @returns markdown lines for the report, or `[]` when there is nothing to explain.
 */
export declare function renderRouting(routed: Pick<RoutedPlan, 'routes' | 'gated'>): readonly string[];
//# sourceMappingURL=route-swarm.d.ts.map