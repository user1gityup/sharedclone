/**
 * OpenRouter key resolution.
 *
 * The harness deliberately never materialises its managed credential document
 * into `process.env`, so a plugin that only reads the environment finds nothing
 * for a key the user entered through the UI. This resolver therefore checks the
 * environment first, then the managed document, matching the harness's own
 * documented precedence.
 */
/** Environment variable the OpenRouter provider conventionally uses. */
export declare const DEFAULT_KEY_ENV = "OPENROUTER_API_KEY";
/** Inputs for key resolution, injectable so tests never touch a real home. */
export interface KeyLookup {
    /** Environment to consult first. */
    readonly env?: Readonly<Record<string, string | undefined>> | undefined;
    /** Variable name holding the key. */
    readonly variable?: string | undefined;
    /** Harness home; defaults to `$DSH_HOME` then `~/.dsh`. */
    readonly home?: string | undefined;
}
/**
 * Resolve the OpenRouter key from the environment, then the managed document.
 * @param lookup - environment, variable name, and home overrides.
 * @returns the key, or `undefined` when no source supplies one.
 */
export declare function resolveOpenRouterKey(lookup?: KeyLookup): string | undefined;
//# sourceMappingURL=credentials.d.ts.map