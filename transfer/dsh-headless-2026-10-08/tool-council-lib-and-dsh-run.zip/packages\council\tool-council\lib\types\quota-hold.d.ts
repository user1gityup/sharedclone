/**
 * Recognising "the quota is spent" and turning it into a time to come back.
 *
 * A seat that runs out of subscription quota is not a broken seat and its unit
 * is not a failed unit: the work is fine, the allowance is not. Treating that
 * as a failure loses the run — the graph, the approval that paid for it, and
 * the units already done — and the user then pays a second planning call to
 * get back to where they were. So exhaustion is detected here and reported as
 * a HOLD with a time, and the caller keeps its state untouched until then.
 *
 * The wording comes from two different places and neither is structured. The
 * Claude Code CLI prints prose at a person ("usage limit reached · resets 3pm
 * (America/Los_Angeles)"); OpenRouter answers HTTP 429, sometimes with a
 * `Retry-After` or an epoch in the body. Both are matched loosely on purpose:
 * a missed match costs a lost run, while a false positive only costs a wait
 * the user can end by pressing the button again.
 */
/** How long to wait when exhaustion is certain but the reset time is not. */
export declare const DEFAULT_HOLD_MS: number;
/** Never hold longer than this on a parsed time; a bad parse must not park a run for a day. */
export declare const MAX_HOLD_MS: number;
/** A run parked because an allowance ran out, and when it is worth trying again. */
export interface QuotaHold {
    /** The seat whose allowance ran out, when one error can be attributed. */
    readonly seat?: string | undefined;
    /** The wording that was matched, trimmed for the report. */
    readonly detail: string;
    /** Epoch ms to resume at. */
    readonly resumeAt: number;
    /** How the time was arrived at, so a report can say "resets 3pm" or "in 30 minutes". */
    readonly source: 'stated' | 'default';
}
/**
 * Decide whether one error means the allowance is spent.
 * @param error - the seat's error text.
 * @returns true when this is exhaustion rather than a fault.
 */
export declare function isQuotaExhausted(error: string): boolean;
/**
 * Turn seat failures into a hold, when they are about allowance.
 *
 * Only the first exhaustion is described: a wave of five units against one
 * spent subscription produces five identical errors, and a report listing all
 * five says nothing the first does not.
 * @param failures - seat id and error text for each failed call.
 * @param now - epoch ms, injectable for tests.
 * @returns the hold, or undefined when nothing here is about allowance.
 */
export declare function detectQuotaHold(failures: readonly {
    readonly seat?: string | undefined;
    readonly error: string;
}[], now?: number): QuotaHold | undefined;
/**
 * Whether a held run may go again.
 *
 * The reading is consulted only to release a hold EARLY: a fresh reading with
 * headroom means the window already rolled over, which is common when the hold
 * time was the 30-minute default rather than a stated one. It can never extend
 * a hold, because a stale cache file must not keep a run parked.
 * @param resumeAt - epoch ms the hold was set to end at.
 * @param now - epoch ms.
 * @param sessionPercent - latest known session usage, when a reading exists.
 * @returns true when the run should proceed.
 */
export declare function holdElapsed(resumeAt: number, now?: number, sessionPercent?: number): boolean;
/**
 * How long is left, worded for a report.
 * @param resumeAt - epoch ms the hold ends at.
 * @param now - epoch ms.
 * @returns e.g. "in 12 minutes", or "now".
 */
export declare function holdRemaining(resumeAt: number, now?: number): string;
//# sourceMappingURL=quota-hold.d.ts.map