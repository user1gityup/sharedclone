import type { SubTask } from './decompose.ts';
import type { Worker } from './roster.ts';
import type { SeatConfig } from './seats.ts';
import type { SwarmRunOptions, SwarmUnitResult } from './swarm.ts';
import type { ProposedWrite } from './writes.ts';
/**
 * Agentic seats (codex, claude) often edit the unit's files straight in the repo and reply
 * with a summary instead of `WRITE:` blocks, which used to stage zero files (RUN-018).
 * Harvest every unit target that changed on disk since the seat was asked.
 * @param files - the unit's target paths.
 * @param roots - the granted source roots the targets resolve against.
 * @param since - epoch ms taken just before the seat was asked.
 * @param base - the run's write root (the DSH process cwd); unit paths are relative to it,
 *   and it need not itself be one of the granted roots (RUN-20261006-021 harvested nothing).
 * @returns the changed targets as proposals, with their current contents.
 */
export declare function harvestDirectWrites(files: readonly string[], roots: readonly string[], since: number, base?: string): ProposedWrite[];
/**
 * Every run/unit/seat gets a separate root, including retries of the same unit.
 * @param root - the workspace root candidate directories are staged under.
 * @param run - the swarm run id.
 * @param unit - the unit (task) id.
 * @param seat - the proposing seat's id.
 * @returns the candidate directory path, with each segment percent-encoded (dots escaped) to keep it filesystem-safe.
 */
export declare function unitCandidateRoot(root: string, run: string, unit: string, seat: string): string;
/**
 * Contest a unit and require an explicit review before downstream work sees it.
 * @param options - the swarm run's shared options: seats, budgets, file roots, and profile.
 * @param task - the unit of work to contest.
 * @param done - units already finished, given to the proposer(s) as prior context.
 * @param workers - the roster, consulted to find seats that can propose or review this unit's kind.
 * @param assigned - the seat the router assigned; the sole proposer outside economy mode.
 * @returns the winning candidate's result, or a failure when no eligible reviewer or proposer exists.
 */
export declare function runUnitContest(options: SwarmRunOptions, task: SubTask, done: readonly SwarmUnitResult[], workers: readonly Worker[], assigned: SeatConfig): Promise<SwarmUnitResult>;
//# sourceMappingURL=swarm-contest.d.ts.map