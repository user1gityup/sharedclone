/**
 * Council orchestration: draft, review, tally.
 *
 * Both rounds fan out with `Promise.allSettled` semantics — every seat returns
 * a reply object rather than throwing — so one unreachable CLI or one rate-limited
 * model degrades that seat only. A council of two still produces a verdict.
 */
import type { ModelPrice, RunEstimate } from './estimate.ts';
import type { BudgetDecision, BudgetLimits } from './budget.ts';
import type { WalletDecision, WalletLimits } from './cheaperinference.ts';
import type { SeatId } from './colors.ts';
import type { SeatConfig, SeatReply } from './seats.ts';
import type { DraftAudit, FetchSeam } from './verify.ts';
import type { FileSeam } from './files.ts';
import type { SearchSeam } from './evidence.ts';
import type { FailureKind } from './errors.ts';
import type { RunRecord } from './runs.ts';
import type { PlanMerge } from './merge.ts';
import type { RoleRoute } from './route-council.ts';
/** One seat's review of the drafts, with its vote. */
export interface SeatReview {
    readonly seat: SeatId;
    /** Seat voted for, when it named one the council recognises. */
    readonly vote?: SeatId | undefined;
    /** Self-reported confidence in that vote, clamped to 0..1. */
    readonly confidence: number;
    /** Prose critique, verbatim from the seat. */
    readonly critique: string;
    /** Failure description; `undefined` on success. */
    readonly error?: string | undefined;
    /** Wall time spent on the call. */
    readonly ms: number;
}
/** Final tally across all reviews. */
export interface Verdict {
    /** Seat whose draft won, or `undefined` when nobody could be chosen. */
    readonly winner?: SeatId | undefined;
    /** Summed confidence per candidate. */
    readonly scores: ReadonlyMap<SeatId, number>;
    /** Raw vote counts per candidate. */
    readonly counts: ReadonlyMap<SeatId, number>;
    /** How the winner was decided. */
    readonly method: 'peer' | 'confidence' | 'majority' | 'sole-draft' | 'none';
    /** True when two candidates tied on confidence and count. */
    readonly tied: boolean;
    /** Confidence contributed by seats other than the candidate itself. */
    readonly peerScores: ReadonlyMap<SeatId, number>;
    /** Seats whose review failed, so their vote never counted. */
    readonly missingVoters: readonly SeatId[];
}
/** How far a run got. */
export type CouncilPhase = 'plan' | 'full';
/** A progress event emitted as the council works. */
export interface CouncilEvent {
    /** Which round produced it. */
    readonly round: 'plan' | 'draft' | 'review';
    /** Seat that settled. */
    readonly seat: SeatId;
    /** Seat display name. */
    readonly name: string;
    /** Wall time for that seat's call. */
    readonly ms: number;
    /** Provider-reported cost, when the transport reports one. */
    readonly costUsd?: number | undefined;
    /** Whether the call produced usable text. */
    readonly ok: boolean;
    /** Metered cost accumulated across the run so far. */
    readonly runningCostUsd: number;
}
/** Everything one council run produced. */
export interface CouncilResult {
    /** Which phase this run stopped at. */
    readonly phase: CouncilPhase;
    /**
     * Sources retrieved and shared with every seat before drafting. Empty when
     * no tool-less seat was active, or when retrieval failed — the report says
     * which, so an ungrounded answer is never mistaken for a grounded one.
     */
    readonly evidenceUrls?: readonly string[] | undefined;
    /** Why the spending gate stayed shut, when it did. */
    readonly approval?: {
        readonly allowed: boolean;
        readonly reason: string;
        readonly missing?: 'trigger' | 'verbal' | 'plan' | 'expired' | undefined;
    } | undefined;
    /**
     * Per-draft citation audit. Present whenever drafts ran, so the report can
     * show which answers were actually sourced and which only looked sourced.
     */
    readonly audits?: readonly DraftAudit[] | undefined;
    /**
     * Planner seats that failed before one succeeded. Reported rather than
     * swallowed: a plan written by the third choice is worth knowing about.
     */
    readonly planFailures?: readonly {
        readonly seat: SeatId;
        readonly error: string;
    }[] | undefined;
    /** Competing plans, when the council voted on the plan. */
    readonly planDrafts?: readonly SeatReply[] | undefined;
    /** Votes cast on those plans. */
    readonly planReviews?: readonly SeatReview[] | undefined;
    /** How the winning plan won. */
    readonly planVerdict?: Verdict | undefined;
    /** Attributed additions after the plan vote; the winner remains the author. */
    readonly planMerge?: PlanMerge | undefined;
    /** Why the Approve control could not be offered, when it could not. */
    readonly issueProblem?: string | undefined;
    /** The stored run this result belongs to, once one has been filed. */
    readonly runId?: string | undefined;
    /**
     * The shared evidence exactly as the drafts saw it, kept so an amendment
     * can put a recovered seat in front of the same sources rather than a fresh
     * search that would make its answer incomparable.
     */
    readonly evidenceBlock?: string | undefined;
    /** What an amendment recovered, when this result came from one. */
    readonly amended?: Amendment | undefined;
    /** The agreed approach, when a planning round ran or one was supplied. */
    readonly plan?: string | undefined;
    /** The seat that produced the plan, when the council generated it. */
    readonly planSeat?: SeatId | undefined;
    /** Planner choice beside the router's shadow pick, when a single planner ran. */
    readonly plannerRoute?: RoleRoute | undefined;
    /** The pre-flight budget decision, when a check was configured. */
    readonly budget?: BudgetDecision | undefined;
    /**
     * The pre-flight CheaperInference wallet decision, when a seat drawing on
     * that wallet was in the roster. Reported beside `budget` rather than
     * folded into it: the two providers hold separate money, so a refusal has
     * to name which wallet is empty.
     */
    readonly walletBudget?: WalletDecision | undefined;
    /** Actual OpenRouter spend for this run, measured as a balance delta. */
    readonly spentUsd?: number | undefined;
    /** Pre-flight estimate produced during the planning gate. */
    readonly estimate?: RunEstimate | undefined;
    readonly query: string;
    readonly seats: readonly SeatConfig[];
    readonly drafts: readonly SeatReply[];
    readonly reviews: readonly SeatReview[];
    readonly verdict: Verdict;
    /** The winning draft's text, empty when there is no winner. */
    readonly answer: string;
    readonly terminalState?: import('./runs.ts').RunTerminalState | undefined;
    /** Seats the pre-flight found unhealthy, classified. Absent when all passed. */
    readonly health?: readonly SeatHealth[] | undefined;
}
/** One seat that failed pre-flight, and what kind of failure it was. */
export interface SeatHealth {
    readonly seat: SeatId;
    readonly kind: FailureKind;
    readonly retryable: boolean;
    readonly error: string;
}
/** Options one run needs beyond the seats themselves. */
export interface RunOptions {
    readonly query: string;
    readonly seats: readonly SeatConfig[];
    readonly apiKey?: string | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly timeoutMs: number;
    readonly minDrafts?: number | undefined;
    readonly minReviews?: number | undefined;
    /** Run seats one at a time instead of in parallel. */
    readonly sequential?: boolean | undefined;
    /**
     * An already-approved plan. When present the planning round is skipped and
     * every draft is written against this plan.
     */
    readonly plan?: string | undefined;
    /** Seat id that writes the plan. Defaults to the cheapest configured seat. */
    readonly plannerSeat?: string | undefined;
    /**
     * How the plan is produced. `single` asks one cheap seat; `council` has every
     * seat propose a plan and the council vote on which to follow.
     *
     * The plan is the decision every later round inherits, so resting it on one
     * seat makes the cheapest seat the most influential one in the run.
     */
    readonly planMode?: 'single' | 'council' | undefined;
    /** Skip planning entirely and go straight to drafting. */
    readonly skipPlan?: boolean | undefined;
    /** Budget thresholds checked before any call is made. */
    readonly budget?: BudgetLimits | undefined;
    /**
     * CheaperInference wallet floor, checked before any call is made. Applied
     * only when a seat in the roster draws on that wallet; a prepaid wallet has
     * no monthly target because the balance already is the ceiling.
     */
    readonly walletBudget?: WalletLimits | undefined;
    /** OpenRouter price table, so the planner's shadow route can price metered seats. */
    readonly pricing?: ReadonlyMap<string, ModelPrice> | undefined;
    /**
     * Shared memory handed to each seat: CLI seats receive the file path, hosted
     * seats receive the text inline because they have no filesystem.
     */
    readonly memory?: {
        file?: string | undefined;
        text?: string | undefined;
    } | undefined;
    /** Estimate attached to a plan-phase result by the caller. */
    readonly estimate?: RunEstimate | undefined;
    /**
     * Called as each seat settles, so a long run reports progress instead of
     * going silent for minutes.
     */
    readonly onEvent?: ((event: CouncilEvent) => void) | undefined;
    /**
     * Stop after the planning round and return the plan for review. This is the
     * point of the phase: one cheap call decides direction before N expensive
     * ones commit to it.
     */
    readonly planOnly?: boolean | undefined;
    /**
     * Web seam used to retrieve one shared evidence block before drafting.
     * Omitted, or failing, simply means seats are told no evidence was
     * retrieved — which is still far better than leaving them to guess.
     */
    readonly web?: (SearchSeam & Partial<FetchSeam>) | undefined;
    /**
     * Web results each hosted seat may request per call. Undefined or zero
     * leaves them offline, answering from training data alone.
     */
    readonly webMaxResults?: number | undefined;
    /**
     * Let each seat say what it wants looked up, then run those searches through
     * the web seam on its behalf. The seam's router prefers a subscription
     * route, so the searches themselves are normally free — only the short round
     * where seats state their queries costs anything.
     */
    readonly seatResearch?: boolean | undefined;
    /**
     * Searches the research round runs at once.
     *
     * The seam routes across two authenticated CLI lanes, so more than one
     * search can be in the air without either subscription queueing. Undefined
     * takes the module default.
     */
    readonly researchConcurrency?: number | undefined;
    /**
     * File seam used to serve the paths seats ask for. A seat never reads for
     * itself; it names a path and this reads it, or refuses.
     */
    readonly files?: FileSeam | undefined;
    /**
     * Absolute directories the seats may be shown files from. Empty — the
     * default — means no seat is told it can ask for a file at all.
     */
    readonly fileRoots?: readonly string[] | undefined;
}
/**
 * Choose which seat writes the plan.
 *
 * Preference order: an explicitly configured planner, then the seat whose plan
 * won the vote, then the first enabled OpenRouter seat (a metered call whose
 * cost is known), then the first enabled seat of any kind.
 *
 * The winner outranks the cost-transparency preference because the two are
 * answering different questions. Reaching for the seat with the clearest price
 * is the right default when nobody has been chosen; once a council has settled
 * on a plan, the seat that wrote it holds the reasoning behind it, and handing
 * the decomposition to a different seat means re-deriving that reasoning from
 * prose — the cheapest call producing the most expensive graph. A configured
 * planner still wins, because that is the user saying so outright.
 * @param seats - the active roster.
 * @param preferred - explicitly configured planner seat id.
 * @param winner - seat whose plan the council voted for, when one won.
 * @returns the planning seat, or undefined when the roster is empty.
 */
export declare function choosePlanner(seats: readonly SeatConfig[], preferred: string | undefined, winner?: string): SeatConfig | undefined;
/**
 * Every seat that could plan, best first.
 *
 * The planner is one cheap call that gates an expensive round, so its failure
 * used to end the run: no plan meant no estimate and no drafts, and the seats
 * that were working never got to speak. Ordering the candidates lets a
 * transient failure on the cheapest seat fall through to the next one.
 * @param seats - the active roster.
 * @param preferred - explicitly configured planner seat id.
 * @param winner - seat whose plan the council voted for, when one won.
 * @returns candidate planners in the order they should be tried.
 */
export declare function plannerOrder(seats: readonly SeatConfig[], preferred: string | undefined, winner?: string): readonly SeatConfig[];
/**
 * Parse a review reply into a vote, confidence, and critique.
 *
 * Tolerant by design: seats answer in prose more often than they follow a
 * format exactly, so a missing confidence defaults to 0.5 and a vote is
 * recovered from any recognised seat id or name anywhere in the reply.
 * @param text - the seat's raw reply.
 * @param seats - roster used to resolve names to ids.
 * @returns the parsed vote, confidence, and critique.
 */
export declare function parseReview(text: string, seats: readonly SeatConfig[]): {
    vote?: SeatId | undefined;
    confidence: number;
    critique: string;
};
/**
 * Whether a seat failure means its backend is not there.
 * @param error - the seat's failure text, when it failed.
 * @returns true when the backend, not the model, is the fault.
 */
export declare function unreachableError(error: string | undefined): boolean;
/** How many usable drafts and good reviews a run needs to call itself completed. */
export interface Quorum {
    readonly minDrafts: number;
    readonly minReviews: number;
}
/**
 * The quorum for a roster, proportional unless the user set one.
 *
 * An absolute `minDrafts: 2` let two answers out of eight read as a decision.
 * The default is now half the roster for drafts (never below two, so a lone
 * seat is partial unless the user explicitly asks for `minDrafts: 1`) and a
 * third for reviews (never below one).
 * @param seatCount - enabled seats in the run.
 * @param explicit - values the user configured, which win when present.
 * @returns the quorum to judge the run against.
 */
export declare function quorumFor(seatCount: number, explicit?: {
    readonly minDrafts?: number | undefined;
    readonly minReviews?: number | undefined;
} | undefined): Quorum;
/**
 * Tally reviews into a verdict.
 *
 * Confidence-weighted sum decides first; a plain vote count breaks a
 * confidence tie; a lone successful draft wins uncontested.
 * @param reviews - every seat's review.
 * @param drafts - the drafts under review.
 * @param penalties - per-seat score deductions applied before the tally, keyed by seat.
 * @returns the verdict, including whether it was tied.
 */
export declare function tally(reviews: readonly SeatReview[], drafts: readonly SeatReply[], penalties?: ReadonlyMap<SeatId, number>): Verdict;
/** What one amendment of a stored run changed. */
export interface Amendment {
    /** The run that was amended. */
    readonly runId: string;
    /** Which attempt this was, counting from one. */
    readonly attempt: number;
    /** Seats that failed before and answered this time. */
    readonly recoveredDrafts: readonly SeatId[];
    /** Seats whose review was recovered. */
    readonly recoveredReviews: readonly SeatId[];
    /** Seats that failed again. */
    readonly stillFailing: readonly SeatId[];
    /**
     * Seats whose vote was cast before the recovered drafts existed.
     *
     * Their reviews are kept — re-asking every seat is the whole cost an
     * amendment exists to avoid — but a vote taken on three answers is not a
     * vote on five, and a report that hid that would be claiming a judgement
     * nobody made.
     */
    readonly staleReviews: readonly SeatId[];
}
/** What {@link amendCouncil} needs to fill a stored run's holes. */
export interface AmendOptions {
    readonly record: RunRecord;
    /** The current roster; a seat missing from it cannot be re-asked. */
    readonly seats: readonly SeatConfig[];
    readonly apiKey?: string | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly timeoutMs: number;
    readonly sequential?: boolean | undefined;
    readonly memory?: {
        file?: string | undefined;
        text?: string | undefined;
    } | undefined;
    readonly web?: (SearchSeam & Partial<FetchSeam>) | undefined;
    readonly webMaxResults?: number | undefined;
    readonly onEvent?: ((event: CouncilEvent) => void) | undefined;
}
/**
 * Re-ask only the seats that failed in a stored run, then re-tally.
 *
 * This is the cheap half of a council: no planning round, no re-drafting from
 * the seats that answered, no second approval — the approval that paid for the
 * run still stands, and the work here is bounded by how many seats failed.
 * @param options - the stored run and how to reach its seats.
 * @returns a complete result, with {@link Amendment} saying what changed.
 */
export declare function amendCouncil(options: AmendOptions): Promise<CouncilResult>;
/**
 * Run one full council: draft round, review round, tally.
 * @param options - query, roster, credentials, and limits.
 * @returns every artefact the report needs.
 */
export declare function runCouncil(options: RunOptions): Promise<CouncilResult>;
//# sourceMappingURL=council.d.ts.map