/**
 * The models the local Codex CLI offers, read from its own model cache.
 *
 * Codex refreshes `~/.codex/models_cache.json` from its service and marks each
 * entry `list` or `hide`; its own picker shows only the listed ones. The
 * council panel runs in the browser and cannot read that file, so the host
 * reads it and publishes the ids into the council settings section, the same
 * way it publishes measured CLI usage.
 */
/** Where Codex keeps its model cache. */
export declare const CODEX_MODELS_CACHE: string;
/**
 * Read the model ids Codex's own picker would offer.
 * @param file - the cache file; defaults to Codex's own.
 * @returns listed model slugs in cache order, or an empty list when the file is
 *   missing or unreadable — a machine without Codex simply offers no choices.
 */
export declare function readCodexModels(file?: string): string[];
//# sourceMappingURL=codex-models.d.ts.map