/**
 * The weight router: role requirements and a candidate field in, a concrete
 * roster with its reasons out.
 *
 * Used by council selection, swarm launchers and any other caller that has to
 * turn "a reviewer with high reasoning, independent of the coder" into a named
 * seat at the moment of launch. It holds no state, reads no files and knows
 * nothing about the caller, so the same engine can serve a pipeline stage and
 * a single delegated task.
 */
export type { Assignment, Candidate, CapabilityLevel, Coverage, CoverageRefusal, CoverageRejectionCode, Rejection, RejectionCode, Resolution, RoleRequirement, RoutingContext, RoutingCostClass, RoutingPolicy, ScoreFactors, } from './types.ts';
export { capabilityLevels, levelRank, routingPolicies } from './types.ts';
export type { MachineProfile, Registry, RegistryData } from './registry.ts';
export { buildRegistry, capabilityOf, isZeroMarginalCost } from './registry.ts';
export { checkCandidate, defaultMinQuotaHeadroom, estimateSeconds, estimateUsd, outputTokensFor } from './filter.ts';
export type { FilterFailure } from './filter.ts';
export { baselineFor, capabilityFit, factorsFor, policyWeights, scoreOf } from './score.ts';
export type { ScoreBaseline } from './score.ts';
export { resolveRoster } from './resolve.ts';
export type { LocalTarget, LocalTargetModel, LocalTargetRequest, ResolvedLocalTarget, TargetHealth } from './local-targets.ts';
export { DEFAULT_RELAY_TOKEN_REF, localCandidates, rankLocalTargets, resolveLocalTarget } from './local-targets.ts';
//# sourceMappingURL=index.d.ts.map