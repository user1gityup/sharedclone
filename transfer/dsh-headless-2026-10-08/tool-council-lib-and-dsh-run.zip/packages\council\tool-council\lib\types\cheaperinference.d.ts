/**
 * CheaperInference: model catalogue, wallet, and usage.
 *
 * The provider is OpenAI-compatible, so inference needs no new transport — a
 * seat with `baseUrl` and its own `apiKeyEnv` already reaches it. What it does
 * need is the three things OpenRouter's own endpoints supply and this one
 * spells differently: which models exist and what they cost (`GET /v1/models`),
 * what is left to spend (`GET /v1/account/balance`), and what has been spent
 * (`GET /v1/account/usage`).
 *
 * Field names and shapes here come from the provider's published OpenAPI
 * document (`https://api.cheaperinference.com/openapi.json`), read 2026-09-21.
 * Prices arrive as decimal *strings* per million tokens, not numbers, which is
 * why every price crosses into this module through {@link parseUsd} rather
 * than a cast: a silent `NaN` in a budget line is worse than a missing one.
 */
/** Base URL of the OpenAI-compatible surface. */
export declare const CHEAPERINFERENCE_BASE_URL = "https://api.cheaperinference.com/v1";
/** Chat-completions endpoint a council seat posts to. */
export declare const CHEAPERINFERENCE_CHAT_URL = "https://api.cheaperinference.com/v1/chat/completions";
/** Credential reference holding the key. Never the key itself. */
export declare const CHEAPERINFERENCE_KEY_ENV = "CHEAPERINFERENCE_API_KEY";
/** How long a fetched catalogue stays usable before it is read again. */
export declare const CATALOG_TTL_MS: number;
/**
 * The model a seat carries when it has not been pinned to one.
 *
 * The catalogue is the provider's own live list and its prices move, so a
 * hard-coded default would be a guess that goes stale. This placeholder is
 * resolved to the cheapest usable text model at the moment the seat speaks,
 * the same way `openrouter-free` carries `proxy-auto` for a proxy that picks
 * the model itself. The model picker overwrites it with a real id.
 */
export declare const CATALOG_CHEAPEST = "catalog-cheapest";
/** What one model costs, in USD per million tokens. */
export interface ModelPricing {
    /** Prompt tokens. */
    readonly inputPerMillion?: number | undefined;
    /** Generated tokens. */
    readonly outputPerMillion?: number | undefined;
    /** Prompt tokens served from the provider's cache. */
    readonly cacheReadPerMillion?: number | undefined;
    /** What the upstream provider charges direct, when published. */
    readonly listInputPerMillion?: number | undefined;
    /** What the upstream provider charges direct for output, when published. */
    readonly listOutputPerMillion?: number | undefined;
    /** Discount off list, as a percentage, when published. */
    readonly discountPercent?: number | undefined;
}
/** One model as the council cares about it. */
export interface CheaperModel {
    /** The id to put in a request's `model` field. */
    readonly id: string;
    /** Who serves it. */
    readonly ownedBy?: string | undefined;
    /** `text`, `image` or `video`. */
    readonly type: string;
    /** Total context window in tokens, when published. */
    readonly contextLength?: number | undefined;
    /** Published output ceiling, when published. */
    readonly maxOutputTokens?: number | undefined;
    /** True when the provider bills nothing for it. */
    readonly free: boolean;
    /** True when the model can stream, which a council seat requires. */
    readonly streaming: boolean;
    /** True when the model reasons before answering. */
    readonly reasoning: boolean;
    /** Prices, when published. */
    readonly pricing: ModelPricing;
}
/** A catalogue reading, with the provider's own pricing revision. */
export interface ModelCatalog {
    /** Every model the key may use, in the provider's order. */
    readonly models: readonly CheaperModel[];
    /** The provider's hash of the price table this reading was priced by. */
    readonly pricingVersion: string;
    /** When this process fetched it. */
    readonly fetchedAt: number;
}
/** What is left to spend. */
export interface Wallet {
    /** Wallet balance. */
    readonly balanceUsd: number;
    /** Balance minus holds against requests in flight — the spendable figure. */
    readonly availableUsd: number;
    /** Held against requests in flight. */
    readonly reservedUsd: number;
    /** Whether the provider tops the wallet up on its own. */
    readonly autoRecharge: boolean;
    /** The card auto-recharge would draw on, as the provider describes it. */
    readonly card?: string | undefined;
}
/** One model's share of a usage window. */
export interface UsageByModel {
    readonly model: string;
    readonly requestCount: number;
    readonly billedUsd?: number | undefined;
    readonly savedUsd?: number | undefined;
}
/** What has been spent over a window. */
export interface UsageWindow {
    /** Length of the window in days. */
    readonly days: number;
    /** Requests in the window. */
    readonly requestCount: number;
    /** What the account was billed. */
    readonly billedUsd: number;
    /** List price minus what was billed. */
    readonly savedUsd: number;
    /** What the same traffic would have cost at list price, when published. */
    readonly listUsd?: number | undefined;
    /** Saving as a percentage of list, when the provider computes it. */
    readonly savingsPercent?: number | undefined;
    /** Biggest spenders first, as the provider ranks them. */
    readonly topModels: readonly UsageByModel[];
}
/** Whether a run may proceed, and why. */
export interface WalletDecision {
    /** Whether the run may start. */
    readonly allowed: boolean;
    /** Human-readable reason, always populated. */
    readonly reason: string;
    /** The reading the decision was made from, when one could be taken. */
    readonly wallet?: Wallet | undefined;
}
/** Floor below which a run is refused. */
export interface WalletLimits {
    /**
     * Refuse to start a run when the spendable balance is below this.
     *
     * There is deliberately no monthly target here. A wallet is prepaid: the
     * balance *is* the limit, and a second ceiling on top of it would refuse
     * runs the user has already paid for.
     */
    readonly minBalanceUsd?: number | undefined;
}
/** Injectable `fetch`, so tests never reach the network. */
export type FetchLike = typeof globalThis.fetch;
/**
 * Read the whole model catalogue.
 * @param apiKey - the account's key.
 * @param signal - abort signal from the tool execution.
 * @param fetchImpl - injected fetch, for tests.
 * @returns the catalogue, or `undefined` when it could not be read.
 */
export declare function fetchCatalog(apiKey: string | undefined, signal?: AbortSignal | undefined, fetchImpl?: FetchLike): Promise<ModelCatalog | undefined>;
/**
 * Read the catalogue, reusing a recent reading.
 *
 * The model picker repaints far more often than the catalogue changes, and
 * every repaint would otherwise be a network round trip on the user's key.
 * @param apiKey - the account's key.
 * @param signal - abort signal from the tool execution.
 * @param options - cache lifetime and injected fetch.
 * @returns the catalogue, or `undefined` when none could be read.
 */
export declare function loadCatalog(apiKey: string | undefined, signal?: AbortSignal | undefined, options?: {
    readonly ttlMs?: number | undefined;
    readonly fetchImpl?: FetchLike | undefined;
    readonly now?: number | undefined;
}): Promise<ModelCatalog | undefined>;
/** Forget the cached catalogue, so the next read goes to the provider. */
export declare function invalidateCatalog(): void;
/**
 * The models a council seat or swarm worker can actually use.
 *
 * A seat streams its answer and sends text, so an image or video model, or one
 * that cannot stream, is not a candidate however cheap it is.
 * @param catalog - a catalogue reading.
 * @returns the usable models, cheapest output price first, unpriced last.
 */
export declare function textModels(catalog: ModelCatalog | undefined): readonly CheaperModel[];
/**
 * Read the wallet.
 * @param apiKey - the account's key.
 * @param signal - abort signal from the tool execution.
 * @param fetchImpl - injected fetch, for tests.
 * @returns the reading, or `undefined` when it could not be taken.
 */
export declare function readWallet(apiKey: string | undefined, signal?: AbortSignal | undefined, fetchImpl?: FetchLike): Promise<Wallet | undefined>;
/**
 * Read what has been spent over a window.
 * @param apiKey - the account's key.
 * @param days - window length; the provider's own default applies when omitted.
 * @param signal - abort signal from the tool execution.
 * @param fetchImpl - injected fetch, for tests.
 * @returns the reading, or `undefined` when it could not be taken.
 */
export declare function readUsage(apiKey: string | undefined, days?: number | undefined, signal?: AbortSignal | undefined, fetchImpl?: FetchLike): Promise<UsageWindow | undefined>;
/**
 * Decide whether a run may spend against this wallet.
 *
 * `availableUsd`, not `balanceUsd`, is the figure judged: the provider holds
 * part of the balance against requests already in flight, and spending it
 * twice is what an over-eager swarm would otherwise do.
 *
 * An unreadable wallet allows the run. A monitoring failure that stops every
 * council round is a worse outcome than a round that overdraws by cents, and
 * the provider refuses an overdrawn request itself with HTTP 402.
 * @param wallet - the current reading, or undefined when unavailable.
 * @param limits - the floor to enforce.
 * @returns the decision and its reasoning.
 */
export declare function judgeWallet(wallet: Wallet | undefined, limits?: WalletLimits): WalletDecision;
/**
 * What one run of a given size would cost on one model.
 * @param model - the model to price.
 * @param promptTokens - prompt tokens to be sent.
 * @param outputTokens - output tokens to be generated.
 * @returns the estimate in USD, or `undefined` when the model has no price.
 */
export declare function estimateUsd(model: CheaperModel, promptTokens: number, outputTokens: number): number | undefined;
/**
 * Resolve {@link CATALOG_CHEAPEST} to a real model id.
 * @param apiKey - the account's key.
 * @param signal - abort signal from the tool execution.
 * @param options - cache lifetime and injected fetch, as {@link loadCatalog}.
 * @returns the cheapest usable text model's id, or `undefined` when the
 *   catalogue could not be read or holds no usable model.
 */
export declare function resolveCheapestModel(apiKey: string | undefined, signal?: AbortSignal | undefined, options?: {
    readonly ttlMs?: number | undefined;
    readonly fetchImpl?: FetchLike | undefined;
    readonly now?: number | undefined;
}): Promise<string | undefined>;
//# sourceMappingURL=cheaperinference.d.ts.map