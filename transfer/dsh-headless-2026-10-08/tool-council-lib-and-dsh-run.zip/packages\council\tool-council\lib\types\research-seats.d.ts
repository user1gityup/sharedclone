/** Distribute research queries across enabled free seats with native web tools. */
import type { SearchSeam } from './evidence.ts';
import type { SeatConfig, SeatReply } from './seats.ts';
/**
 * Create a round-robin search provider, falling back to the host on failure.
 * @param seats - active seats in this run.
 * @param ask - accounted seat invocation owned by the council run.
 * @param fallback - existing search provider, when mounted.
 * @returns a search provider, or the original fallback when no free seat can search.
 */
export declare function researchSeats(seats: readonly SeatConfig[], ask: (seat: SeatConfig, prompt: string) => Promise<SeatReply>, fallback: SearchSeam | undefined): SearchSeam | undefined;
//# sourceMappingURL=research-seats.d.ts.map