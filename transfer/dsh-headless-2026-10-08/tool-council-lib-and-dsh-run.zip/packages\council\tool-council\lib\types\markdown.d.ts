/**
 * Markdown rendering for the conversation surface.
 *
 * The web chat renders markdown, not ANSI, so escape codes would arrive as
 * literal garbage. Seat identity is carried by a coloured disc that matches the
 * console palette — cyan, green, magenta, yellow — which survives any markdown
 * renderer without needing HTML or custom components.
 */
import type { CouncilResult } from './council.ts';
/**
 * Render a council result as markdown for the conversation surface.
 * @param result - the completed run.
 * @returns markdown text.
 */
export declare function renderMarkdown(result: CouncilResult): string;
//# sourceMappingURL=markdown.d.ts.map