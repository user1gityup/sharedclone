/**
 * Saved runs, and the narrow door a model may use to write one.
 *
 * Settings are deliberately the one channel no model-facing tool reaches: that
 * is what makes the approval gate mean anything, since a model that could
 * write `approvedPlanId` could approve its own spending. Presets are the one
 * exception worth making, because a preset is only a piece of TEXT the user
 * will later choose to press — it authorises nothing and spends nothing on its
 * own. So the door is cut to exactly that shape here: this module produces a
 * new `pipelinePresets` map and nothing else, and the tool that uses it writes
 * that one key. No approval slot is reachable from this path even by mistake.
 *
 * The id carries the naming convention (`area/name`) rather than a separate
 * field, because a list is only scannable when its order means something, and
 * sorting by id is the cheapest order that groups an area's runs together.
 */
/** One saved run. */
export interface PresetEntry {
    readonly mode?: 'council' | 'economy' | 'fastest' | undefined;
    /** The button label. */
    readonly name: string;
    /** The whole request, written out once. */
    readonly query: string;
    /** Advance the chain between stages without being asked. */
    readonly autoAdvance?: boolean | undefined;
    /**
     * The stage order this run needs, comma separated, when it is not the
     * default `council,swarm,review`.
     *
     * A saved run is the only place the order can sensibly live. It is a
     * property of the KIND of work — deciding something wants three stages,
     * building something wants the proposing stage in the middle — and the user
     * chose that when they wrote the run, not when they pressed the button.
     * Leaving it out of the preset meant a build run had to ask for its own
     * stages in prose, which the tool never read.
     */
    readonly stages?: string | undefined;
}
/** Presets as settings hold them, keyed by `area/name`. */
export type PresetMap = Readonly<Record<string, PresetEntry>>;
/** `area/name`, both lowercase kebab. Anything else sorts and reads badly. */
export declare const PRESET_ID: RegExp;
/**
 * The longest request a preset may carry; past this it belongs in a file.
 *
 * Raised from 32k after a real prompt came in at 38k: the whole point of a
 * saved run is that the request is already written out, so a ceiling that a
 * genuine one overshoots turns every long prompt into a negotiation. 64k still
 * sits far below anything that would bloat settings.yaml, and a request past
 * it is long enough that a file reference reads better than an inlined wall.
 */
export declare const MAX_QUERY = 64000;
/**
 * Why this id is not usable, or undefined when it is.
 *
 * The rules are the convention, enforced rather than documented: a preset with
 * no area lands in a flat list nobody can scan, and one with capitals or spaces
 * sorts unpredictably next to its neighbours.
 * @param id - the proposed id.
 * @returns the problem, or undefined.
 */
export declare function presetIdProblem(id: string): string | undefined;
/** What a save attempt produced. */
export interface PresetWrite {
    /** The map to persist; unchanged from the input when there is a problem. */
    readonly presets: PresetMap;
    /** Why nothing was written. */
    readonly problem?: string | undefined;
    /** True when an existing preset was replaced rather than added. */
    readonly replaced?: boolean | undefined;
}
/**
 * Add or replace one preset, returning a whole new map.
 *
 * Refusing to overwrite unless asked is the point: a saved run is a thing the
 * user presses without reading, so silently changing what a familiar button
 * does is worse than failing to save.
 * @param existing - the presets as they stand.
 * @param id - `area/name`.
 * @param entry - the preset to store.
 * @param replace - permission to overwrite an id already in use.
 * @returns the new map, or the old one with a problem.
 */
export declare function savePreset(existing: PresetMap, id: string, entry: PresetEntry, replace?: boolean): PresetWrite;
/**
 * Remove one preset.
 * @param existing - the presets as they stand.
 * @param id - the preset to remove.
 * @returns the new map, or the old one with a problem.
 */
export declare function removePreset(existing: PresetMap, id: string): PresetWrite;
/**
 * The saved runs, in the order the panel shows them.
 * @param presets - the map from settings.
 * @returns id/entry pairs sorted by id, so areas group themselves.
 */
export declare function listPresets(presets: PresetMap): readonly (readonly [string, PresetEntry])[];
/**
 * The saved runs as a report, grouped by area.
 * @param presets - the map from settings.
 * @returns markdown.
 */
export declare function renderPresets(presets: PresetMap): string;
/** The fields an edit may change; anything left out keeps its current value. */
export interface PresetPatch {
    readonly name?: string | undefined;
    readonly query?: string | undefined;
    readonly mode?: PresetEntry['mode'];
    readonly autoAdvance?: boolean | undefined;
    /** An empty string clears a custom order back to the default. */
    readonly stages?: string | undefined;
    /** Move the preset to a new `area/name`. */
    readonly id?: string | undefined;
}
/**
 * Change part of one preset, optionally moving it to a new id.
 *
 * An edit is a replace the user asked for by name, so it may overwrite its own
 * entry — but a move onto an id another preset already holds would silently
 * destroy that one, and is refused for the same reason {@link savePreset}
 * refuses a blind overwrite.
 * @param existing - the presets as they stand.
 * @param id - the preset to edit.
 * @param patch - the fields to change.
 * @returns the new map, or the old one with a problem.
 */
export declare function updatePreset(existing: PresetMap, id: string, patch: PresetPatch): PresetWrite;
/**
 * Copy one preset under a new id, so a variant can be edited without touching the original.
 * @param existing - the presets as they stand.
 * @param id - the preset to copy.
 * @param copyId - the id the copy is saved under.
 * @param name - the copy's label; defaults to the original's with " (copy)".
 * @returns the new map, or the old one with a problem.
 */
export declare function duplicatePreset(existing: PresetMap, id: string, copyId: string, name?: string): PresetWrite;
//# sourceMappingURL=presets.d.ts.map