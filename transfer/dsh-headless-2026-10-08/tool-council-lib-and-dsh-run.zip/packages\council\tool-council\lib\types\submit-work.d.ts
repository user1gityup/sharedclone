import type { Context } from '@deepseek-ai/cordis';
import { type WriterRepo, type WriterSettings } from './host-commit.ts';
/** Writer settings as they appear in the council configuration. */
export interface WriterConfig {
    /** Parent of writer worktrees. Defaults to ~/.dsh/worktrees. */
    worktreeRoot?: string;
    /** Absolute path of the gatekeeper's queue-build.mjs. Required. */
    queueScript?: string;
    /** Queue file override for queue-build. */
    queuePath?: string;
    /** Limit for each git, setup and check command. Defaults to ten minutes. */
    commandTimeoutMs?: number;
    /** Repositories writers may submit to, keyed by a short name. */
    repos?: Record<string, {
        /** Absolute path of the repository writers branch from. */
        path: string;
        /** Branch submitted work is targeted at. */
        target: string;
        /** Commands run once after the worktree is created, each as argv. */
        setup?: string[][];
        /** Commands that must pass before the work is queued, each as argv. */
        checks?: string[][];
    }>;
}
/**
 * Read a stage_work batch back into the files_json shape.
 * @param workspaceRoot - session workspace that owns .dsh-staging.
 * @param batch - batch id printed by stage_work.
 * @returns JSON object mapping relative paths to contents.
 */
export declare function readStagedBatch(workspaceRoot: string, batch: string): Promise<string>;
/**
 * Check the writer settings and resolve one repository key.
 *
 * Pulled out of the tool so the swarm seam can make the same check BEFORE a
 * run rather than after: a misspelled repo key that only surfaces once every
 * unit has been paid for is a refusal that arrives too late to be useful.
 * @param settings - writer settings as configured.
 * @param repoKey - the repository key being submitted to.
 * @returns the host settings and the resolved repository.
 */
export declare function resolveWriter(settings: WriterConfig | undefined, repoKey: string): {
    host: WriterSettings;
    repo: WriterRepo;
};
/**
 * Register `submit_work`.
 * @param ctx - context with tools, agents and sandbox policy.
 * @param writer - reads the current writer settings on every call.
 */
export declare function registerSubmitWork(ctx: Context, writer: () => WriterConfig | undefined): void;
//# sourceMappingURL=submit-work.d.ts.map