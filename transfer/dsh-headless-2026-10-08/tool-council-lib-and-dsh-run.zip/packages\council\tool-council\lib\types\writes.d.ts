/**
 * Seats proposing code, each into a tree of its own.
 *
 * `files.ts` gives a seat a way to be shown source it cannot reach. This is
 * the other direction: a way for a seat to produce source without being able
 * to reach anything either. A seat emits `WRITE:` blocks; the host writes them
 * under that seat's own root and nowhere else. An OpenRouter seat has no
 * filesystem and no process, so this is the only sense in which it can own a
 * directory tree at all — and it turns out to be the safer sense, because the
 * seat never holds a handle it could point somewhere unintended.
 *
 * Nothing here touches the real repositories. A proposal is a candidate, and
 * candidates are written side by side so a later round can compare them and
 * pick one. Applying the winner is a separate, human-gated act.
 *
 * Two containment checks run on every proposal, and both must pass. The path
 * must name a location inside a granted source root — so a seat cannot invent
 * a target outside the work — and the destination must land inside that seat's
 * own root, so one seat cannot write over another's candidate.
 */
/** Files one seat may propose in a round. */
export declare const MAX_WRITES_PER_SEAT = 6;
/** Characters accepted for one proposed file. */
export declare const MAX_WRITE_CHARS = 20000;
/** Characters accepted across one seat's whole proposal. */
export declare const MAX_WRITE_CHARS_TOTAL = 60000;
/**
 * Least time a seat gets to write a unit that stages files. A whole file is a
 * long reply, and the run-wide default cut seats off mid-file.
 */
export declare const WRITE_UNIT_TIMEOUT_MS = 600000;
/** The subset of the filesystem this module needs, so tests need no disk. */
export interface WriteSeam {
    write(path: string, text: string): Promise<void>;
}
/** One file a seat proposed. */
export interface ProposedWrite {
    /** Path as the seat wrote it. */
    readonly path: string;
    /** Full intended contents of the file. */
    readonly content: string;
}
/** One file actually written into a seat's tree. */
export interface WrittenFile {
    /** Path relative to the source root, as shown in reports. */
    readonly label: string;
    /** Absolute path inside the seat's own tree. */
    readonly path: string;
    /** Characters written. */
    readonly chars: number;
}
/** What one seat produced in a proposing round. */
export interface Candidate {
    readonly seat: string;
    /** Absolute root this seat's files were written under. */
    readonly root: string;
    readonly files: readonly WrittenFile[];
    /** Proposals that were not written, and why. */
    readonly refused: readonly string[];
}
/**
 * The section of a prompt that tells a seat how to propose code.
 *
 * A seat is told plainly that it is writing into its own tree and that nothing
 * it writes reaches the real repository. Without that, a model asked to edit a
 * file it cannot see will either refuse or claim to have edited it.
 * @param roots - absolute source roots whose files may be targeted.
 * @returns the prompt section, or an empty string when nothing may be written.
 */
export declare function writeRequestSection(roots: readonly string[]): string;
/**
 * Pull proposed files out of a seat's reply.
 *
 * A `WRITE:` line must be followed by a fenced block; a bare one is dropped
 * rather than guessed at, because the alternative is writing whatever prose
 * happened to follow it into a source file.
 * @param text - the seat's reply.
 * @param max - most files to accept from this seat.
 * @returns the proposals, in the order the seat gave them.
 */
export declare function parseWriteRequests(text: string, max?: number): readonly ProposedWrite[];
/**
 * Recover the one file a single-file unit asked for when the seat did not use
 * the `WRITE:` form.
 *
 * Free seats reliably produce the file and unreliably produce the header. When
 * a unit names exactly one file there is only one place the reply can be meant
 * for, so the header adds nothing but a way to fail. Tried in order: a line that
 * is just the target path followed by a fence; else the largest closed fenced
 * block; else the whole reply.
 * @param text - the seat's reply.
 * @param target - the unit's only target path.
 * @returns the proposal, or undefined when the reply is empty.
 */
export declare function parseSingleFileReply(text: string, target: string): ProposedWrite | undefined;
/**
 * A seam backed by the real filesystem, creating parent directories.
 * @returns a seam writing UTF-8 to disk.
 */
export declare function diskWriteSeam(): WriteSeam;
/**
 * Write one seat's proposals into that seat's own tree.
 *
 * Both containment checks live here rather than in the caller. A path must
 * name a location inside a granted source root, so a seat cannot target a file
 * outside the work; and the destination must resolve inside the seat's own
 * root, so a proposal cannot escape into another seat's candidate or into the
 * real repository.
 * @param seam - the write seam, or undefined when proposing is switched off.
 * @param seatRoot - absolute directory this seat owns.
 * @param sourceRoots - absolute source roots whose files may be targeted.
 * @param seat - the seat id, for the report.
 * @param proposals - what the seat proposed.
 * @returns what was written and what was refused.
 */
export declare function applyWrites(seam: WriteSeam | undefined, seatRoot: string, sourceRoots: readonly string[], seat: string, proposals: readonly ProposedWrite[]): Promise<Candidate>;
/**
 * Render what each seat proposed, for the report shown at the selection round.
 * @param candidates - one per seat that proposed.
 * @returns a markdown summary.
 */
export declare function renderCandidates(candidates: readonly Candidate[]): string;
//# sourceMappingURL=writes.d.ts.map