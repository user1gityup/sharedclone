/**
 * Citation verification.
 *
 * Shared evidence removes a seat's *incentive* to invent a source, but nothing
 * in it checks whether the source a seat actually cited exists. A model that
 * has produced plausible-looking URLs its whole training life will still
 * produce one under pressure, and a fabricated citation is worse than no
 * citation: it reads as diligence.
 *
 * So every draft is audited. URLs that came from the shared evidence are
 * trusted without a second request — the council just retrieved them. Anything
 * else is fetched and must answer. A seat that cites what does not resolve, or
 * that emits tool-call syntax it had no tools to run, is scored down rather
 * than merely annotated: the tally is where a fabrication has to cost
 * something, or it will keep winning on fluency.
 */
import type { SeatId } from './colors.ts';
/** Outcome for one cited URL. */
export type CitationStatus = 
/** Came from the shared evidence block, so already retrieved. */
'evidence'
/** Fetched successfully just now. */
 | 'reachable'
/** Fetched and did not answer, or could not be fetched at all. */
 | 'unreachable'
/** Not checked: over the per-draft budget. */
 | 'unchecked';
/** One cited URL and what became of it. */
export interface Citation {
    readonly url: string;
    readonly status: CitationStatus;
    /** Why, when the status needs explaining. */
    readonly detail?: string | undefined;
}
/** What auditing one draft found. */
export interface DraftAudit {
    readonly seat: SeatId;
    readonly citations: readonly Citation[];
    /** Tool-call syntax the seat emitted despite having no tools. */
    readonly fabricatedToolCalls: readonly string[];
    /** Score multiplier penalty in 0..1, applied by the tally. */
    readonly penalty: number;
}
/** The subset of the web seam this module needs. */
export interface FetchSeam {
    fetch(request: {
        readonly url: string;
    }, signal?: AbortSignal): Promise<{
        readonly statusCode: number;
    }>;
}
/**
 * Pull http(s) URLs out of prose, trimming trailing punctuation and markdown.
 * @param text - the draft.
 * @returns unique URLs in first-seen order.
 */
export declare function extractUrls(text: string): readonly string[];
/**
 * Find tool-call syntax a tool-less seat could not have executed.
 * @param text - the draft.
 * @returns the distinct shapes found.
 */
export declare function detectFabricatedToolCalls(text: string): readonly string[];
/**
 * Turn an audit's findings into a score multiplier penalty.
 * @param citations - the audited citations.
 * @param fabricated - tool-call shapes found.
 * @returns a penalty in 0..MAX_PENALTY.
 */
export declare function penaltyFor(citations: readonly Citation[], fabricated: readonly string[]): number;
/**
 * Audit one draft's citations and tool-call syntax.
 *
 * Never throws: a verification failure must not take down a run that otherwise
 * produced good answers. A URL that cannot be checked is reported as such
 * rather than assumed good or assumed bad.
 * @param seat - whose draft this is.
 * @param text - the draft.
 * @param evidenceUrls - URLs already retrieved as shared evidence.
 * @param seam - the fetch seam, or undefined to skip network checks.
 * @param signal - cancellation from the run.
 * @returns what the audit found.
 */
export declare function auditDraft(seat: SeatId, text: string, evidenceUrls: readonly string[], seam: FetchSeam | undefined, signal?: AbortSignal): Promise<DraftAudit>;
//# sourceMappingURL=verify.d.ts.map