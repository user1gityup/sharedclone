/**
 * Where the quota ledger's state lives, and the local file that keeps it.
 *
 * The ledger never edits state in place. It reads the whole state with a
 * version, computes the next one, and hands it back through
 * `compareAndSwap(version, next)`, which writes only if nobody else wrote in
 * between. Any store that can make that promise can hold the ledger.
 *
 * The file store makes it for the processes of one host. A writer first takes
 * an exclusive lock file (created with the 'wx' flag, so exactly one creator
 * wins) recording its pid, host and the time it took the lock. Under the lock
 * it re-reads the version — the one the ledger computed from may be stale by
 * now — and only on a match writes the next state to a temporary file and
 * renames it over the ledger, so a reader sees the old file or the new one and
 * never half of either. Windows refuses a rename while another process (an
 * indexer, an antivirus scan, a reader) has the target open, with EPERM or
 * EBUSY; those are retried a bounded number of times.
 *
 * A writer that dies holding the lock would stop every other writer, so a lock
 * older than `lockStaleMs` is broken. There is no default for it: it must be
 * longer than any honest write, and only the caller knows its disk. Breaking is
 * a read followed by an unlink, so two writers that judge the same lock stale
 * at the same instant can race; each writer checks it still holds its own lock
 * before renaming, which leaves only that check-to-rename gap open.
 */
import type { SeatLedger } from './quota-ledger.ts';
/** The whole ledger: every seat that has a reading. */
export interface LedgerState {
    /** Seats by seat key. */
    readonly seats: Readonly<Record<string, SeatLedger>>;
}
/** The ledger as read, with the version a compare-and-swap must match. */
export interface VersionedLedger {
    /** The state. */
    readonly state: LedgerState;
    /** Bumped by one on every successful swap; 0 before the first. */
    readonly version: number;
}
/** What the ledger needs from wherever its state lives. */
export interface LedgerStore {
    /**
     * Read the whole ledger.
     * @returns the state and its version.
     */
    read(): Promise<VersionedLedger>;
    /**
     * Replace the state only if nobody wrote since `expected` was read.
     * @param expected - the version the next state was computed from.
     * @param next - the state to write.
     * @returns true when written, false when the version had moved on or the store was busy.
     */
    compareAndSwap(expected: number, next: LedgerState): Promise<boolean>;
}
/** The file operations the file store uses, so tests can fail them on purpose. */
export interface LedgerFs {
    /**
     * Read a file as UTF-8.
     * @param path - the file.
     * @returns its text.
     */
    readFile(path: string): Promise<string>;
    /**
     * Write a file; with flag 'wx', fail with EEXIST if it already exists.
     * @param path - the file.
     * @param data - the text.
     * @param options - the open flag.
     */
    writeFile(path: string, data: string, options: {
        readonly flag: 'w' | 'wx';
    }): Promise<void>;
    /**
     * Rename a file over another.
     * @param from - the source.
     * @param to - the target, replaced if present.
     */
    rename(from: string, to: string): Promise<void>;
    /**
     * Remove a file.
     * @param path - the file.
     */
    unlink(path: string): Promise<void>;
    /**
     * A file's modification time.
     * @param path - the file.
     * @returns its stat, of which only mtimeMs is read.
     */
    stat(path: string): Promise<{
        readonly mtimeMs: number;
    }>;
    /**
     * Create a directory and its parents.
     * @param path - the directory.
     */
    mkdir(path: string): Promise<void>;
}
/** How a file store is set up. */
export interface FileLedgerStoreOptions {
    /** The ledger file. Its lock is the same path plus `.lock`. */
    readonly path: string;
    /** How old a lock must be before it is taken for a dead writer's and broken. */
    readonly lockStaleMs: number;
    /** The clock; defaults to `Date.now`. */
    readonly now?: () => number;
    /** The host written into the lock; defaults to the OS hostname. */
    readonly host?: string;
    /** The pid written into the lock; defaults to this process's. */
    readonly pid?: number;
    /** File operations; defaults to node:fs/promises. */
    readonly fs?: LedgerFs;
    /** How to wait between attempts; defaults to a timer. */
    readonly sleep?: (ms: number) => Promise<void>;
    /** How long to wait between attempts at a busy lock; defaults to 20 ms. */
    readonly lockWaitMs?: number;
    /** How many times to try a busy lock before reporting the store busy; defaults to 250. */
    readonly lockAttempts?: number;
    /** How many times to try a read or rename Windows refused with EPERM or EBUSY; defaults to 5. */
    readonly ioAttempts?: number;
}
/** A ledger store in one local file; see the module comment for how it swaps. */
export declare class FileLedgerStore implements LedgerStore {
    private readonly path;
    private readonly lockPath;
    private readonly lockStaleMs;
    private readonly now;
    private readonly host;
    private readonly pid;
    private readonly fs;
    private readonly sleep;
    private readonly lockWaitMs;
    private readonly lockAttempts;
    private readonly ioAttempts;
    /**
     * @param options - the file, the stale-lock age, and optional seams and bounds.
     */
    constructor(options: FileLedgerStoreOptions);
    /**
     * Read the ledger file; a file not yet written is an empty ledger at version 0.
     * @returns the state and its version.
     */
    read(): Promise<VersionedLedger>;
    /**
     * Write `next` under the lock if the file is still at `expected`.
     * @param expected - the version the next state was computed from.
     * @param next - the state to write.
     * @returns true when written; false when the version moved, the lock stayed busy, or it was lost.
     */
    compareAndSwap(expected: number, next: LedgerState): Promise<boolean>;
    /**
     * Take the lock, breaking it when its holder looks dead.
     * @returns this writer's token, or undefined when the lock stayed busy.
     */
    private acquire;
    /**
     * Who holds the lock, as far as the file shows. An empty or torn file is aged by its mtime.
     * @returns the holder, or undefined when there is no lock to judge.
     */
    private holder;
    /**
     * Whether this writer still holds the lock it took.
     * @param token - the token it wrote.
     * @returns true when the lock file still carries it.
     */
    private holds;
    /**
     * Run a read or rename again while Windows reports the file held open.
     * @param work - the operation.
     * @returns its result.
     */
    private retrying;
}
//# sourceMappingURL=quota-ledger-store.d.ts.map