/**
 * Capacity projection: what a given monthly configuration actually buys.
 *
 * Answers the question a budget cannot: not "am I over" but "how much work
 * does this money represent". Calibrated against the user's real measured
 * usage rather than a guess, so the answer is grounded in work already done.
 *
 * Everything here is an estimate and says so. Subscription seats have no
 * observable per-unit cost, so their contribution is counted in throughput,
 * never in dollars.
 */
import type { ModelPrice } from './estimate.ts';
import type { SeatConfig } from './seats.ts';
/** One month's configured spending power. */
export interface Configuration {
    /** OpenRouter credit budgeted per month. */
    readonly openRouterUsd: number;
    /** Subscription seats available, e.g. one Claude and one Codex. */
    readonly subscriptionSeats: number;
    /**
     * Output tokens one subscription seat can produce per month before its own
     * limits bite. Unknown unless the user supplies it, because no CLI exposes it.
     */
    readonly subscriptionTokensPerMonth?: number | undefined;
}
/** Observed work, used to calibrate the projection. */
export interface ObservedWork {
    /** Output tokens produced over the observation window. */
    readonly outputTokens: number;
    /** Length of that window, in days. */
    readonly days: number;
    /** Assistant messages produced, used to size a typical unit of work. */
    readonly messages: number;
}
/** What the configuration buys. */
export interface Capacity {
    /** Output tokens per month the hosted seats can afford. */
    readonly hostedTokensPerMonth: number;
    /** Output tokens per month the subscription seats contribute, when known. */
    readonly subscriptionTokensPerMonth?: number | undefined;
    /** Combined monthly output-token ceiling. */
    readonly totalTokensPerMonth: number;
    /** Observed usage scaled to a month, for comparison. */
    readonly observedTokensPerMonth: number;
    /** Multiple of current throughput this configuration represents. */
    readonly multiple: number;
    /** Full council runs affordable per month at the observed size. */
    readonly councilRunsPerMonth: number;
    /** Mean output tokens per assistant message in the observed window. */
    readonly tokensPerMessage: number;
    /** Caveats the reader must weigh before trusting the figure. */
    readonly caveats: readonly string[];
}
/**
 * Project what a configuration buys, calibrated against observed work.
 * @param config - the monthly budget and seat count.
 * @param seats - the council roster.
 * @param pricing - OpenRouter price table.
 * @param observed - measured usage to calibrate against.
 * @returns the projection and its caveats.
 */
export declare function projectCapacity(config: Configuration, seats: readonly SeatConfig[], pricing: ReadonlyMap<string, ModelPrice>, observed: ObservedWork): Capacity;
/**
 * Render a capacity projection for the console.
 * @param capacity - the projection.
 * @param config - the configuration it was computed for.
 * @returns lines ready to print.
 */
export declare function renderCapacity(capacity: Capacity, config: Configuration): readonly string[];
//# sourceMappingURL=capacity.d.ts.map