/**
 * OpenRouter balance surface.
 *
 * The OpenRouter monitor and the budget panel both fetch `/credits` from the
 * browser with a key kept in `localStorage`. That works on the machine where
 * the key was once pasted and nowhere else: a second host, a second browser
 * profile or a cleared site storage all show "no key" while the account it
 * would have reported is perfectly readable from the host. Worse, a host that
 * deliberately holds no raw key — reaching OpenRouter only through the relay —
 * can never satisfy that panel at all, because the panel wants the key itself.
 *
 * So the host reads the balance and publishes the figures, exactly as the
 * CheaperInference budget surface does. The panels keep their own key when one
 * is stored; when there is none they show the host's reading instead of
 * nothing. No credential ever reaches the browser either way.
 *
 * Two sources, in order of preference:
 *
 * 1. A raw key (`OPENROUTER_API_KEY`), used against OpenRouter directly.
 * 2. The relay, on hosts that hold no raw key: `<base>/openrouter/v1/credits`
 *    with `OPENROUTER_RELAY_TOKEN`. A loopback relay may trust the caller and
 *    need no token at all, so a missing token is not a failed resolution.
 *
 * `/credits` is free and unmetered, which is what makes a poll allowed here —
 * the same rule the CheaperInference surface follows, and the opposite of the
 * Claude quota surface, where a reading spends the user's own allowance.
 */
/** Default poll period; a credit balance does not move faster than this. */
export declare const OPENROUTER_BALANCE_POLL_MS = 300000;
/** Credential reference holding the relay's bearer token. */
export declare const RELAY_TOKEN_ENV = "OPENROUTER_RELAY_TOKEN";
/** Environment variable naming the relay's root, for hosts that set one. */
export declare const RELAY_BASE_ENV = "OPENROUTER_RELAY_BASE";
/** The settings fields this surface reads and writes. All flat scalars. */
export interface OpenRouterBalanceFields {
    /** Credits left to spend, in USD: purchased minus used. */
    openRouterRemainingUsd?: number | undefined;
    /** Credits bought to date, in USD. */
    openRouterPurchasedUsd?: number | undefined;
    /** Credits consumed to date, in USD. */
    openRouterUsedUsd?: number | undefined;
    /** Last successful capture, in epoch milliseconds. */
    openRouterCapturedAt?: number | undefined;
    /** idle, running, ok, or failed. */
    openRouterBalanceState?: string | undefined;
    /** Poll period in milliseconds; zero polls only at boot and on Refresh. */
    openRouterBalancePollMs?: number | undefined;
    /** Monotonic refresh request from a panel. */
    openRouterRefreshRequestedAt?: number | undefined;
    /**
     * Relay root for hosts that hold no raw key, e.g. `http://10.0.0.241:8080`.
     * A provider `baseURL` can be pasted in whole; the trailing `/v1` is dropped.
     */
    openRouterRelayBase?: string | undefined;
}
/** One reading of the account's credits. */
export interface CreditsReading {
    /** Credits bought to date, in USD. */
    readonly purchased: number;
    /** Credits consumed to date, in USD. */
    readonly used: number;
    /** What is left to spend, in USD. */
    readonly remaining: number;
}
/** Where a reading will be fetched from, and with what. */
export interface BalanceSource {
    /** Absolute credits URL. */
    readonly url: string;
    /** Bearer token; absent when a loopback relay trusts the caller. */
    readonly token?: string | undefined;
    /** Whether this goes through the relay rather than straight to OpenRouter. */
    readonly viaRelay: boolean;
}
/** Minimal fetch shape, so tests need no network. */
export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;
/** Everything the publisher needs from the host, so tests need no host at all. */
export interface BalanceHost {
    /** The current settings, as the panels see them. */
    live: () => OpenRouterBalanceFields;
    /** Publish a patch; rejections are treated as a read-only settings provider. */
    update: (patch: OpenRouterBalanceFields) => Promise<void>;
    /** Observe settings changes, for a panel's Refresh. Returns an unwatch. */
    watch?: ((listener: (next: OpenRouterBalanceFields) => void) => () => void) | undefined;
    /** The raw account key, or undefined on a relay-only host. */
    key?: (() => string | undefined) | undefined;
    /** The relay's bearer token, or undefined when the relay trusts the caller. */
    relayToken?: (() => string | undefined) | undefined;
    /** Environment, consulted for {@link RELAY_BASE_ENV}. */
    env?: Readonly<Record<string, string | undefined>> | undefined;
    /**
     * The OpenRouter route's configured `baseURL`, from whichever provider
     * surface this host uses. Injected rather than read here so this module
     * stays free of another plugin's settings shape.
     */
    providerBase?: (() => string | undefined) | undefined;
    /** Injected fetch, for tests. */
    fetchImpl?: FetchLike | undefined;
    /** Injected clock, for tests. */
    now?: (() => number) | undefined;
}
/**
 * Normalise a relay root.
 *
 * The value a user has to hand is usually a provider `baseURL` ending in
 * `/v1`, and the credits route already carries its own `/openrouter/v1`
 * prefix, so pasting one in whole would otherwise produce a doubled path.
 *
 * On a relay-only host that `baseURL` is `<root>/openrouter/v1`, the relay's
 * own route included. Stripping just `/v1` left `<root>/openrouter` and the
 * credits URL then asked for `<root>/openrouter/openrouter/v1/credits`, so the
 * relay path never worked on any machine that used the one value it had.
 * @param base - the configured root, in any of those shapes.
 * @returns the root with no trailing slash, `/v1` or relay route, or undefined when empty.
 */
export declare function normalizeRelayBase(base: string | undefined): string | undefined;
/**
 * Pick the OpenRouter route's `baseURL` out of a provider settings section.
 *
 * Takes `unknown` and narrows defensively: this is another plugin's document,
 * so it may be absent, reshaped, or written by hand, and none of those is a
 * reason to throw where a missing balance will do.
 * @param section - the provider settings section, in whatever state it is in.
 * @returns the route's configured address, or undefined when there is none.
 */
export declare function providerBaseFrom(section: unknown): string | undefined;
/**
 * Decide where the balance comes from on this host.
 *
 * A raw key wins because it needs no second process to be up. The relay is the
 * fallback, and it is a real one: a host that holds no key by design still has
 * a readable balance, which is the whole point of this module.
 *
 * The relay root is looked for in three places, most explicit first: the
 * council's own setting, the environment, and finally the OpenRouter route's
 * configured `baseURL`. That last one is what makes this work out of the box:
 * a relay-only host already points its provider at the relay, and requiring it
 * to write the same address a second time under a different name is how this
 * surface came to be silently dead on the only kind of machine it exists for.
 * @param opts - the key, the relay token, the settings, the environment and the provider route.
 * @returns the source, or undefined when nothing can be read.
 */
export declare function resolveBalanceSource(opts: {
    key?: string | undefined;
    relayToken?: string | undefined;
    relayBase?: string | undefined;
    env?: Readonly<Record<string, string | undefined>> | undefined;
    providerBase?: string | undefined;
}): BalanceSource | undefined;
/**
 * Take one reading of the credits.
 * @param source - where to read from.
 * @param signal - abort signal, from the publisher's lifecycle.
 * @param fetchImpl - injected fetch, for tests.
 * @returns the reading, or undefined on any failure; never throws.
 */
export declare function readCredits(source: BalanceSource, signal?: AbortSignal, fetchImpl?: FetchLike): Promise<CreditsReading | undefined>;
/**
 * Work out what to publish from a reading.
 *
 * Only material change is written: the settings document is user-visible and
 * synchronized, so re-publishing an unchanged balance every poll would churn
 * it for nothing. A failed read writes no figures at all rather than zeros —
 * an unread account must not display as a spent one.
 * @param known - the settings as they stand.
 * @param reading - what was just read, or undefined when the read failed.
 * @param capturedAt - the capture time to stamp a successful reading with.
 * @returns the patch, never empty: it always carries a state.
 */
export declare function balancePatch(known: OpenRouterBalanceFields, reading: CreditsReading | undefined, capturedAt: number): OpenRouterBalanceFields;
/**
 * Start the standing reading: boot read, poll, and a panel's Refresh.
 *
 * Reads are serial, and a Refresh pressed while one is in flight is remembered
 * and served once it ends rather than dropped — from a panel a dropped click
 * is indistinguishable from a dead button. The same reasoning, and the same
 * rising-edge bookkeeping, as the CheaperInference publisher.
 * @param host - settings access, the credentials, and the injected clock and fetch.
 * @returns the disposer, which cancels the poll and awaits the read in flight.
 */
export declare function startOpenRouterBalancePublisher(host: BalanceHost): () => Promise<void>;
/**
 * The host's own credential lookups, kept here so the wiring stays one line.
 * @returns the raw key and the relay token, each undefined when unset.
 */
export declare function hostCredentials(): {
    key: string | undefined;
    relayToken: string | undefined;
};
//# sourceMappingURL=openrouter-balance.d.ts.map