/**
 * What executing a decomposition will cost, before any of it runs.
 *
 * The council's estimator prices a *conversation*: N seats answering one
 * question for a couple of rounds. Execution is a different shape — units of
 * work, run by workers, some of which are paid for by subscription and some
 * metered per token — so it needs its own arithmetic rather than a reused
 * number that happens to be in the same currency.
 *
 * Every figure here is an estimate and says so. The only cost anyone should
 * trust afterwards is the provider's own reported spend.
 */
import type { ModelPrice } from './estimate.ts';
import type { SubTask } from './decompose.ts';
/**
 * How a provider is paid for.
 *
 * `free` and `included` both add nothing to a bill, and collapsing them was
 * the reason a swarm could not be told to run cheaply: a subscription seat and
 * a local-proxy seat sorted identically, so the tie fell to whichever name
 * came first alphabetically and the paid seat took the work. They are separate
 * because the scarce resource is different — the subscription's quota is spent
 * by an `included` unit and is the thing a monthly budget runs out of, while a
 * `free` unit spends nothing but wall clock.
 */
export type CostClass = 
/** No metered cost and no subscription quota: a free tier or a local proxy. */
'free'
/** Absorbed by a subscription already paid for; no metered cost, but its quota is finite. */
 | 'included'
/** Billed per token. */
 | 'metered';
/** One worker provider and how it bills. */
export interface ProviderCost {
    readonly name: string;
    readonly costClass: CostClass;
    /** Model id for price lookup. Metered providers without one cannot be priced. */
    readonly model?: string | undefined;
}
/** Estimated cost of one unit of work. */
export interface TaskCost {
    readonly id: string;
    readonly provider: string;
    readonly costClass: CostClass;
    /** Output tokens assumed for this unit. */
    readonly outputTokens: number;
    /** Estimated USD, or undefined when the provider could not be priced. */
    readonly usd?: number | undefined;
}
/** Estimated cost of a whole decomposition. */
export interface ExecutionEstimate {
    readonly countsCalls?: boolean | undefined;
    readonly tasks: readonly TaskCost[];
    /** Units running concurrently, in execution order. */
    readonly waveSizes: readonly number[];
    /** Sum of every priced unit. */
    readonly meteredUsd: number;
    /** Units carried by a subscription rather than metered spend. */
    readonly includedCount: number;
    /** Units that cost neither money nor subscription quota. */
    readonly freeCount: number;
    /** Units whose provider carries no price, so they are missing from the total. */
    readonly unpricedCount: number;
    /** Caveats the reader must weigh before trusting the figure. */
    readonly caveats: readonly string[];
}
/**
 * Estimate what running a decomposition will cost.
 * @param tasks - the validated task graph.
 * @param providers - providers available, keyed by name.
 * @param pricing - OpenRouter price table.
 * @param fallbackProvider - provider used by units that name none.
 * @returns the estimate and its caveats.
 */
export declare function estimateExecution(tasks: readonly SubTask[], providers: readonly ProviderCost[], pricing: ReadonlyMap<string, ModelPrice>, fallbackProvider: string): ExecutionEstimate;
/**
 * Render an execution estimate for the approval surface.
 * @param estimate - the estimate.
 * @returns markdown lines.
 */
export declare function renderExecutionEstimate(estimate: ExecutionEstimate): readonly string[];
//# sourceMappingURL=execution-cost.d.ts.map