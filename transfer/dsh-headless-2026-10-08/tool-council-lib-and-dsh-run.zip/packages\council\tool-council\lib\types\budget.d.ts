/**
 * Pre-flight budget guard.
 *
 * Checking the live balance before spending beats reconstructing spend
 * afterwards: the provider's own number is authoritative, needs no token
 * arithmetic, and is available before any expensive call is made. The same
 * endpoint read twice also yields the exact cost of a run as a delta.
 */
/** A point-in-time reading of the OpenRouter account. */
export interface Balance {
    /** Credits purchased to date, in USD. */
    readonly purchased: number;
    /** Credits consumed to date, in USD. */
    readonly used: number;
    /** Purchased minus used. */
    readonly remaining: number;
}
/** What the guard decided, and why. */
export interface BudgetDecision {
    /** Whether the run may proceed. */
    readonly allowed: boolean;
    /** Human-readable reason, always populated. */
    readonly reason: string;
    /** The reading the decision was made from, when one could be taken. */
    readonly balance?: Balance | undefined;
    /** Projected spend for the current month at the observed rate. */
    readonly projectedMonthlyUsd?: number | undefined;
    /** True when spend is on track to exceed the monthly target. */
    readonly overPace: boolean;
}
/** Budget limits the guard enforces. */
export interface BudgetLimits {
    /** Refuse to start a run when remaining credit is below this. */
    readonly minBalanceUsd?: number | undefined;
    /** Monthly spend target used for the pace warning. */
    readonly monthlyUsd?: number | undefined;
    /** Day of month used for pace maths; defaults to today. */
    readonly dayOfMonth?: number | undefined;
    /** Days in the current month; defaults to the real value. */
    readonly daysInMonth?: number | undefined;
}
/**
 * Read the current OpenRouter balance.
 * @param apiKey - an inference key; `/credits` accepts one.
 * @param signal - abort signal from the tool execution.
 * @returns the reading, or `undefined` when it could not be taken.
 */
export declare function readBalance(apiKey: string | undefined, signal?: AbortSignal | undefined): Promise<Balance | undefined>;
/**
 * Decide whether a run may proceed against the current balance.
 *
 * An unreadable balance allows the run: a monitoring failure must not become
 * an outage. The pace warning is advisory and never blocks, because month-to-date
 * usage includes spend from outside the council.
 * @param balance - the current reading, or undefined when unavailable.
 * @param limits - configured thresholds.
 * @returns the decision and its reasoning.
 */
export declare function judgeBudget(balance: Balance | undefined, limits?: BudgetLimits): BudgetDecision;
/**
 * Cost of a run, as the difference between two readings.
 * @param before - reading taken before the run.
 * @param after - reading taken after the run.
 * @returns the spend in USD, or undefined when either reading is missing.
 */
export declare function spendBetween(before: Balance | undefined, after: Balance | undefined): number | undefined;
//# sourceMappingURL=budget.d.ts.map