/**
 * Running a request as a swarm, without a council deciding first.
 *
 * The council path exists to settle *what to do* when that is genuinely in
 * doubt, and it costs a full round of drafts and reviews to do it. Plenty of
 * work is not in doubt: the user knows what they want and wants it split
 * across the agents they already configured. Making them buy a debate first
 * would be charging them for an answer they already have.
 *
 * So this path decomposes the request itself, assigns the units across the
 * enabled seats, and stops — the same two-factor gate the council stops at,
 * for the same reason. Nothing here runs a unit until a person has pressed
 * Approve and then spoken. The estimate is shown at that gate rather than
 * after, because a number that arrives afterwards is a bill, not a choice.
 *
 * Workers are seats, not subagent providers. A seat is a one-shot prompt over
 * its own transport, so a unit's worker reads, searches and reports; it does
 * not hold a session and it writes nothing unless the seat's own argv lets it.
 * That is a real ceiling on what this can do, and it is deliberate: the seat
 * roster is the set of agents the user configured, and widening what one may
 * do is a change to that seat, made by the user, not a power this module
 * grants itself.
 */
import type { SubTask } from './decompose.ts';
import type { Assignment } from './roster.ts';
import type { RoleRoute } from './route-council.ts';
import type { SeatState, UnitRoute } from './route-swarm.ts';
import type { ExecutionEstimate } from './execution-cost.ts';
import type { ModelPrice } from './estimate.ts';
import type { SeatConfig } from './seats.ts';
import type { FileSeam } from './files.ts';
import type { Candidate, WriteSeam } from './writes.ts';
/** How a seat's swarm participation is overridden. */
export interface SwarmOverride {
    readonly enabled?: boolean | undefined;
    readonly kinds?: readonly string[] | undefined;
}
/** Everything one swarm run needs. */
export interface SwarmRunOptions {
    readonly profile?: 'economy' | 'fastest' | 'user' | undefined;
    readonly picked?: string | undefined;
    readonly workRoot?: string | undefined;
    readonly writes?: WriteSeam | undefined;
    /** What the user asked for, verbatim. */
    readonly query: string;
    /** Every configured seat, shipped and user-added. */
    readonly seats: readonly SeatConfig[];
    /** Per-seat swarm state, keyed by seat id. */
    readonly overrides: Readonly<Record<string, SwarmOverride>>;
    /**
     * Whether the gate has been passed. False plans and stops; nothing is run
     * and nothing but the one planning call is spent.
     */
    readonly approved: boolean;
    /** OpenRouter key, used only by OpenRouter seats. */
    readonly apiKey?: string | undefined;
    /** OpenRouter price table, for the estimate shown at the gate. */
    readonly pricing: ReadonlyMap<string, ModelPrice>;
    /** Hard cap per seat call. */
    readonly timeoutMs: number;
    /** Seat id that should write the decomposition. */
    readonly planner?: string | undefined;
    /**
     * Seat whose plan won the council vote, when this run follows one.
     *
     * Routing that a user configures is an opinion; routing derived from this is
     * earned by the run itself, which is why the winner is carried here rather
     * than inferred from the roster. It selects the planner when no planner is
     * configured outright, so the seat that argued for the approach is the one
     * that splits it up. In the `fastest` profile it also earns first refusal on
     * `code` units during assignment, ahead of load balancing.
     */
    readonly winner?: string | undefined;
    /**
     * Agents whose samples the user kept, in the order they kept them.
     *
     * Stronger than {@link SwarmOptions.winner} and earned differently: a winner
     * won a vote among seats, and these were chosen by the person the work is
     * for, from samples they read. So they take first refusal on EVERY kind of
     * unit they can accept rather than on `code` alone, and they take it in any
     * profile — the preference is the user's decision, not a speed setting, and
     * dropping it because the run is economical would quietly build the product
     * with the agents whose samples were passed over.
     */
    readonly chosen?: readonly string[] | undefined;
    /**
     * The graph to run, when one was already approved.
     *
     * An approved run MUST NOT decompose again. Re-planning would produce a
     * different graph from the one the user read and approved, so the approval
     * would be carrying work nobody saw. Supplying the stored graph is also what
     * makes approval cost nothing: the planning call was already paid for before
     * the gate.
     */
    readonly tasks?: readonly SubTask[] | undefined;
    /** Run units one at a time instead of a wave at a time. */
    readonly sequential?: boolean | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly memory?: {
        file?: string | undefined;
        text?: string | undefined;
    } | undefined;
    readonly webMaxResults?: number | undefined;
    /**
     * File seam used to serve paths a unit asks for. A worker never reads for
     * itself; it names a path and this reads it, or refuses.
     */
    readonly files?: FileSeam | undefined;
    /** Absolute directories a unit may be shown files from. */
    readonly fileRoots?: readonly string[] | undefined;
    /** Results already completed by an interrupted attempt. Successful units are never asked again. */
    readonly previousResults?: readonly SwarmUnitResult[] | undefined;
    /**
     * Live seat state, keyed by seat id. A seat reported down or out of quota is
     * held out of this run by the router's hard filter; absent means no evidence.
     */
    readonly seatState?: Readonly<Record<string, SeatState>> | undefined;
    /** Optional product verification supplied by the host or a focused test. */
    readonly verifyUnit?: ((result: SwarmUnitResult) => Promise<readonly string[]>) | undefined;
}
/** What one worker did with one unit. */
export interface SwarmUnitResult {
    readonly candidates?: readonly Candidate[] | undefined;
    readonly review?: string | undefined;
    readonly task: SubTask;
    /** Seat id that ran it. */
    readonly seat: string;
    readonly text: string;
    readonly error?: string | undefined;
    readonly ms: number;
    /** Contest units only: author and reviewer beside the router's shadow picks. */
    readonly route?: readonly RoleRoute[] | undefined;
}
/** How far a swarm run got, and why it stopped there. */
export type SwarmPhase = 
/** Decomposed and priced, waiting at the approval gate. Nothing ran. */
'plan'
/** Could not proceed: no worker, no usable graph, or no planner. */
 | 'blocked'
/** Units ran. */
 | 'full'
/** Some work landed, but failed/missing/unverified units remain resumable. */
 | 'partial';
/** The outcome of one swarm run. */
export interface SwarmResult {
    readonly phase: SwarmPhase;
    readonly query: string;
    readonly tasks: readonly SubTask[];
    /** Faults that make the graph unsafe to run. Non-empty means blocked. */
    readonly problems: readonly string[];
    readonly assignments: readonly Assignment[];
    readonly estimate?: ExecutionEstimate | undefined;
    readonly results: readonly SwarmUnitResult[];
    /** Per-unit routing trace: the seat chosen, the router's shadow pick, and every rejection. */
    readonly routes?: readonly UnitRoute[] | undefined;
    /** Markdown for the main window. */
    readonly report: string;
}
/**
 * The prompt one worker gets for one unit.
 *
 * A worker has not read the conversation and never sees the other workers, so
 * everything it needs travels here: the original request for context, its own
 * unit, and the reports of the units it depends on. Dependency output is
 * included rather than summarised — a worker asked to build on a result it
 * cannot see will invent one.
 * A worker that may ask for files is told so here, and told how. It gets one
 * chance to ask: the reply naming paths is answered with their contents and
 * the unit is put again. Asking therefore costs a second call, and only for
 * the units that actually ask — which is why it is not a round of its own.
 * @param query - the original request.
 * @param task - the unit to do.
 * @param done - results of units already finished.
 * @param roots - directories the worker may ask to be shown files from.
 * @param files - file evidence already served to this worker, when re-asking.
 * @returns the prompt.
 */
export declare function unitPrompt(query: string, task: SubTask, done: readonly SwarmUnitResult[], roots?: readonly string[], files?: string): string;
/**
 * Decompose a request, assign it across the seats, and — once approved — run it.
 *
 * Stops at the gate by default. The one call it makes before the gate is the
 * decomposition itself, which is what makes the estimate mean anything; that
 * cost is real and is why the planner prefers a seat whose price is known.
 * @param options - the request, the seats, and whether the gate has passed.
 * @returns what happened, and the report to show.
 */
export declare function runSwarm(options: SwarmRunOptions): Promise<SwarmResult>;
//# sourceMappingURL=swarm.d.ts.map