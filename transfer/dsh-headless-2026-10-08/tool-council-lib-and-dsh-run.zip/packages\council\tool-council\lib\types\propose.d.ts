/**
 * The proposing round: every seat writes the same change, separately.
 *
 * One model writing code is one model's blind spots. Four writing the same
 * change independently, into trees that cannot see each other, gives the
 * selection round something real to choose between — and a seat that
 * misunderstood the task shows up as a candidate nobody votes for rather than
 * as a commit somebody has to find later.
 *
 * Nothing here touches a repository. Each seat's work lands under its own root
 * and stays there until a person implements the winner. That is the whole
 * safety property: the round can be run, read and thrown away at no cost
 * beyond the tokens it spent.
 *
 * Seats read through the same broker they use everywhere else, so a seat can
 * ask for the file it is about to rewrite. It gets one such request, for the
 * same reason a swarm unit does: each is another paid call.
 */
import type { SeatConfig } from './seats.ts';
import type { FileSeam } from './files.ts';
import type { Candidate, WriteSeam } from './writes.ts';
import type { SelectionResult } from './select.ts';
/** How far a proposing run got. */
export type ProposePhase = 
/** Priced and waiting at the approval gate. Nothing ran. */
'plan'
/** Could not proceed. */
 | 'blocked'
/** Seats proposed, and the selection round ran. */
 | 'full';
/** Everything one proposing run needs. */
export interface ProposeOptions {
    /** What the seats should implement, in the user's own terms. */
    readonly task: string;
    /** Every configured seat. */
    readonly seats: readonly SeatConfig[];
    /** Absolute source roots the change targets. */
    readonly fileRoots: readonly string[];
    /** Directory under which each seat's own tree is created. */
    readonly workRoot: string;
    /** Whether the gate has been passed. */
    readonly approved: boolean;
    readonly files: FileSeam;
    readonly writes: WriteSeam;
    readonly apiKey?: string | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly timeoutMs: number;
    readonly sequential?: boolean | undefined;
    readonly memory?: {
        file?: string | undefined;
        text?: string | undefined;
    } | undefined;
    readonly webMaxResults?: number | undefined;
    /** Run id, so a second run does not overwrite the first. Generated when absent. */
    readonly runId?: string | undefined;
    /**
     * Whether the seats vote on the versions once they are written. Default true.
     *
     * False is the sampling round: the same seats write the same way into the
     * same sandboxed trees, and nobody is asked which one is best. That question
     * belongs to the user in a workflow where the user is the selector, and a
     * vote taken before they have looked is a vote whose only effect is to bias
     * them — it also costs one call per seat to produce an answer that has no
     * standing. Turning it off changes nothing about the writing itself, which
     * is why this is a flag and not a second round.
     */
    readonly vote?: boolean | undefined;
}
/** The outcome of one proposing run. */
export interface ProposeResult {
    readonly phase: ProposePhase;
    readonly task: string;
    readonly runId: string;
    readonly candidates: readonly Candidate[];
    readonly selection?: SelectionResult | undefined;
    /** Seats that were asked but produced nothing usable. */
    readonly silent: readonly string[];
    readonly report: string;
}
/**
 * The prompt asking one seat to write its version of the change.
 * @param task - what to implement.
 * @param roots - source roots, for both reading and targeting.
 * @param files - file evidence already served, when re-asking.
 * @returns the prompt.
 */
export declare function proposePrompt(task: string, roots: readonly string[], files?: string): string;
/**
 * Ask every enabled seat to write the change, then pick a winner.
 * @param options - the task, the seats, and where their trees go.
 * @returns the candidates, the selection, and a report.
 */
export declare function runPropose(options: ProposeOptions): Promise<ProposeResult>;
//# sourceMappingURL=propose.d.ts.map