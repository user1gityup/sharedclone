/**
 * Weighting: which of the eligible candidates is best for this role.
 *
 * Weights rank; they never admit. Anything scored here has already passed the
 * hard filter, so a policy that prefers free workers cannot thereby hand work
 * to one that is unauthorized, exhausted or incapable.
 *
 * Zero marginal cost is a factor, not a verdict. A local worker at 25 tokens a
 * second is genuinely free and genuinely slow, and the only honest comparison
 * is estimated total completion time against a subscription seat's — which is
 * why `speed` is normalized against the fastest eligible candidate rather than
 * against a constant.
 */
import type { Candidate, RoleRequirement, RoutingContext, RoutingPolicy, ScoreFactors } from './types.ts';
/**
 * The weights a policy applies, exposed so a caller can show why a route was chosen.
 * @param policy - the routing policy to look up.
 * @returns that policy's per-factor weights, summing to 1.
 */
export declare function policyWeights(policy: RoutingPolicy): ScoreFactors;
/**
 * How far above the bar a candidate is for this role.
 *
 * Meeting every requirement exactly scores 0.5; the rest of the range rewards
 * headroom, so a `high` reasoner still beats a `medium` one when both qualify.
 * A role with no stated capabilities scores 0.5, because nothing distinguishes
 * the field.
 * @param candidate - the candidate whose offered levels to compare.
 * @param role - the role whose required capability levels set the bar.
 * @returns the capability factor, from 0 to 1, averaged across the role's required capabilities.
 */
export declare function capabilityFit(candidate: Candidate, role: RoleRequirement): number;
/**
 * How good this candidate looks on cost alone.
 *
 * The three tiers are deliberately far apart rather than proportional, because
 * the resources are not commensurable. Local and free spend nothing at all. A
 * subscription spends a quota that is finite, shared by every user and gone
 * for the month once used, so it sits well below free even though no invoice
 * arrives. Metered spend ranks last and is then ordered by price among the
 * metered candidates themselves.
 * @param costClass - the candidate's cost class.
 * @param usd - the candidate's estimated spend for this role.
 * @param worstUsd - the highest estimated spend among the eligible field, for normalizing metered candidates.
 * @returns the cost factor, from 0 to 1: 1 for zero-marginal-cost, 0.6 for `included`, otherwise scaled against `worstUsd`.
 */
export declare function costFactor(costClass: Candidate['costClass'], usd: number, worstUsd: number): number;
/** Normalizing context shared by every candidate for one role. */
export interface ScoreBaseline {
    /** Fastest estimated completion among the eligible candidates, in seconds. */
    readonly bestSeconds: number;
    /** Highest estimated spend among them, in USD. */
    readonly worstUsd: number;
}
/**
 * Work out the baseline from the eligible field.
 * @param candidates - the eligible candidates for the role.
 * @param role - the role being sized.
 * @param context - the run's routing context, for the default output estimate.
 * @returns the fastest completion time and highest spend across the field, for normalizing each candidate's factors.
 */
export declare function baselineFor(candidates: readonly Candidate[], role: RoleRequirement, context: RoutingContext): ScoreBaseline;
/**
 * Every factor for one candidate, each from 0 to 1.
 * @param candidate - the candidate to score.
 * @param role - the role being filled.
 * @param context - the run's routing context, for the default output estimate and latency budget.
 * @param baseline - the eligible field's fastest completion and highest spend, from `baselineFor`.
 * @returns the candidate's raw per-factor scores, ready to weight with `scoreOf`.
 */
export declare function factorsFor(candidate: Candidate, role: RoleRequirement, context: RoutingContext, baseline: ScoreBaseline): ScoreFactors;
/**
 * Combine the factors under a policy's weights.
 * @param factors - the candidate's per-factor scores, from `factorsFor`.
 * @param policy - the routing policy whose weights to apply.
 * @returns the weighted sum: the candidate's overall score under that policy.
 */
export declare function scoreOf(factors: ScoreFactors, policy: RoutingPolicy): number;
//# sourceMappingURL=score.d.ts.map