import type { Context } from '@deepseek-ai/cordis';
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { SandboxPolicyService } from '@deepseek-ai/dsh-sandbox-policy';
import type { Session } from '@deepseek-ai/dsh-session';
import type { WriteSeam } from './writes.ts';
/**
 * Route proposal writes through the active session's sandbox on every file.
 * @param fs - mounted confined filesystem.
 * @param policy - deployment policy and write gate.
 * @param session - session owning this batch, captured before asynchronous work.
 * @returns a writer that never grants itself broader access.
 */
export declare function sandboxWriteSeam(fs: FileSystem, policy: SandboxPolicyService, session: Session): WriteSeam;
/**
 * Validate a complete staging batch before creating any file.
 * @param json - object mapping portable relative file paths to full contents.
 * @returns validated file entries.
 */
export declare function parseStagingFiles(json: string): [string, string][];
/**
 * Register the no-CLI route for API agents to leave code for later implementation.
 * @param ctx - context with tool registry, agents, filesystem and sandbox policy.
 */
export declare function registerStaging(ctx: Context): void;
//# sourceMappingURL=staging.d.ts.map