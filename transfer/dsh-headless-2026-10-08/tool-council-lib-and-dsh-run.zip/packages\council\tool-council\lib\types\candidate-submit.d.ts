/**
 * The seam between a swarm's staged candidates and the host's commit path.
 *
 * A contested unit already writes its winner's files somewhere real: under
 * `.dsh-staging`, in a tree belonging to the seat that wrote them. That is
 * where every swarm run has ended. Turning staged candidates into a commit was
 * a step a person did by hand, which in practice meant it was not done, and a
 * run that produced code looked exactly like a run that produced nothing.
 *
 * Both halves of the journey already existed and neither could see the other:
 * `writes.ts` produces the candidates, `host-commit.ts` commits a map of paths
 * to contents. This reads the winners back off disk into that map.
 *
 * Nothing here grants anything new. The files were written through the
 * sandbox's own write seam, under roots the run was already granted; the host
 * still refuses hooks, manifests and secret-shaped content; and the commit
 * still lands on a fresh branch that only the user can push. What changes is
 * that the work stops evaporating between the two.
 */
import type { Candidate } from './writes.ts';
/**
 * The part of a finished unit this seam reads.
 *
 * Declared structurally rather than imported from the swarm, so the seam can
 * be tested without standing up a run, and so the swarm keeps knowing nothing
 * about commits.
 */
export interface UnitOutcome {
    readonly task: {
        readonly id: string;
    };
    /** Seat whose artifact the unit chose. */
    readonly seat: string;
    readonly error?: string | undefined;
    readonly candidates?: readonly Candidate[] | undefined;
}
/** One unit's chosen candidate. */
export interface WinningCandidate {
    /** Unit id, for the commit message and for naming a collision. */
    readonly unit: string;
    readonly candidate: Candidate;
}
/**
 * Pick out the candidate each unit actually chose.
 *
 * A contest stages every proposer's tree, not just the winner's, so the seat
 * recorded on the result is the only thing that says which one passed review.
 * Committing the rest would commit work nothing accepted. A failed unit
 * contributes nothing at all: its files are the half-finished ones.
 * @param results - finished units, in the order the swarm ran them.
 * @returns the winning candidate of every unit that produced files.
 */
export declare function winningCandidates(results: readonly UnitOutcome[]): readonly WinningCandidate[];
/**
 * Read the winning candidates back into the files map the host commits.
 *
 * Two units writing the same file is refused rather than resolved. Either
 * order is a guess, and the wrong guess is a file silently missing half its
 * change — the decomposition is what needs fixing, so it is what gets named.
 * The link check is the one `readStagedBatch` makes for the other route into
 * the host, kept here for the same reason: a staged tree is written by the
 * sandbox seam, but the place that reads it back is the wrong place to assume
 * only the sandbox has ever touched it.
 * @param winners - the chosen candidates, from `winningCandidates`.
 * @returns JSON object mapping repository-relative paths to contents.
 */
export declare function candidateFilesJson(winners: readonly WinningCandidate[]): Promise<string>;
/**
 * The seat recorded as the commit's author.
 *
 * One commit carries one model id, and a swarm is several. The seat that wrote
 * the most of it is the least misleading single answer, and the message below
 * names every one of them anyway. Ties settle on the seat id so the same run
 * always produces the same branch name.
 * @param winners - the chosen candidates.
 * @returns the seat id to record, or undefined when there is nothing to record.
 */
export declare function authoringSeat(winners: readonly WinningCandidate[]): string | undefined;
/**
 * The commit message for one submitted swarm run.
 *
 * The body is the audit trail the run records nowhere else: which unit wrote
 * which file, and which seat wrote the unit.
 * @param query - the request the swarm was given.
 * @param winners - the chosen candidates.
 * @returns subject and body, ready for the host.
 */
export declare function submissionMessage(query: string, winners: readonly WinningCandidate[]): string;
//# sourceMappingURL=candidate-submit.d.ts.map