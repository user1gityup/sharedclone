/**
 * The council → propose → swarm → council chain, as one resumable run.
 *
 * Each of the tools already works alone, and stringing them together by asking
 * the model to call them in order is what this replaces. That version has no
 * memory: nothing carries the agreed approach into the decomposition, nothing
 * carries the units' output into the review, and a model that forgets a stage
 * simply does not run it. Here the stage is durable state, so the chain is a
 * fact about the run rather than a hope about the model.
 *
 * One call advances ONE stage. That is deliberate: every stage spends, and a
 * call that could spend three times over is a call no gate can price. Between
 * stages the run sits in settings, which is also what makes it survivable —
 * see the hold below.
 *
 * **The stage list belongs to the run, not to this module.** A run that only
 * has to decide something wants council → swarm → review; a run that has to
 * BUILD something wants a proposing stage in the middle, where every seat
 * writes its own version of the change into a tree of its own and the user
 * picks between them before any work is split up. Hard-coding one order made
 * the second kind impossible to express: a request that described its own
 * stages in prose got the three-stage chain anyway, and the samples it asked
 * for had nowhere to come from. So the order is data now, carried in the state
 * and validated on the way in, and {@link PIPELINE_STAGES} is only the default.
 *
 * **A spent quota holds the run; it never fails it.** A seat that runs out of
 * subscription allowance has produced no work and lost none: the approved
 * graph, the plan it came from and the units already finished all stay exactly
 * where they are, and the run resumes at the same stage once the window rolls
 * over. Treating exhaustion as failure would throw away an approval the user
 * paid a planning call for, and charge them a second one to get back.
 */
import type { QuotaHold } from './quota-hold.ts';
import type { SubTask } from './decompose.ts';
import type { SampleSelection } from './sample-select.ts';
import type { SwarmUnitResult } from './swarm.ts';
/** Every stage the chain knows how to run, in their natural order. */
export declare const ALL_PIPELINE_STAGES: readonly ["council", "sample", "propose", "select", "swarm", "review"];
/** One stage of the chain. */
export type PipelineStage = (typeof ALL_PIPELINE_STAGES)[number];
/**
 * The default order: decide, split, review.
 *
 * Kept as the default rather than the only order because it is what a run that
 * answers a question wants, and because every run stored before the order
 * became configurable is one of these.
 */
export declare const PIPELINE_STAGES: readonly ["council", "swarm", "review"];
/**
 * The order a build wants: decide, write competing versions, split, review.
 *
 * The proposing stage sits between the decision and the work because that is
 * the only point where choosing is cheap. Once the swarm has split the job the
 * choice has already been made implicitly by whoever wrote the graph.
 */
export declare const BUILD_PIPELINE_STAGES: readonly ["council", "propose", "swarm", "review"];
/**
 * The order a run takes when the user, not a council, is the selector.
 *
 * No council at either end, and that is the whole point rather than an
 * economy. A council in front decides the approach before anything has been
 * seen, which is exactly the decision the user wanted to make from real
 * samples; a council at the back reviews work whose direction the user already
 * chose, and its only power is to disagree with them. What is left is the
 * three things that actually have to happen: everyone writes a sample at once,
 * the user walks them one at a time, and the ones they kept build the product.
 *
 * `sample` rather than `propose` because the proposing stage ends in a vote —
 * see {@link ALL_PIPELINE_STAGES}. Same writing round, no ballot.
 */
export declare const SWARM_SELECT_BUILD_STAGES: readonly ["sample", "select", "swarm"];
/**
 * Stage orders that have a name, so a run can ask for one without spelling it.
 *
 * A saved run that lists its stages is a run that has to be edited in four
 * places when an order changes, and a run that names a strategy is not. The
 * names are the user-facing vocabulary: `SWARM_SELECT_BUILD` is what the
 * amendment that asked for it calls the workflow, and a setting that reads
 * back as the word the user used is a setting they can check.
 */
export declare const PIPELINE_STRATEGIES: Readonly<Record<string, readonly PipelineStage[]>>;
/**
 * Read a stage list written as text, e.g. `council,propose,swarm,review`, or
 * as the name of a strategy, e.g. `SWARM_SELECT_BUILD`.
 *
 * A strategy name is matched first and case-insensitively, because it is a
 * whole list and a list is what the caller wanted; only text that names no
 * strategy is read as stages. Unknown stage names are dropped rather than
 * rejected: a list that names one stage this build does not have should still
 * run the stages it does, and a run is worse off stopped than shortened. An
 * empty result falls back to the default, so a typo can never produce a chain
 * with nothing in it.
 * @param text - a strategy name, or comma/space separated stage names in order.
 * @returns the stages, or the default when none survive.
 */
export declare function parseStages(text: string | undefined): readonly PipelineStage[];
/** How a call ended. */
export type PipelinePhase = 
/** A stage ran and the next one is waiting at its gate. */
'staged'
/** Every stage is done. */
 | 'done'
/** Parked on a spent allowance. Nothing was lost and nothing was spent. */
 | 'held'
/** Cannot proceed for a reason waiting will not fix. */
 | 'blocked';
/** One stage of the chain that has finished. */
export interface StageRecord {
    readonly stage: PipelineStage;
    /** The stage's own report, as shown when it ran. */
    readonly text: string;
    /** Epoch ms the stage finished. */
    readonly at: number;
}
/**
 * One seat's sandboxed version of the change, as the chain carries it.
 *
 * Only what a later stage or a person needs to find the tree again: the code
 * itself stays on disk under the seat's own root, because a chain state that
 * carried file bodies would put tens of thousands of characters into settings,
 * which is read whole on every tool invocation.
 */
export interface PipelineCandidate {
    /** Seat that wrote it. */
    readonly seat: string;
    /** Absolute root the seat's files were written under. */
    readonly root: string;
    /** How many files it wrote. */
    readonly files: number;
}
/**
 * The run, as it survives between calls.
 *
 * Serialised into settings by the caller. Every field is optional but `id` and
 * `query`: a run that has only just started has nothing else yet, and a state
 * that cannot be partially filled cannot be resumed.
 */
export interface PipelineState {
    readonly id: string;
    readonly query: string;
    /** The stage the NEXT call will run. */
    readonly stage: PipelineStage;
    /**
     * The order this run advances through. Absent means {@link PIPELINE_STAGES},
     * which is what every run stored before the order was configurable has.
     */
    readonly stages?: readonly PipelineStage[] | undefined;
    /** The approach the council agreed, carried into every stage after it. */
    readonly plan?: string | undefined;
    /**
     * Seat whose plan won the vote, carried into every stage after it.
     *
     * The approach alone says what to do; this says who worked it out. A later
     * stage that has to pick a seat for a job — writing the decomposition, above
     * all — should route on what the run earned rather than on a configured
     * preference, and that is only possible if the winner survives the stage
     * boundary the way the approach does.
     */
    readonly winner?: string | undefined;
    /** The approved graph, stored verbatim so it is never re-planned. */
    readonly tasks?: readonly SubTask[] | undefined;
    /** Sandboxed versions the proposing stage wrote, carried into the swarm. */
    readonly candidates?: readonly PipelineCandidate[] | undefined;
    /**
     * What the user kept, and what they kept out of it, from the selecting stage.
     *
     * Carried on the run rather than derived when needed because it is the one
     * thing in the chain that cannot be recomputed: every other field is the
     * output of a call that could be made again, and this is a person's taste.
     */
    readonly selections?: readonly SampleSelection[] | undefined;
    /** What the workers reported, carried into the review. */
    readonly units?: readonly SwarmUnitResult[] | undefined;
    /** Finished stages, oldest first. */
    readonly records?: readonly StageRecord[] | undefined;
    /** Set while parked on a spent allowance. */
    readonly hold?: QuotaHold | undefined;
}
/** What one stage runner is handed. */
export interface StageInput {
    readonly query: string;
    /** The council's agreed approach; absent at stage one. */
    readonly plan?: string | undefined;
    /** The seat whose plan won; absent at stage one, or when no vote settled. */
    readonly winner?: string | undefined;
    /** The approved graph; present for the swarm stage once approved. */
    readonly tasks?: readonly SubTask[] | undefined;
    /** The sandboxed versions; present once a proposing stage has run. */
    readonly candidates?: readonly PipelineCandidate[] | undefined;
    /** What the user kept; present once a selecting stage has finished. */
    readonly selections?: readonly SampleSelection[] | undefined;
    /** What the workers reported; present at the review stage. */
    readonly units?: readonly SwarmUnitResult[] | undefined;
}
/** What a stage runner gives back. */
export interface StageOutput {
    /** Markdown for the main window. */
    readonly report: string;
    /** True when the stage did its work; false when it stopped at its own gate. */
    readonly complete: boolean;
    /** Calls that failed, so exhaustion can be told from a fault. */
    readonly failures?: readonly {
        readonly seat?: string | undefined;
        readonly error: string;
    }[] | undefined;
    /** Reasons the stage cannot proceed at all. */
    readonly problems?: readonly string[] | undefined;
    /** The approach, when the council stage produced one. */
    readonly plan?: string | undefined;
    /** The winning seat, when the council stage's vote settled on one. */
    readonly winner?: string | undefined;
    /** The graph, when the swarm stage produced or ran one. */
    readonly tasks?: readonly SubTask[] | undefined;
    /** The sandboxed versions, when the proposing or sampling stage wrote any. */
    readonly candidates?: readonly PipelineCandidate[] | undefined;
    /** The verdicts, when the selecting stage recorded any. */
    readonly selections?: readonly SampleSelection[] | undefined;
    /** Unit results, when the swarm stage ran. */
    readonly units?: readonly SwarmUnitResult[] | undefined;
    /** A completed final review explicitly rejected the product and sends it back to rework. */
    readonly rework?: boolean | undefined;
}
/** Everything a call needs beyond the state itself. */
export interface PipelineOptions {
    readonly state: PipelineState;
    /** Runs one stage. Injected so the chain can be tested without spending. */
    readonly runStage: (stage: PipelineStage, input: StageInput) => Promise<StageOutput>;
    /** Epoch ms, injectable for tests. */
    readonly now?: number | undefined;
    /**
     * Latest known session usage, when a quota reading exists. Used only to
     * release a hold early, never to impose or extend one.
     */
    readonly sessionPercent?: number | undefined;
}
/** What a call did. */
export interface PipelineResult {
    readonly phase: PipelinePhase;
    readonly state: PipelineState;
    /** Markdown for the main window. */
    readonly report: string;
}
/**
 * The order a run advances through, defaulted for runs stored before the order
 * was data.
 * @param state - the run.
 * @returns its stage list.
 */
export declare function stagesOf(state: PipelineState): readonly PipelineStage[];
/**
 * The stage after this one, or undefined at the end of the chain.
 * @param stage - the stage that just finished.
 * @param stages - the order this run advances through.
 * @returns the next stage.
 */
export declare function nextStage(stage: PipelineStage, stages?: readonly PipelineStage[]): PipelineStage | undefined;
/**
 * Start a run. Nothing has been spent at this point.
 * @param id - the run's id, used by the gate controls.
 * @param query - the user's request, in their own words.
 * @param stages - the order to advance through; defaults to the three-stage chain.
 * @returns the state a first call will advance.
 */
export declare function startPipeline(id: string, query: string, stages?: readonly PipelineStage[]): PipelineState;
/**
 * Advance a run by one stage.
 *
 * Four things can happen, and only one of them spends: the run is held and
 * stays held; the stage runs and the chain moves on; the stage runs out of
 * allowance and the run parks unchanged; or the stage reports a problem
 * waiting cannot fix and the run stops.
 * @param options - the state, the stage runner, and the clock.
 * @returns the new state and what to show.
 */
export declare function runPipeline(options: PipelineOptions): Promise<PipelineResult>;
/**
 * Whether the run a stage belongs to was stopped from the panel while the
 * stage was running.
 *
 * The panel's Stop clears the run in settings and records its id. A stage
 * already in flight returns afterwards and would write its state back, which
 * brings the stopped run back to life and hides the saved runs again. Checked
 * against settings read AFTER the stage, never the snapshot taken before it.
 * @param runId - the id of the run this call advanced.
 * @param stoppedId - `pipelineStoppedId` as it stands now.
 * @returns true when the write-back must be skipped.
 */
export declare function stoppedDuring(runId: string, stoppedId: string | undefined): boolean;
//# sourceMappingURL=pipeline.d.ts.map