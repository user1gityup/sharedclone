/**
 * CheaperInference budget surface.
 *
 * The readers in `cheaperinference.ts` answer one question each — what is in
 * the wallet, what the window cost — and the council calls them when a run is
 * about to spend. This module turns them into a standing reading: a poll, a
 * Refresh the panel can press, a capture time, and a state the panel can show
 * while a read is in flight.
 *
 * Every call here is free (catalogue, `/account/balance`, `/account/usage`
 * bill nothing and consume no tokens), which is why a timer is allowed at all.
 * The Claude quota surface deliberately has none: there a reading costs a
 * request against the user's own allowance.
 *
 * The key never leaves the host. The panel is a browser and only ever sees the
 * figures published into the council's settings namespace.
 */
import type { FetchLike, UsageWindow, Wallet } from './cheaperinference.ts';
/** Default poll period; the provider's figures do not move faster than this. */
export declare const BUDGET_POLL_MS = 300000;
/**
 * The settings fields this surface reads and writes.
 *
 * All flat scalars: the settings document holds no nested values, so the
 * window's per-model breakdown travels as one JSON string.
 */
export interface BudgetFields {
    /** Model ids the provider serves, cheapest output price first. */
    cheaperInferenceModels?: string[] | undefined;
    /** Spendable balance — the wallet minus holds against requests in flight. */
    cheaperInferenceWalletUsd?: number | undefined;
    /** Wallet balance before those holds. */
    cheaperInferenceBalanceUsd?: number | undefined;
    /** Held against requests in flight. */
    cheaperInferenceReservedUsd?: number | undefined;
    /** Whether the provider tops the wallet up on its own. */
    cheaperInferenceAutoRecharge?: boolean | undefined;
    /** What the discount saved over the usage window, in USD. */
    cheaperInferenceSavedUsd?: number | undefined;
    /** That saving as a percentage of list price. */
    cheaperInferenceSavingsPercent?: number | undefined;
    /** Length of the usage window in days. */
    cheaperInferenceUsageDays?: number | undefined;
    /** What the account was billed over the window. */
    cheaperInferenceBilledUsd?: number | undefined;
    /** Requests in the window. */
    cheaperInferenceRequestCount?: number | undefined;
    /** The window's biggest spenders, as JSON: `[{model, requestCount, billedUsd}]`. */
    cheaperInferenceTopModelsJson?: string | undefined;
    /** Last successful capture, in epoch milliseconds. */
    cheaperInferenceCapturedAt?: number | undefined;
    /** idle, running, ok, or failed. */
    cheaperInferenceBudgetState?: string | undefined;
    /** Poll period in milliseconds; zero polls only at boot and on Refresh. */
    cheaperInferenceBudgetPollMs?: number | undefined;
    /** Monotonic refresh request from the panel. */
    cheaperInferenceRefreshRequestedAt?: number | undefined;
}
/** One reading of the account, with each part absent when it could not be read. */
export interface BudgetReading {
    /** Catalogue ids, empty when the catalogue could not be read. */
    readonly models: readonly string[];
    /** The wallet, absent when the key lacks `account:read` or the call failed. */
    readonly wallet?: Wallet | undefined;
    /** The usage window, absent for the same reasons. */
    readonly usage?: UsageWindow | undefined;
}
/** Everything the publisher needs from the host, so tests need no host at all. */
export interface BudgetHost {
    /** The current settings, as the panel sees them. */
    live: () => BudgetFields;
    /** Publish a patch; rejections are treated as a read-only settings provider. */
    update: (patch: BudgetFields) => Promise<void>;
    /** Observe settings changes, for the panel's Refresh. Returns an unwatch. */
    watch?: ((listener: (next: BudgetFields) => void) => () => void) | undefined;
    /** The account key, or undefined when none is configured. */
    key: () => string | undefined;
    /** Injected fetch, for tests. */
    fetchImpl?: FetchLike | undefined;
    /** Injected clock, for tests. */
    now?: (() => number) | undefined;
}
/**
 * Take one reading of the account.
 *
 * The three calls are independent: a key scoped for chat but not for
 * `account:read` still yields a catalogue, and publishing that alone is what
 * lets the panel tell "no key" apart from "key without the scope".
 * @param apiKey - the account's key.
 * @param signal - abort signal, from the publisher's lifecycle.
 * @param fetchImpl - injected fetch, for tests.
 * @returns whatever could be read; never throws.
 */
export declare function readBudget(apiKey: string | undefined, signal?: AbortSignal, fetchImpl?: FetchLike): Promise<BudgetReading>;
/**
 * Work out what to publish from a reading.
 *
 * Only material change is written: the settings document is user-visible and
 * synchronized, so re-publishing an unchanged wallet on every poll would churn
 * it for nothing. An unreadable figure writes nothing at all rather than a
 * zero — an unread wallet must not display as a spent account.
 * @param known - the settings as they stand.
 * @param reading - what was just read.
 * @param capturedAt - the capture time to stamp a successful reading with.
 * @returns the patch, empty when nothing moved.
 */
export declare function budgetPatch(known: BudgetFields, reading: BudgetReading, capturedAt: number): BudgetFields;
/**
 * Start the standing reading: boot read, poll, and the panel's Refresh.
 *
 * Reads are serial. A Refresh pressed while one is in flight is remembered and
 * served once it ends rather than dropped, because from the panel a dropped
 * click is indistinguishable from a dead button.
 * @param host - settings access, the key, and the injected clock and fetch.
 * @returns the disposer, which cancels the poll and awaits the read in flight.
 */
export declare function startBudgetPublisher(host: BudgetHost): () => Promise<void>;
//# sourceMappingURL=cheaperinference-budget.d.ts.map