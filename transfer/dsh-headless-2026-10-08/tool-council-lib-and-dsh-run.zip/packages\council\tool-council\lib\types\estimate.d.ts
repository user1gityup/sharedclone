/**
 * Cost estimation for the planning gate.
 *
 * This is a guess and is labelled as one everywhere it surfaces. A model that
 * decides mid-run to enumerate a million digits will blow through any estimate
 * made before it started. The estimate exists to catch the obvious cases —
 * "this looks like a large job and you have $4 left" — not to be accurate.
 *
 * Two inputs feed it: the planner's own size judgement, and what comparable
 * runs actually cost. History wins when it exists, because a measured average
 * beats a model's self-assessment.
 */
import type { SeatConfig } from './seats.ts';
/** Coarse size bands the planner may report. */
export declare const scales: readonly ["small", "medium", "large", "huge"];
/** One coarse size band. */
export type Scale = (typeof scales)[number];
/** What the planner said about the job's size. */
export interface PlanScale {
    readonly scale: Scale;
    /** Output tokens the planner expects one seat to produce. */
    readonly outputTokens: number;
    /** True when the planner supplied a number rather than only a band. */
    readonly explicit: boolean;
}
/**
 * Read the size block out of a plan.
 *
 * Tolerant like the vote parser: a plan that ignores the format still yields a
 * usable band, defaulting to medium rather than refusing to estimate.
 * @param text - the planner's reply.
 * @returns the parsed size judgement.
 */
export declare function parsePlanScale(text: string): PlanScale;
/** Per-token prices for one model, in USD. */
export interface ModelPrice {
    readonly prompt: number;
    readonly completion: number;
}
/**
 * Fetch OpenRouter's public price table.
 *
 * Unauthenticated and free, so it costs nothing to consult before deciding
 * whether a run is affordable.
 * @param signal - abort signal from the tool execution.
 * @returns model id → price, or an empty map when unavailable.
 */
export declare function fetchModelPricing(signal?: AbortSignal | undefined): Promise<ReadonlyMap<string, ModelPrice>>;
/** What a past run actually cost, used to calibrate. */
export interface RunHistory {
    /** Metered cost of one completed full run. */
    readonly costUsd: number;
}
/** One seat's share of the estimate. */
export interface SeatEstimate {
    readonly seat: string;
    readonly name: string;
    /** Undefined for CLI seats, whose spend this process cannot observe. */
    readonly costUsd?: number | undefined;
    /** True when the seat bills a subscription rather than credits. */
    readonly metered: boolean;
}
/** The complete pre-flight estimate. */
export interface RunEstimate {
    /** Total metered cost expected, in USD. */
    readonly meteredCostUsd: number;
    /** Per-seat breakdown. */
    readonly seats: readonly SeatEstimate[];
    /** Output tokens assumed per seat per round. */
    readonly outputTokens: number;
    /** Size band the planner reported. */
    readonly scale: Scale;
    /** Rounds the full council will run (draft + review). */
    readonly rounds: number;
    /** How the figure was reached. */
    readonly basis: 'history' | 'pricing' | 'unknown';
    /** Warnings the user should see before approving. */
    readonly warnings: readonly string[];
}
/** Thresholds the estimate is judged against. */
export interface EstimateLimits {
    /** Remaining OpenRouter credit. */
    readonly remainingUsd?: number | undefined;
    /** Monthly OpenRouter target. */
    readonly monthlyUsd?: number | undefined;
    /** Spend so far this month. */
    readonly monthUsedUsd?: number | undefined;
    /** Weekly Claude token allowance the user set. */
    readonly weeklyClaudeTokens?: number | undefined;
    /** Claude tokens already used this week. */
    readonly weeklyClaudeUsed?: number | undefined;
}
/**
 * Estimate a full council run and judge it against the configured limits.
 * @param seats - the active roster.
 * @param plan - the planner's size judgement.
 * @param pricing - OpenRouter price table.
 * @param history - costs of comparable completed runs.
 * @param limits - budget thresholds.
 * @returns the estimate and any warnings it raises.
 */
export declare function estimateRun(seats: readonly SeatConfig[], plan: PlanScale, pricing: ReadonlyMap<string, ModelPrice>, history: readonly RunHistory[], limits?: EstimateLimits): RunEstimate;
//# sourceMappingURL=estimate.d.ts.map