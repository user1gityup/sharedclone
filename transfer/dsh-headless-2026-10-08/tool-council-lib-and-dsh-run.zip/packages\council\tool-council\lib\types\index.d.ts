/**
 * Multi-agent council tool.
 *
 * Registers one `council` tool that fans a query out to four seats, has them
 * review each other, tallies a confidence-weighted vote, and reports the
 * outcome. The coloured report goes to the console; a plain-text copy is
 * returned as the tool result so the calling model reads the same thing.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { CouncilResult } from './council.ts';
import { type WriterConfig } from './submit-work.ts';
import type { SeatConfig } from './seats.ts';
/** Cordis plugin name. */
export declare const name = "tool-council";
/**
 * Services required. `settings` carries the UI-writable namespace; the base
 * bundle always mounts a provider, so waiting for it is safe.
 */
export declare const inject: string[];
/** Settings namespace this plugin owns; the UI binds the same name. */
export declare const COUNCIL_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** One seat's user-facing configuration. */
export interface SeatOverride {
    /** Turn this seat off without removing its configuration. */
    enabled?: boolean;
    /** CLI seats: executable name resolved against PATH. */
    command?: string;
    /** CLI seats: argv template; `{prompt}` is replaced with the prompt. */
    args?: string[];
    /**
     * Model identifier to request. OpenRouter seats send it as the request's
     * model; a CLI seat with a model flag (Codex: `-m`) passes it on the command
     * line. Empty means the seat's own default.
     */
    model?: string;
    /**
     * OpenRouter seats: chat-completions endpoint, overriding OpenRouter's own.
     * Set this to route a seat through a local OpenAI-compatible proxy.
     */
    baseUrl?: string;
    /** Mark this seat as costing nothing per token. */
    free?: boolean;
}
/** A seat the user adds beyond the shipped ones. */
export interface ExtraSeat {
    /** Display name shown in the report; the key is used when omitted. */
    name?: string;
    /** OpenRouter model identifier. Extra seats are OpenRouter-only. */
    model: string;
    /**
     * Chat-completions endpoint, overriding OpenRouter's own. An extra seat
     * pointed at a local proxy needs no API key, because the proxy holds one.
     */
    baseUrl?: string;
    /** This seat costs nothing per token; keeps it out of the metered blend. */
    free?: boolean;
    /**
     * Environment variable, or `.credentials.yaml` entry, holding this seat's
     * own key in place of the OpenRouter one. This is how a second AWS account
     * gets its own Bedrock seat: one extra seat per account, each naming that
     * account's bearer-token variable. Empty sends the run's OpenRouter key.
     */
    apiKeyEnv?: string;
    /** Turn this seat off without removing it. Defaults to on. */
    enabled?: boolean;
}
/** Council routing configuration. */
export interface Config {
    /** Master switch. Set false to register no tool at all. */
    enabled?: boolean;
    /** Per-seat overrides for the four shipped seats, keyed by seat id. */
    seats?: Record<string, SeatOverride>;
    /** Additional OpenRouter seats, keyed by a new seat id. */
    extraSeats?: Record<string, ExtraSeat>;
    /** Environment variable holding the OpenRouter key. */
    apiKeyEnv?: string;
    /** Hard cap per seat call, in milliseconds. */
    timeoutMs?: number;
    /** Successful drafts required before a result is a council decision. */
    minDrafts?: number;
    /** Successful reviews required before a result is a council decision. */
    minReviews?: number;
    /** Run seats one at a time instead of in parallel. */
    sequential?: boolean;
    /** Never emit ANSI escapes, whatever the terminal reports. */
    noColor?: boolean;
    /**
     * Run a cheap planning round before drafting. On by default: one small call
     * that settles direction is far cheaper than N large ones aimed wrongly.
     */
    planning?: boolean;
    /**
     * Stop after planning and return the plan for review. On by default, so the
     * expensive rounds never run without a look at the direction first.
     */
    planOnly?: boolean;
    /** Seat that writes the plan. Defaults to the first OpenRouter seat. */
    plannerSeat?: string;
    /**
     * When on, the agent is instructed to route every substantive request
     * through the council rather than answering alone.
     */
    councilMode?: boolean;
    /**
     * Plan the council issued and is holding at the approval gate. Flat scalars
     * on purpose: a nested object schema gets an empty default materialised into
     * it at load, and its required fields then fail validation before boot.
     */
    pendingPlanId?: string;
    /** The question that plan answers, shown on the Approve control. */
    pendingPlanQuery?: string;
    /** The plan text itself, run verbatim once approved. */
    pendingPlanText?: string;
    /** When the plan was issued, so a stale approval can be rejected. */
    pendingPlanIssuedAt?: number;
    /**
     * The planner route the planning round took, as JSON. The approved run
     * skips planning, so without this the filed record would never carry it.
     */
    pendingPlanRoute?: string;
    /**
     * Plan id a human approved, written only by the Approve control. The model
     * has no settings-writing tool, so this field cannot be forged by it.
     */
    approvedPlanId?: string;
    /** When the Approve control was pressed. */
    approvedAt?: number;
    /**
     * The swarm's half of the same gate, kept in its own slots.
     *
     * A council approval must not authorise a swarm run: they cost differently
     * and do different things. Sharing one set of slots would mean approving a
     * debate and getting a graph of workers.
     */
    pendingSwarmId?: string;
    /** Cost profile a swarm run uses; `user` keeps whatever seats the roster names. */
    swarmProfile?: 'economy' | 'fastest' | 'user';
    /** Profile the pending graph was proposed under, so approving cannot change what it costs. */
    pendingSwarmProfile?: string;
    /** Profile the running pipeline hands to the stages it has not fired yet. */
    pipelineProfile?: string;
    /** The request that graph serves, shown on the Approve control. */
    pendingSwarmQuery?: string;
    /**
     * The approved graph itself, as JSON, run verbatim once approved.
     *
     * Stored rather than re-derived: decomposing again would produce a different
     * graph from the one the user read, so the approval would carry work nobody
     * saw. It also means approval costs nothing — the planning call was paid for
     * before the gate.
     */
    pendingSwarmTasks?: string;
    /** When the graph was issued, so a stale approval can be rejected. */
    pendingSwarmIssuedAt?: number;
    /** Graph id a human approved, written only by the Approve control. */
    approvedSwarmId?: string;
    /** When the swarm's Approve control was pressed. */
    approvedSwarmAt?: number;
    /**
     * The proposing round's half of the same gate, in its own slots again.
     *
     * A proposing round spends a long writing call per seat plus a vote per
     * seat, so it is the most expensive of the three and must be approved on its
     * own terms rather than inheriting either of the others.
     */
    /**
     * The council -> swarm -> council chain, as it survives between calls.
     *
     * The stage is durable state rather than something the model remembers, so
     * a chain that gets interrupted resumes where it stood. These slots hold no
     * approval of their own: each stage still passes its own tool's gate.
     */
    /**
     * Named, pre-written runs. A preset is the whole request already agreed, so
     * firing one takes a click rather than typing the prompt again — and the
     * wording is reviewed once, in settings, rather than retyped differently
     * each time. Keyed by id, a dict for the same reason `swarmRoster` is: a
     * bare object schema materialises an empty default and then fails its own
     * required fields at boot.
     */
    pipelinePresets?: Record<string, {
        /** Which pipeline the preset fires: a full council debate, or a swarm at either cost profile. */
        mode?: 'council' | 'economy' | 'fastest';
        /** Label shown on the preset's control. */
        name?: string;
        /** Request sent verbatim when the preset fires. */
        query?: string;
        /** Advance the chain without waiting to be asked between stages. */
        autoAdvance?: boolean;
        /** Stage order this run needs, comma separated; empty means the default. */
        stages?: string;
    }>;
    /** The pipeline panel's run-history request, as JSON `{seq, op, id?, label?}`; see run-history-publisher.ts. */
    runHistoryRequest?: string;
    /** The host's answer to the latest run-history request, with the stored runs, as JSON. */
    runHistoryJson?: string;
    /** Set while a run should advance itself; written by the control that fired a preset. */
    pipelineAuto?: boolean;
    /** Id of the pipeline run in flight; empty when nothing is running. */
    pipelineId?: string;
    /**
     * Id of the run the panel's Stop cleared. A stage already in flight when
     * Stop is pressed checks this before writing its state back, so the run it
     * belonged to stays stopped instead of reappearing when the stage returns.
     */
    pipelineStoppedId?: string;
    /** The request the whole chain serves, in the user's own words. */
    pipelineQuery?: string;
    /** Which stage the next call runs. */
    pipelineStage?: string;
    /**
     * The order this run advances through, comma separated.
     *
     * Held per run rather than per install: one preset builds and the next only
     * decides, and a global setting would make the second inherit the first.
     */
    pipelineStages?: string;
    /** The approach the council agreed, carried into the decomposition. */
    pipelinePlan?: string;
    /** Seat whose plan won the vote, so later stages can route on what the run earned. */
    pipelineWinner?: string;
    /** The approved graph, as JSON, so a resumed run needs no new planning call. */
    pipelineTasks?: string;
    /** What the workers reported, as JSON, carried into the review. */
    pipelineUnits?: string;
    /** Seat trees the proposing stage wrote, as JSON, so the swarm can cite them. */
    pipelineCandidates?: string;
    /**
     * The versions the user picked, comma separated seat ids, empty until they
     * have picked.
     *
     * Written by the gate strip, next to Approve, because picking IS the second
     * factor for the stage that builds: a run that could advance without it
     * would build whatever the council happened to prefer, which is the one
     * decision the proposing stage exists to hand back to the user.
     */
    pipelinePicked?: string;
    /**
     * What the user kept in the selecting stage, as JSON, and what they kept out
     * of each.
     *
     * Separate from `pipelinePicked`, which is a comma list of seat ids written
     * by the gate strip for the proposing stage. A list of ids cannot hold "this
     * one, but only its sidebar", and that sentence is the whole output of a
     * round whose point is that the user, not a vote, decides. Cleared with the
     * run for the same reason a pick is: taste belongs to the run it was
     * expressed in.
     */
    pipelineSelections?: string;
    /** Wording of the exhaustion that parked the run, empty when it is running. */
    pipelineHoldDetail?: string;
    /** Seat whose allowance ran out. */
    pipelineHoldSeat?: string;
    /** Epoch ms the hold ends at; 0 when there is no hold. */
    pipelineHoldResumeAt?: number;
    /** Whether that time was stated by the provider or defaulted here. */
    pipelineHoldSource?: string;
    /** Id of the propose round held at the approval gate. */
    pendingProposeId?: string;
    /** The change the seats would each write, shown on the Approve control. */
    pendingProposeTask?: string;
    /** Run id, so the approved run writes where the plan said it would. */
    pendingProposeRunId?: string;
    /** When the round was issued, so a stale approval can be rejected. */
    pendingProposeIssuedAt?: number;
    /** Round id a human approved, written only by the Approve control. */
    approvedProposeId?: string;
    /** When the proposing round's Approve control was pressed. */
    approvedProposeAt?: number;
    /**
     * Directory under which each seat's own tree is created, one per run and
     * seat. Defaults to `swarm-work` beside the other DSH state.
     */
    workRoot?: string;
    /**
     * Skip the per-run approval gate. Off by default, and only a person can set
     * it: the model has no settings-writing tool, so it cannot grant itself
     * standing permission to spend.
     */
    autoApprove?: boolean;
    /** How many pipeline runs the headless runner (bin/dsh-run.mjs) lets run at once on this machine. */
    maxPipelineRuns?: number;
    /**
     * Route approved work to a swarm of workers instead of answering in one
     * agent. Off by default: a swarm writes files and runs commands.
     */
    /**
     * How the plan is produced. Defaults to `council`: the plan is the decision
     * every later round inherits, so it should not rest on one seat.
     */
    /**
     * Web results each hosted seat may request per call. Zero leaves them
     * offline. OpenRouter bills per result, so this is a spending dial.
     */
    /**
     * Let seats request their own searches, run through the web seam on their
     * behalf. On by default: the searches go through a subscription route, so
     * this is the cheap way to give every seat live information.
     */
    seatResearch?: boolean;
    /**
     * Searches the research round runs at once.
     *
     * The web seam spreads searches across the authenticated CLI lanes it is
     * configured with, so this is what turns eight sequential lookups into a few
     * concurrent ones. Raising it past the lane count spawns more CLI processes
     * than there are subscriptions to serve them.
     */
    researchConcurrency?: number;
    /**
     * Directories whose files seats may ask to be shown, comma-separated.
     *
     * A seat never reads for itself: it names a path in the research round and
     * the host reads it, only inside these roots. Empty — the default — means no
     * seat is told it can ask, so nothing is readable until a person says which
     * directories. One flat string rather than an array because a nested
     * schemastery default materialises an empty object and fails at boot.
     */
    fileRoots?: string;
    /** How many web-search results a seat may pull for one query. */
    webMaxResults?: number;
    /** Whether a plan is drafted by one seat or debated by the whole council. */
    planMode?: 'single' | 'council';
    /** Whether an approved plan advances to a swarm run instead of stopping at the plan. */
    swarmMode?: boolean;
    /**
     * Per-provider swarm roster, keyed by subagent provider name. A dict of
     * objects rather than a bare object: a top-level object schema gets an empty
     * default materialised into it and fails its own required fields at boot.
     */
    swarmRoster?: Record<string, {
        /** Whether this provider may be given swarm work at all. */
        enabled?: boolean;
        /** Subagent kinds this provider may be asked for. */
        kinds?: string[];
        /** How many of this provider's workers may run at once. */
        maxConcurrent?: number;
    }>;
    /** Refuse to start when remaining OpenRouter credit falls below this. */
    minBalanceUsd?: number;
    /**
     * Refuse to start when the spendable CheaperInference wallet falls below
     * this. Checked only when a seat in the roster draws on that wallet, and
     * judged separately from the OpenRouter floor above: the two providers hold
     * separate money. There is deliberately no monthly counterpart — the wallet
     * is prepaid, so its balance already is the ceiling.
     */
    cheaperInferenceMinBalanceUsd?: number;
    /** Monthly OpenRouter spend target used for pace warnings. */
    monthlyBudgetUsd?: number;
    /** Weekly Claude token allowance the estimator measures against. */
    weeklyClaudeTokens?: number;
    /** Daily Claude token allowance shown in the budget panel. */
    dailyClaudeTokens?: number;
    /**
     * Monthly price of one subscription seat, in USD. A subscription's cost per
     * token is knowable: its price divided by the tokens it actually produces.
     */
    subscriptionUsdPerSeat?: number;
    /**
     * Output tokens the CLI seats produced over the last seven days, measured
     * from their local logs. Written by this plugin so the browser panel — which
     * cannot read those logs — can price subscription seats.
     */
    observedCliTokensPerWeek?: number;
    /**
     * Model ids the local Codex CLI lists, read from its model cache. Written by
     * this plugin so the browser panel can offer them for the Codex seat.
     */
    codexModels?: string[];
    /**
     * Model ids CheaperInference currently serves, cheapest output price first.
     * Written by this plugin so the browser panel can offer them without holding
     * the provider's key: the catalogue is live and priced per model, so a list
     * compiled at build time would be wrong within days.
     */
    cheaperInferenceModels?: string[];
    /**
     * Spendable CheaperInference balance in USD, as the provider reports it.
     * Written by this plugin for the same reason: the panel runs in a browser
     * and the key lives in the host's credentials file.
     */
    cheaperInferenceWalletUsd?: number;
    /**
     * What CheaperInference's discount saved over its reported usage window, in
     * USD. Written by this plugin for the same reason as the wallet: the figure
     * needs the provider's key and the panel is a browser. Surfaced because the
     * discount off list is what distinguishes this provider, and it is the one
     * number the OpenRouter balance cannot show.
     */
    cheaperInferenceSavedUsd?: number;
    /** That saving as a percentage of list price, as the provider computes it. */
    cheaperInferenceSavingsPercent?: number;
    /** Length in days of the usage window the two figures above cover. */
    cheaperInferenceUsageDays?: number;
    /** Wallet balance before holds against requests in flight, in USD. */
    cheaperInferenceBalanceUsd?: number;
    /** Held against requests in flight, in USD. */
    cheaperInferenceReservedUsd?: number;
    /** Whether the provider tops the wallet up on its own. */
    cheaperInferenceAutoRecharge?: boolean;
    /** What the account was billed over the usage window, in USD. */
    cheaperInferenceBilledUsd?: number;
    /** Requests in the usage window. */
    cheaperInferenceRequestCount?: number;
    /**
     * The window's biggest spenders as JSON, `[{model, requestCount, billedUsd}]`.
     * A string because settings fields stay flat scalars.
     */
    cheaperInferenceTopModelsJson?: string;
    /** Last successful budget capture, in epoch milliseconds. */
    cheaperInferenceCapturedAt?: number;
    /** Budget reader state: idle, running, ok, or failed. */
    cheaperInferenceBudgetState?: string;
    /**
     * Budget poll period in milliseconds; zero reads only at boot and on the
     * panel's Refresh. A timer is allowed because every call it makes is free.
     */
    cheaperInferenceBudgetPollMs?: number;
    /** Monotonic budget refresh request from the panel. */
    cheaperInferenceRefreshRequestedAt?: number;
    /** OpenRouter credits left to spend, in USD: purchased minus used. */
    openRouterRemainingUsd?: number;
    /** OpenRouter credits bought to date, in USD. */
    openRouterPurchasedUsd?: number;
    /** OpenRouter credits consumed to date, in USD. */
    openRouterUsedUsd?: number;
    /** Last successful OpenRouter balance capture, in epoch milliseconds. */
    openRouterCapturedAt?: number;
    /** OpenRouter balance reader state: idle, running, ok, or failed. */
    openRouterBalanceState?: string;
    /**
     * OpenRouter balance poll period in milliseconds; zero reads only at boot
     * and on the panel's Refresh. Free to call, like the budget above.
     */
    openRouterBalancePollMs?: number;
    /** Monotonic OpenRouter balance refresh request from a panel. */
    openRouterRefreshRequestedAt?: number;
    /**
     * Relay root for a host that holds no raw OpenRouter key, e.g.
     * `http://10.0.0.241:8080`. A provider `baseURL` may be pasted in whole;
     * the trailing `/v1` is dropped.
     */
    openRouterRelayBase?: string;
    /**
     * Shared-memory digest handed to every seat. Defaults to the agent-memory
     * plugin's digest; set false to run the council without that digest.
     */
    memoryDigest?: string | false;
    /**
     * Index of the user's shared brain, handed to every seat ahead of the digest
     * so seats and swarm workers start from the same notes as Claude Code, Codex
     * and the DSH agents. Defaults to `~/.claude/shared-brain/MEMORY.md`; set
     * false to leave it out.
     */
    brainIndex?: string | false;
    /**
     * Host commit route for `submit_work`: agents hand over files, the host
     * commits them on a fresh worktree branch and queues the commit for the
     * user's push approval. Unset queueScript makes the tool refuse.
     */
    writer?: WriterConfig;
}
/** Loader schema for the council tool. */
export declare const Config: z<Config>;
/**
 * Whether a council run actually reached a decision, as opposed to merely
 * reaching its final phase. `runCouncil` returns `phase: 'full'` on the dead-
 * roster path too (`council.ts`, the `usable.length < minDrafts` return), where
 * `terminalState` is `failed`, `partial` or `cancelled`. Only `completed` means
 * quorum was met and a winner was elected, so only `completed` may advance a
 * pipeline stage or be spent on.
 * @param council - the run result's `phase` and `terminalState`.
 * @returns true only when the run reached `full` phase with a `completed` terminal state.
 */
export declare function councilDecided(council: Pick<CouncilResult, 'phase' | 'terminalState'>): boolean;
/**
 * Merge configured overrides onto the shipped seat defaults.
 * @param overrides - per-seat configuration keyed by seat id.
 * @param extras - user-added OpenRouter seats, keyed by seat id, appended after the shipped roster (a duplicate id is skipped).
 * @returns the resolved roster in council order.
 */
export declare function resolveSeats(overrides?: Record<string, SeatOverride>, extras?: Record<string, ExtraSeat>): readonly SeatConfig[];
/**
 * Render the brain index as seat context.
 * @param indexPath - the index file, whose directory is the store.
 * @param index - the index text.
 * @returns the section that opens every seat's shared memory.
 */
export declare function renderBrainContext(indexPath: string, index: string): string;
/**
 * Resolve the shared-memory payload for one run.
 *
 * CLI seats take the path; hosted seats take the text. Both come from one
 * file, so every seat sees identical memory. With a shared brain present, that
 * file is a composite of the brain index and the digest, written beside the
 * digest as `council-context.md`.
 * @param setting - configured digest path, or false to leave the digest out.
 * @param brainSetting - configured brain index path, or false to leave it out.
 * @returns the payload, or undefined when memory is off or absent.
 */
export declare function resolveMemory(setting: string | false | undefined, brainSetting?: string | false): {
    file?: string | undefined;
    text?: string | undefined;
} | undefined;
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map