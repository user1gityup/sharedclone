/**
 * Resolution: roles in, a concrete roster out, with the reasons attached.
 *
 * Roles are filled in the order given, and a candidate already holding a role
 * that this one must be independent of is passed over however well it scores —
 * a review by its own author is not a review. Everything refused is kept in
 * the trace, because "why did this run use the metered seat" is asked after
 * the run, when the field it chose from is gone.
 */
import type { Candidate, Resolution, RoleRequirement, RoutingContext } from './types.ts';
/**
 * Resolve every role against the candidate field.
 *
 * `candidates` is expected to come from `buildRegistry`, so machine profiles
 * have already been applied and the throughput figures are the measured ones.
 * @param roles - the roles to fill, in fill order.
 * @param candidates - the field to resolve roles against.
 * @param context - the run's routing policy, budgets, and entitlements.
 * @returns the assignments made, the unfilled roles, and every rejection for the trace.
 */
export declare function resolveRoster(roles: readonly RoleRequirement[], candidates: readonly Candidate[], context: RoutingContext): Resolution;
//# sourceMappingURL=resolve.d.ts.map