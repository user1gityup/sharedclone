/**
 * The hard filter: who is allowed to do this work at all.
 *
 * Everything here is a yes or no question — capable, authorized, available,
 * within quota, within budget, in the right place. Weights never run against a
 * candidate that failed one of these, which is the whole point of the split:
 * a score can be tuned, and a tuned score must never be able to route around
 * an entitlement.
 *
 * Every rejection carries a code, so a run can be explained after the fact
 * without keeping the reasoning that produced it.
 */
import type { Candidate, RejectionCode, RoleRequirement, RoutingContext } from './types.ts';
/** Default quota fraction below which a candidate counts as exhausted. */
export declare const defaultMinQuotaHeadroom = 0.05;
/** One failed check. */
export interface FilterFailure {
    readonly code: RejectionCode;
    readonly detail: string;
}
/**
 * Output tokens this role should be sized against.
 * @param role - the role, consulted first for its own estimate.
 * @param context - the run's default estimate, used when the role names none.
 * @returns the output-token estimate to size cost and latency against.
 */
export declare function outputTokensFor(role: RoleRequirement, context: RoutingContext): number;
/**
 * Estimated metered spend for one role on one candidate, in USD.
 * @param candidate - the candidate whose per-token price to apply.
 * @param role - the role being sized.
 * @param context - the run's routing context, for the default output estimate.
 * @returns the estimated USD cost, or 0 for a candidate with no per-token price.
 */
export declare function estimateUsd(candidate: Candidate, role: RoleRequirement, context: RoutingContext): number;
/**
 * Seconds this role is expected to take on this candidate.
 *
 * Queued units count: a free local worker with four units ahead of it finishes
 * later than a subscription seat that is idle, and routing that ignores the
 * queue keeps choosing the slower one because it is free.
 * @param candidate - the candidate whose throughput, queue depth, and startup cost to apply.
 * @param role - the role being sized.
 * @param context - the run's routing context, for the default output estimate.
 * @returns the estimated wall-clock seconds, including time behind already-queued units.
 */
export declare function estimateSeconds(candidate: Candidate, role: RoleRequirement, context: RoutingContext): number;
/**
 * Check one candidate against one role.
 *
 * Returns the first failure, or undefined when the candidate is eligible. The
 * order runs cheapest and most decisive first: an incapable candidate is not
 * worth a budget calculation.
 * @param candidate - the candidate to check.
 * @param role - the role's requirements: capabilities, tools, context size, cost classes.
 * @param context - the run's routing context: roster pins, entitlements, budgets, and deadlines.
 * @returns the first failed check, or undefined when the candidate passes every one.
 */
export declare function checkCandidate(candidate: Candidate, role: RoleRequirement, context: RoutingContext): FilterFailure | undefined;
//# sourceMappingURL=filter.d.ts.map