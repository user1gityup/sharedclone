/**
 * Seat definitions and the two transports that back them.
 *
 * Some seats are driven by an already-authenticated local CLI, the rest by an
 * OpenAI-compatible HTTP endpoint. The council never handles a CLI seat's
 * credentials: the user authenticated that tool once, and the child process
 * inherits the session. Only a seat calling OpenRouter itself needs a key, and
 * it reads one from the environment rather than accepting it as an argument; a
 * seat pointed at a local proxy needs none, because the proxy holds the key.
 */
import type { SeatId } from './colors.ts';
/** How a seat reaches its model. */
export type SeatTransport = 'cli' | 'openrouter';
/** One seat's resolved routing. */
export interface SeatConfig {
    /** Stable seat identity, also the colour key. */
    readonly id: SeatId;
    /** Human-facing name used in the report and in vote text. */
    readonly name: string;
    /** Which transport carries this seat. */
    readonly transport: SeatTransport;
    /**
     * For `cli`: the executable to run. For `openrouter`: unused.
     * Resolved against PATH by the platform, never through a shell.
     */
    readonly command?: string | undefined;
    /**
     * For `cli`: argv template. The literal token `{prompt}` is replaced by the
     * prompt; every other entry is passed through verbatim. Keeping the prompt a
     * distinct argv entry is what makes shell-free spawning safe.
     */
    readonly args?: readonly string[] | undefined;
    /**
     * For `cli`: what replaces the `{prompt}` entry when the prompt is delivered
     * on stdin instead of argv, or omitted when the CLI wants the entry gone.
     *
     * A council prompt grows with the round: the review prompt carries every
     * seat's full draft, and a five-seat round on a researched question passed
     * 32767 characters — the Windows command-line limit — so `spawn` failed with
     * ENAMETOOLONG and all three CLI seats lost their vote at once. Delivering
     * the same text on stdin has no such limit. `codex exec` wants `-` to mean
     * "read the prompt from stdin"; `claude -p` reads stdin whenever no prompt
     * argument follows, so its entry is dropped instead.
     */
    readonly stdinPromptArg?: string | undefined;
    /** Deliver every prompt over stdin for this CLI. */
    readonly promptOnStdin?: boolean | undefined;
    /** This seat can execute web searches with native tools. */
    readonly nativeWebSearch?: boolean | undefined;
    /**
     * For `openrouter`: how long the streamed answer may go silent before the
     * seat gives up, overriding {@link DEFAULT_STREAM_IDLE_MS}.
     */
    readonly idleMs?: number | undefined;
    /**
     * Seat-specific hard cap, overriding the run's timeout.
     *
     * One global timeout cannot serve a paid seat and a free one equally: a
     * free-tier provider retries through 529s and is legitimately slower, so a
     * limit set for a fast seat kills a slow one mid-answer while a limit set
     * for the slow one lets a hung fast seat stall the round.
     */
    readonly timeoutMs?: number | undefined;
    /**
     * For `cli`: environment layered over the parent process environment.
     *
     * This is what lets one CLI serve as two independent seats: a seat can point
     * at a different backend and keep its own config directory, so it shares
     * neither credentials nor session state with a seat running on the user's
     * own subscription.
     */
    readonly env?: Readonly<Record<string, string>> | undefined;
    /**
     * The model identifier to request. For `openrouter` it is the request's
     * `model` field; for `cli` it is passed through {@link modelFlag}, and is
     * ignored by a CLI seat that declares no flag.
     */
    readonly model?: string | undefined;
    /**
     * For `cli`: the flag that selects the CLI's model, e.g. `-m` for
     * `codex exec`. When set and {@link model} is non-empty, the flag and model
     * go in front of the prompt entry; with no model the CLI uses its own
     * configured default.
     */
    readonly modelFlag?: string | undefined;
    /**
     * For `openrouter`: chat-completions endpoint, overriding OpenRouter's own.
     *
     * The wire format is unchanged — an OpenAI-compatible `/chat/completions`
     * that streams SSE — so only the URL differs. This is what lets a seat run
     * against a local proxy without inventing a third transport: a dozen call
     * sites branch on `transport === 'openrouter'` for prompt shaping, capacity
     * and estimates, and a new transport value would silently miss some.
     */
    readonly baseUrl?: string | undefined;
    /**
     * This seat costs nothing per token.
     *
     * Free is not the same as unpriced. An OpenRouter seat whose model carries
     * no price row is of *unknown* cost, and the panel says so; a seat marked
     * free is known to be zero, so it stays out of the metered blend entirely
     * and the swarm sorts it beside the subscription seats rather than after
     * them.
     */
    readonly free?: boolean | undefined;
    /**
     * Served by this machine's own GPU (a local llama.cpp router), not a proxy.
     *
     * Three things follow. The OpenRouter key is never sent, because the request
     * does not leave the machine and the key has no business in a local log. The
     * live probe lists models instead of asking for a token: a chat forces the
     * router to swap the requested model in, measured at 13-57s on an 8 GB card,
     * so a probe that chats pays a model load per council round. And the router
     * sees the seat as cost class `local`, not merely `free`.
     */
    readonly local?: boolean | undefined;
    /**
     * For a `local` seat served by another machine: that machine's relay token,
     * sent as the Bearer in place of the OpenRouter key. Filled in at run time
     * by `routeLocalSeat` from `.credentials.yaml`, never written to settings.
     */
    readonly authToken?: string | undefined;
    /**
     * For `openrouter`: the credential reference this seat authenticates with,
     * in place of the run's OpenRouter key.
     *
     * A `baseUrl` already lets a seat speak the same wire format to a different
     * provider, but every such seat still sent the OpenRouter bearer — which is
     * the wrong secret for anyone but OpenRouter, and is missing entirely on a
     * machine that only has the other provider's key. Naming the reference here
     * keeps the key itself out of settings: it is read at run time from the
     * environment, then from `.credentials.yaml`, exactly as the run's own key
     * is.
     */
    readonly apiKeyEnv?: string | undefined;
    /**
     * For `cli`: a flag that takes a context file path. When set and a memory
     * digest exists, the flag and path are appended to argv, which is far
     * cheaper than pasting the digest into every prompt.
     */
    readonly contextFileFlag?: string | undefined;
    /**
     * For `cli`: working directory for the child, overriding the host's own.
     *
     * An agent CLI discovers project instruction files by walking up from its
     * working directory. Inheriting the host's cwd therefore feeds the seat
     * whatever repository DSH happens to be running in — measured at ~8s per
     * call for `claude -p`, and it changes the answer: a seat handed a project's
     * instructions will sometimes address those instead of the question. Seats
     * do not read files themselves anyway (the host reads them and quotes the
     * text back, resolved against the configured roots), so a neutral directory
     * costs the seat nothing.
     */
    readonly cwd?: string | undefined;
    /** Whether this seat participates. */
    readonly enabled: boolean;
}
/**
 * What a provider reported about one call's consumption.
 *
 * Only metered transports populate this. A CLI seat bills a separate
 * subscription that this process cannot observe, so its usage stays undefined
 * rather than being guessed — an invented number would corrupt any budget
 * built on this history.
 */
export interface SeatUsage {
    readonly inputTokens?: number | undefined;
    readonly outputTokens?: number | undefined;
    /** Cost in USD, as reported by the provider. */
    readonly costUsd?: number | undefined;
    /** Model that actually served the request. */
    readonly model?: string | undefined;
}
/** A seat's answer, or the reason it produced none. */
export interface SeatReply {
    /** URLs the provider reports this seat actually consulted, when it searched. */
    readonly citedUrls?: readonly string[] | undefined;
    readonly seat: SeatId;
    /** Model text, empty when `error` is set. */
    readonly text: string;
    /** Failure description; `undefined` on success. */
    readonly error?: string | undefined;
    /** Wall time spent on the call. */
    readonly ms: number;
    /** Provider-reported consumption, when the transport reports any. */
    readonly usage?: SeatUsage | undefined;
}
/** Defaults chosen so a fresh install runs without configuration. */
export declare const DEFAULT_SEATS: readonly SeatConfig[];
/**
 * Windows spellings to try, most preferred first.
 *
 * `.exe` leads deliberately. Node's fix for CVE-2024-27980 refuses to spawn a
 * `.cmd` or `.bat` with `shell: false` and throws EINVAL, so a batch shim is
 * unusable on the safe spawn path. A real executable has no such restriction,
 * and npm-installed agent CLIs ship one beside their shims.
 */
/**
 * Output cap sent with every OpenRouter request.
 *
 * Omitting `max_tokens` makes OpenRouter ask for the model's entire context
 * window. A provider whose real ceiling is lower than the advertised context
 * then rejects the call outright: Novita serves Kimi K2 with a 98304 cap
 * against a 100352 context, so every uncapped request 400s before the model
 * ever sees the prompt. An explicit cap is the difference between a seat that
 * answers and a seat that never does.
 *
 * Set generously — no realistic council draft approaches this.
 */
export declare const DEFAULT_MAX_OUTPUT_TOKENS = 16000;
/**
 * Web results requested per seat when live search is on.
 *
 * OpenRouter bills the web plugin per result, so this is a cost dial, not a
 * quality dial past the first few: five gives a seat enough to check a claim
 * without turning every draft into a research bill.
 */
export declare const DEFAULT_WEB_MAX_RESULTS = 5;
/**
 * Resolve a bare CLI name to a real executable when one can be found.
 *
 * Returns the input unchanged off Windows, or when nothing is known about the
 * name — the PATH candidates still get their turn.
 * @param command - the configured command name.
 * @returns an absolute path to a real executable, or undefined.
 */
export declare function resolveRealExecutable(command: string): string | undefined;
/**
 * Candidate spellings for an executable, most preferred first.
 *
 * A `.cmd` shim cannot be spawned without a shell on modern Node, and running
 * one through a shell would re-parse the prompt as a command line. Preferring
 * the real `.exe` avoids both problems.
 * @param command - the bare executable name.
 * @returns ordered candidates for this platform.
 */
export declare function executableCandidates(command: string): readonly string[];
/**
 * Put a CLI seat's chosen model in front of its prompt entry.
 *
 * In front of the prompt rather than after it, so the flag lands among the
 * subcommand's options whichever channel the prompt then travels on.
 * @param template - the seat's argv template.
 * @param seat - the seat, for its model and model flag.
 * @returns the template with `[modelFlag, model]` inserted, or unchanged.
 */
export declare function withModelFlag(template: readonly string[], seat: SeatConfig): readonly string[];
/**
 * Ask a CLI-backed seat, trying each platform candidate until one starts.
 *
 * A missing executable is reported as a seat failure rather than thrown: one
 * uninstalled CLI must not collapse the whole council.
 * @param seat - the seat's resolved routing.
 * @param prompt - the full prompt text.
 * @param signal - abort signal from the tool execution.
 * @param timeoutMs - hard cap per seat.
 * @param contextFile - path to a shared-memory digest, passed via the seat's `contextFileFlag` instead of the prompt.
 * @returns the seat's reply or its failure.
 */
export declare function askCliSeat(seat: SeatConfig, prompt: string, signal: AbortSignal | undefined, timeoutMs: number, contextFile?: string | undefined): Promise<SeatReply>;
/**
 * Ask an OpenRouter-backed seat.
 * @param seat - the seat's resolved routing.
 * @param prompt - the full prompt text.
 * @param apiKey - OpenRouter key resolved by the caller.
 * @param signal - abort signal from the tool execution.
 * @param timeoutMs - hard cap per seat.
 * @param maxTokens - the `max_tokens` cap sent to OpenRouter for this call.
 * @param webMaxResults - result count for the OpenRouter web plugin; omitted or non-positive leaves web search off.
 * @returns the seat's reply or its failure.
 */
export declare function askOpenRouterSeat(seat: SeatConfig, prompt: string, apiKey: string | undefined, signal: AbortSignal | undefined, timeoutMs: number, maxTokens?: number, webMaxResults?: number | undefined): Promise<SeatReply>;
/**
 * How long a reachability probe waits before calling a backend dead.
 *
 * A loopback TCP connect either answers immediately or is refused
 * immediately; anything slower than this is a port that will not serve a
 * council round either.
 */
export declare const PROBE_TIMEOUT_MS = 1500;
/** A loopback backend a CLI seat is pointed at. */
export interface SeatBackend {
    readonly host: string;
    readonly port: number;
    /** Origin as written, for the failure message. */
    readonly origin: string;
}
/**
 * The local backend a CLI seat routes through, when it routes through one.
 *
 * Only loopback addresses are returned. A probe exists to catch a proxy the
 * user forgot to start, which is always local; probing a remote host would
 * turn a slow network into a seat the council silently drops.
 * @param seat - the seat's resolved routing.
 * @returns the backend to probe, or undefined when there is nothing local to probe.
 */
export declare function loopbackBackend(seat: SeatConfig): SeatBackend | undefined;
/**
 * Check that a seat's local backend is listening before the round pays for it.
 *
 * A CLI agent does not fail fast on a dead backend: measured against a stopped
 * proxy, `claude -p` retried a refused connection for 180s before returning an
 * error, and because a round waits for every seat, that one dead seat set the
 * wall time for the whole round — twice, once per round. A connect that is
 * refused in a millisecond says the same thing.
 * @param seat - the seat to probe.
 * @param timeoutMs - how long to wait for the connect.
 * @returns undefined when the seat is usable, else why it is not.
 */
export declare function probeSeat(seat: SeatConfig, timeoutMs?: number): Promise<string | undefined>;
/**
 * How long a live probe may take before the seat counts as unreachable.
 *
 * One token from a warm provider comes back in under a second; 20s is slack
 * for a proxy that has to pick an upstream first, and still a fraction of the
 * 420s a free seat is otherwise allowed to burn failing.
 */
export declare const LIVE_PROBE_TIMEOUT_MS = 20000;
/**
 * Check that a free seat will actually serve, not merely that something is
 * listening.
 *
 * `probeSeat` opens a socket, which a proxy that is up but out of upstream
 * credit passes. Measured: in run `9d32f748` the socket probe reported
 * `ms 0` — healthy — for a seat whose very next request came back
 * `HTTP 402 SAMBANOVA PAYMENT_METHOD_REQUIRED`, and the council recorded a
 * completed run off half a dead roster. One token costs nothing on a free
 * seat and is the only thing that distinguishes the two.
 *
 * Paid seats are never probed this way: the request is not free there, and a
 * subscription CLI has its own credentials to spend.
 * @param seat - the seat to probe.
 * @param apiKey - OpenRouter key, when the caller has one.
 * @param signal - abort signal from the tool execution.
 * @param timeoutMs - how long the probe may take.
 * @returns undefined when the seat served, else why it did not.
 */
export declare function probeSeatLive(seat: SeatConfig, apiKey?: string | undefined, signal?: AbortSignal | undefined, timeoutMs?: number): Promise<string | undefined>;
/**
 * How long a stream may go silent before it is judged dead.
 *
 * Generation itself never pauses this long: a model that has stopped emitting
 * for a minute and a half has been cut off somewhere upstream, and waiting out
 * the whole per-seat cap only delays the round for an answer that is not
 * coming.
 */
export declare const DEFAULT_STREAM_IDLE_MS = 90000;
/**
 * Ask one seat over whichever transport it declares.
 * @param seat - the seat's resolved routing.
 * @param prompt - the full prompt text.
 * @param apiKey - OpenRouter key, used only by OpenRouter seats.
 * @param signal - abort signal from the tool execution.
 * @param timeoutMs - hard cap per seat.
 * @param memory - shared-memory digest to hand the seat: a file path for a CLI seat, prompt-prefixed text for an OpenRouter seat.
 * @param webMaxResults - result count for the OpenRouter web plugin, when the seat is OpenRouter-backed.
 * @returns the seat's reply or its failure.
 */
export declare function askSeat(seat: SeatConfig, prompt: string, apiKey: string | undefined, signal: AbortSignal | undefined, timeoutMs: number, memory?: {
    file?: string | undefined;
    text?: string | undefined;
} | undefined, webMaxResults?: number | undefined): Promise<SeatReply>;
//# sourceMappingURL=seats.d.ts.map