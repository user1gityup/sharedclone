/**
 * Error description for seat failures.
 *
 * `String(error)` renders a plain object as `[object Object]`, which is how a
 * real failure reason reached a report as nothing at all. Provider SDKs throw
 * plain objects and `AggregateError`s routinely, so a seat runner cannot assume
 * it caught an `Error`.
 */
/**
 * Describe a thrown value in one line a human can act on.
 *
 * Walks the shapes providers actually throw — Error, AggregateError, a plain
 * object with `message` or `error`, an HTTP-ish object with `status` — and
 * falls back to a JSON view rather than `[object Object]`.
 * @param error - the caught value, of unknown shape.
 * @returns a single-line description, never empty.
 */
export declare function describeError(error: unknown): string;
/** What kind of failure a seat error is, judged from its one-line description. */
export type FailureKind = 'cancelled' | 'unreachable' | 'auth' | 'payment' | 'quota' | 'timeout' | 'bad-request' | 'upstream' | 'empty' | 'unknown';
/** A classified seat failure: the kind, and whether asking again can help. */
export interface FailureClass {
    readonly kind: FailureKind;
    /** True when the same request could succeed later without anyone acting. */
    readonly retryable: boolean;
}
/**
 * Classify a seat failure so the gate, the journal and the report can tell a
 * dead credential (ask the user) from a rate limit (wait) from a cancel (stop).
 *
 * Only the normalized description is read; raw stderr never reaches here, so
 * nothing stored from the result can carry a token or a path.
 * @param error - the seat's one-line error, as {@link describeError} renders it.
 * @returns the kind and whether a retry can help.
 */
export declare function classifyFailure(error: string | undefined): FailureClass;
//# sourceMappingURL=errors.d.ts.map