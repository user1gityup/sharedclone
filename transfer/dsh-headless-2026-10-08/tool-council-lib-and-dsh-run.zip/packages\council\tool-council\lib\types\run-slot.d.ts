/**
 * Per-run pipeline state, so several pipeline runs can proceed at once.
 *
 * Pipeline and gate state used to live only in the `council` section of
 * settings.yaml: one slot per machine, so a second run either resumed the
 * first or, with `restart`, destroyed it. A process started with
 * `DSH_RUN_ID` set instead keeps those fields in its own file under
 * `~/.dsh/council-runs/active/<runId>.json`, layered over the shared
 * settings. Everything else — seats, presets, budgets, writer repos — stays
 * shared. A process without the variable behaves exactly as before, which is
 * what the web UI and every existing session still run.
 */
/** Environment variable that binds one DSH process to one pipeline run. */
export declare const RUN_ENV = "DSH_RUN_ID";
/** Settings fields that belong to a run rather than to the install. */
export declare function isRunField(key: string): boolean;
/**
 * Lifecycle a run moves through, as the runner records it. `routing`,
 * `validating`, `repairing`, `retrying` and `blocked` occur only in Auto Mode
 * (bin/dsh-auto.mjs).
 */
export type RunStatus = 'queued' | 'starting' | 'routing' | 'running' | 'validating' | 'repairing' | 'retrying' | 'paused' | 'blocked' | 'complete' | 'failed' | 'stopped';
/** What one run file holds. */
export interface RunRecordFile {
    runId: string;
    status: RunStatus;
    /** Preset or pipeline name the run was launched from. */
    pipeline?: string;
    /** Machine the run was launched on, and the one it executes on. */
    originMachine: string;
    executionMachine: string;
    /** PID of the DSH process serving the run, 0 before it starts. */
    pid: number;
    /** Working directory the run writes into. */
    cwd?: string;
    /** Log file the runner appends the process output to. */
    log?: string;
    createdAt: number;
    updatedAt: number;
    exitCode?: number;
    /** The run-scoped settings fields. */
    fields: Record<string, unknown>;
}
/**
 * The run id this process serves, or undefined when it serves the shared slot.
 * @throws when the variable is set to something that is not a safe id.
 */
export declare function runIdFromEnv(env?: NodeJS.ProcessEnv): string | undefined;
/** Directory holding one file per run. */
export declare function activeRunsDir(home?: string): string;
/** Path of one run's file. */
export declare function runFilePath(runId: string, dir?: string): string;
/** Read a run file; undefined when it is absent or unreadable. */
export declare function readRunFile(file: string): RunRecordFile | undefined;
/** Write a run file through a temp file and rename, so a reader never sees half of it. */
export declare function writeRunFile(file: string, record: RunRecordFile): void;
/** A fresh record for a run nothing has written yet. */
export declare function newRunRecord(runId: string, now?: number): RunRecordFile;
/** One run's state, bound to its file. */
export interface RunSlot {
    readonly runId: string;
    readonly file: string;
    /** The run-scoped fields as they stand on disk. */
    fields(): Record<string, unknown>;
    /** Merge run-scoped fields into the file. */
    write(patch: Record<string, unknown>): void;
}
/** Bind a slot to a run id. The file is created on first write. */
export declare function openRunSlot(runId: string, dir?: string): RunSlot;
/** Split a settings patch into the part a run owns and the part the install owns. */
export declare function splitPatch(patch: Record<string, unknown>): {
    run: Record<string, unknown>;
    shared: Record<string, unknown>;
};
/**
 * Settings as a run sees them: the shared section with every run field
 * replaced by the run's own value, or cleared when the run has none. A field
 * the run never wrote must not leak in from the shared slot, or a new run
 * would resume whatever the UI's run left behind.
 */
export declare function overlay<T extends object>(shared: T, fields: Record<string, unknown>): T;
/** Whether a process id is alive on this machine. */
export declare function pidAlive(pid: number): boolean;
/** Every run file, newest first, with whether its process is still alive. */
export declare function listRuns(dir?: string): (RunRecordFile & {
    alive: boolean;
})[];
/**
 * The seat working directory for this process. CLI seats share one default
 * directory; two runs at once would let one seat's scratch files land in the
 * other's, so a run gets its own subdirectory of it.
 */
export declare function scopeSeatCwd(cwd: string | undefined, runId?: string | undefined): string | undefined;
//# sourceMappingURL=run-slot.d.ts.map