/**
 * What the weight router routes: roles that describe work, candidates that can
 * perform it, and the policy that decides which of them wins.
 *
 * A preset says what a seat must be able to do; it does not say which model
 * sits there. That binding happens at launch, when availability, quota, load
 * and the machine's measured throughput are known — none of which a preset
 * written weeks earlier could have predicted.
 *
 * Nothing here knows about the Project Manager, the council, or the swarm. The
 * router takes plain data and returns a decision with its reasons, so the same
 * engine serves a council roster, a swarm wave and a single delegated task.
 */
import type { CostClass } from '../execution-cost.ts';
/**
 * How a candidate is paid for.
 *
 * `local` is separate from `free` because the scarce resource differs again:
 * a free remote tier spends someone else's wall clock, while a local worker
 * spends this team's own GPU, and a machine that is already saturated is not
 * cheap merely because no invoice arrives.
 */
export type RoutingCostClass = 'local' | CostClass;
/**
 * Who pays for a metered call, kept apart from the cost class.
 *
 * A Bedrock call is metered whether or not a promotional credit absorbs it, so
 * folding "a credit covers this" into `RoutingCostClass` would make the router
 * state a price it does not believe. `free` creates no charge, `credit` is
 * metered with an eligible unexpired credit applying, and `uncovered` is
 * metered with nothing shown to pay it, which includes unknown coverage.
 */
export type Coverage = 'free' | 'credit' | 'uncovered';
/** Refusal codes the quota reader derives for a candidate's coverage. */
export type CoverageRejectionCode = 'REAL_MONEY_BLOCKED' | 'CREDIT_NOT_APPLICABLE' | 'CREDIT_EXPIRED';
/** Why the quota reader refused a candidate's coverage, carried through to the decision trace. */
export interface CoverageRefusal {
    readonly code: CoverageRejectionCode;
    readonly detail: string;
}
/** Capability levels, ordered. A requirement is met when the candidate's level is at least the required one. */
export declare const capabilityLevels: readonly ["none", "low", "medium", "high"];
/** One capability level. */
export type CapabilityLevel = (typeof capabilityLevels)[number];
/**
 * Numeric rank of a level, used for comparison and for scoring the margin above the bar.
 * @param level - the capability level to rank.
 * @returns its index in `capabilityLevels` (`'none'` is 0, `'high'` is 3).
 */
export declare function levelRank(level: CapabilityLevel): number;
/**
 * What a role needs, expressed as capabilities rather than model names.
 *
 * `independentFrom` exists because a review is worthless when the reviewer is
 * the author: the resolver refuses to hand two such roles to one candidate
 * even when it scores highest for both.
 */
export interface RoleRequirement {
    readonly id: string;
    /** Capability floor per named capability, e.g. `{ coding: 'high', reasoning: 'medium' }`. */
    readonly capabilities: Readonly<Record<string, CapabilityLevel>>;
    /** Tools the candidate must expose, e.g. `repo`, `research`. */
    readonly tools?: readonly string[] | undefined;
    /** Prompt plus output tokens this role must hold in one context window. */
    readonly minContextTokens?: number | undefined;
    /** Role ids this role must not share a candidate with. */
    readonly independentFrom?: readonly string[] | undefined;
    /** Cost classes this role may use at all, whatever the policy prefers. */
    readonly allowedCostClasses?: readonly RoutingCostClass[] | undefined;
    /** Output tokens this role is expected to produce, when it differs from the run default. */
    readonly estimatedOutputTokens?: number | undefined;
}
/**
 * One thing that could do the work: a model on a provider, a CLI seat, or a
 * local worker on a named machine.
 *
 * Throughput, queue depth and quota are the volatile fields. They come from
 * the registry at launch rather than from the preset, which is what lets a
 * hardware upgrade change routing without a code or policy edit.
 */
export interface Candidate {
    readonly id: string;
    /** Routing key the launcher runs on: a seat id or a provider name. */
    readonly provider: string;
    /** Model id, where the provider serves more than one. */
    readonly model?: string | undefined;
    readonly costClass: RoutingCostClass;
    /** Capability levels this candidate offers. Anything unlisted counts as `none`. */
    readonly capabilities: Readonly<Record<string, CapabilityLevel>>;
    /** Tools the candidate exposes. */
    readonly tools?: readonly string[] | undefined;
    /** Usable context window in tokens. */
    readonly contextTokens: number;
    /** Measured output tokens per second. Registry data, never a constant in policy code. */
    readonly throughputTokensPerSecond: number;
    /** Units already queued ahead of this one. */
    readonly queueDepth?: number | undefined;
    /** Seconds before the first token, covering process start and scheduling. */
    readonly startupSeconds?: number | undefined;
    /** False when the seat is down, signed out, or parked on a quota hold. */
    readonly available: boolean;
    /** Why it is unavailable, carried through to the decision trace. */
    readonly unavailableReason?: string | undefined;
    /** Remaining quota for this window, as a fraction from 0 to 1. Absent means unmetered. */
    readonly quotaHeadroom?: number | undefined;
    /** Metered price per output token, in USD. Absent for local, free and included candidates. */
    readonly usdPerOutputToken?: number | undefined;
    /** Share of runs that have needed a retry, from 0 to 1. */
    readonly retryRate?: number | undefined;
    /** True when the work never leaves the team's own machines. */
    readonly local?: boolean | undefined;
    /** Machine this candidate runs on, used to pick up that machine's profile. */
    readonly machineId?: string | undefined;
    /** Candidate ids this one may not be paired with, for provider-level independence. */
    readonly siblingOf?: readonly string[] | undefined;
    /** Who pays for this candidate's calls. Absent for a candidate outside the coverage axis. */
    readonly coverage?: Coverage | undefined;
    /** Set when the quota reader refused this candidate's coverage; the filter rejects it with this code. */
    readonly coverageRefusal?: CoverageRefusal | undefined;
}
/** Routing policies. Each one is a different weighting of the same factors, never a different filter. */
export declare const routingPolicies: readonly ["TOKEN_EFFICIENT", "FREE_FIRST", "SUBSCRIPTION_FIRST", "PAID_FASTEST", "LOCAL_FIRST", "FIXED_ROSTER", "USER_JOB_PROFILE"];
/** One routing policy. */
export type RoutingPolicy = (typeof routingPolicies)[number];
/**
 * Everything about this run that is not a role or a candidate.
 *
 * `allowedCandidateIds` and `requiredRoster` are entitlement, not preference:
 * they are applied in the hard filter, so no weight can route around them.
 */
export interface RoutingContext {
    readonly policy: RoutingPolicy;
    /** Candidates this user, team or job may use at all. Absent means no entitlement restriction. */
    readonly allowedCandidateIds?: readonly string[] | undefined;
    /** Role id to candidate id, for `FIXED_ROSTER` and for a pinned role under any policy. */
    readonly requiredRoster?: Readonly<Record<string, string>> | undefined;
    /** Output tokens a role is expected to produce when it does not say. */
    readonly estimatedOutputTokens: number;
    /** Prompt tokens the compiled context is expected to carry. */
    readonly estimatedPromptTokens: number;
    /** Seconds a role may take before the route counts as too slow. Absent means no deadline. */
    readonly latencyBudgetSeconds?: number | undefined;
    /** USD left in the budget. A metered candidate that would exceed it is filtered out. */
    readonly budgetUsdRemaining?: number | undefined;
    /** Quota fraction below which a candidate is treated as exhausted. Defaults to 0.05. */
    readonly minQuotaHeadroom?: number | undefined;
    /** True when the work may not leave the team's machines. */
    readonly requireLocality?: boolean | undefined;
    /** True when an `uncovered` candidate may create a real charge. Absent means false. */
    readonly realMoneyAllowed?: boolean | undefined;
}
/** Why a candidate was rejected. One code per reason, so a trace can be read without prose. */
export type RejectionCode = 'INCAPABLE' | 'MISSING_TOOL' | 'CONTEXT_TOO_SMALL' | 'UNAUTHORIZED' | 'NOT_IN_ROSTER' | 'UNAVAILABLE' | 'QUOTA_EXHAUSTED' | 'OVER_BUDGET' | 'COST_CLASS_FORBIDDEN' | 'LOCALITY_REQUIRED' | 'LATENCY_RISK' | 'NOT_INDEPENDENT' | CoverageRejectionCode;
/** One candidate refused for one role, with the code and a readable detail. */
export interface Rejection {
    readonly roleId: string;
    readonly candidateId: string;
    readonly code: RejectionCode;
    readonly detail: string;
}
/** The scored factors behind one assignment, each normalized from 0 to 1. */
export interface ScoreFactors {
    readonly capability: number;
    readonly speed: number;
    readonly cost: number;
    readonly quota: number;
    readonly load: number;
    readonly locality: number;
    readonly reliability: number;
    readonly latency: number;
}
/** One role, the candidate that won it, and why. */
export interface Assignment {
    readonly roleId: string;
    readonly candidateId: string;
    readonly provider: string;
    readonly model?: string | undefined;
    readonly costClass: RoutingCostClass;
    readonly score: number;
    readonly factors: ScoreFactors;
    /** Seconds this role is expected to take on this candidate. */
    readonly estimatedSeconds: number;
    /** Estimated metered spend for this role, in USD. Zero for local, free and included. */
    readonly estimatedUsd: number;
    /** One phrase for a panel, e.g. "local, capable, no metered spend". */
    readonly reason: string;
    /** Set when the policy's first preference was passed over, e.g. local escalated to a subscription. */
    readonly escalatedFrom?: string | undefined;
    readonly escalationReason?: string | undefined;
}
/** What the router decided, including everything it refused. */
export interface Resolution {
    readonly policy: RoutingPolicy;
    readonly assignments: readonly Assignment[];
    /** Roles no eligible candidate could fill. */
    readonly unfilled: readonly string[];
    /** Every rejection, in the order they were made. */
    readonly rejections: readonly Rejection[];
    readonly estimatedUsd: number;
    /** Seconds for the slowest role, which is what a wave actually costs in wall clock. */
    readonly estimatedSeconds: number;
}
//# sourceMappingURL=types.d.ts.map