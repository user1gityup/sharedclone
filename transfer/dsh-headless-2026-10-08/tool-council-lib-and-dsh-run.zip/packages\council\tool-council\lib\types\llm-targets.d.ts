/**
 * Local model targets on disk and on the wire: the I/O half of
 * `router/local-targets.ts`.
 *
 * Reads the published target records, probes each host's model list for
 * liveness and the model in VRAM, and points a `local` seat at whichever host
 * serves its model. A seat that used to hard-code `127.0.0.1:8090` therefore
 * works on a machine without a GPU, through the serving host's relay, and
 * drops out cleanly when no host serves it.
 */
import type { LocalTarget, ResolvedLocalTarget, TargetHealth } from './router/local-targets.ts';
import type { SeatConfig } from './seats.ts';
/**
 * Where published target records live, overridable for tests and other layouts.
 * @param env - environment lookup, consulted for `DSH_LLM_TARGETS_DIR` (defaults to `process.env`).
 * @returns the target-records directory: the override when set and non-empty, else `~/.claude/shared-brain/relay/llm-targets`.
 */
export declare function defaultTargetsDir(env?: Readonly<Record<string, string | undefined>>): string;
/**
 * Every well-formed target record in `dir`. A missing directory or a broken
 * record is skipped, never thrown: no targets means no local class, which the
 * router already handles by escalating.
 * @param dir - the directory to read target JSON files from (defaults to `defaultTargetsDir()`).
 * @returns every parsed target record, in filename order.
 */
export declare function loadLocalTargets(dir?: string): LocalTarget[];
/** How long a probe result stands before the host is asked again. */
export declare const TARGET_HEALTH_TTL_MS = 30000;
/** Forget cached probe results; for tests. */
export declare function clearTargetHealthCache(): void;
/**
 * Probe one host by listing its models: cheap, and it never loads a model.
 * The llama.cpp router marks the model in VRAM with `status.value: "loaded"`,
 * and the relay reports its in-flight count in `x-relay-inflight`.
 * @param target - the published target record to probe.
 * @param machine - the local hostname routing resolves against, to reach the target directly or via its relay.
 * @param token - the relay bearer token, when the resolved route goes through one.
 * @param timeoutMs - how long to wait for the host to answer before treating it as unreachable.
 * @param now - clock used to timestamp and expire the cached result; injectable for tests.
 * @returns the host's liveness, loaded model (if any), and in-flight count, cached for `TARGET_HEALTH_TTL_MS`.
 */
export declare function probeTarget(target: LocalTarget, machine: string, token: string | undefined, timeoutMs?: number, now?: () => number): Promise<TargetHealth>;
/** Inputs for pointing a local seat at a target; injectable for tests. */
export interface LocalSeatRouting {
    readonly targets?: readonly LocalTarget[] | undefined;
    readonly machine?: string | undefined;
    readonly env?: Readonly<Record<string, string | undefined>> | undefined;
    readonly dshHome?: string | undefined;
    /** Probe hosts before choosing. Off means every published host counts as live. */
    readonly probe?: boolean | undefined;
}
/** What routing did to one local seat. */
export interface LocalSeatRoute {
    readonly seat: SeatConfig;
    readonly target?: ResolvedLocalTarget | undefined;
    /** Why the seat was left as configured. */
    readonly reason?: string | undefined;
}
/**
 * Point a `local` seat at the host that serves its model.
 *
 * Seats that are not local, and local seats when no target records exist at
 * all, come back unchanged: a machine that has never published a target keeps
 * the configured loopback URL it had before this module existed.
 * @param seat - the seat configuration to route.
 * @param routing - target records, machine identity, and probing options for the resolution.
 * @returns the seat as routed (or disabled with a reason when no live host serves it), plus that reason.
 */
export declare function routeLocalSeat(seat: SeatConfig, routing?: LocalSeatRouting): Promise<LocalSeatRoute>;
//# sourceMappingURL=llm-targets.d.ts.map