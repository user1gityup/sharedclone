/**
 * Durable record of a finished council run, so a degraded one can be amended
 * instead of re-run.
 *
 * A council round waits for every seat and keeps whatever comes back, so one
 * seat timing out does not lose the round — but until now it did lose that
 * seat's answer permanently. The only way to get a complete run was to ask the
 * whole council again: a second planning round, a second draft from every seat
 * that had already answered, and a second bill, all to recover the two that
 * failed. Measured 2026-09-07: a stage-2 run cost 12m29s and returned three
 * drafts of five, with both hosted seats cut off at the timeout.
 *
 * So a finished run is written here, and {@link amendRun} re-asks only the
 * seats that failed. Everything that answered the first time is kept exactly
 * as it was — including the votes, which is why the report has to say which
 * reviews were cast before a recovered draft existed rather than quietly
 * presenting them as judgements on the full field.
 *
 * Records live in `$HOME/.dsh/council-runs`, not in settings: a draft is
 * thousands of words, and settings is read whole on every tool invocation.
 */
import type { SeatId } from './colors.ts';
import type { SeatReview } from './council.ts';
import type { SeatReply } from './seats.ts';
import type { RoleRoute } from './route-council.ts';
/** How many finished runs are kept before the oldest are pruned. */
export declare const RUN_HISTORY = 20;
/** How many times one run may be amended, so a loop cannot spend forever. */
export declare const MAX_AMENDMENTS = 3;
/**
 * Explicit lifecycle state of a finished or suspended run.
 *
 * A run that ends with fewer successful drafts than the configured quorum is
 * `partial`, not `completed`. Callers must not present a partial run as a
 * council decision. `awaiting_resume` means the user pressed Stop; the journal
 * was not discarded and Continue can pick up from here.
 */
export type RunTerminalState = 'completed' | 'partial' | 'cancelled' | 'failed' | 'awaiting_resume';
/**
 * How many seats must succeed for a round to constitute a council decision.
 *
 * A quorum of zero disables the check and preserves the prior behaviour where
 * a single successful draft can win as `sole-draft`. A configured minimum
 * stops a one-answer result from being presented as a council verdict.
 */
export interface QuorumConfig {
    /** Minimum successful drafts to call a run `completed`. 0 = no check. */
    readonly minDrafts: number;
    /** Minimum successful reviews to call a run `completed`. 0 = no check. */
    readonly minReviews: number;
}
/**
 * Sizes of one seat's prompt, recorded before the call is made.
 *
 * These are the numbers that decide which transport was chosen and whether
 * compaction occurred, so they are captured at decision time, not reconstructed
 * afterwards.
 */
export interface PromptMetric {
    readonly seat: SeatId;
    readonly round: string;
    /** Total characters in the final prompt sent. */
    readonly promptChars: number;
    /** Total UTF-8 bytes. */
    readonly promptBytes: number;
    /** Characters in the query section. */
    readonly queryChars: number;
    /** Characters in the plan section, when present. */
    readonly planChars: number;
    /** Characters in the evidence section, when present. */
    readonly evidenceChars: number;
    /** Characters in the memory section, when present. */
    readonly memoryChars: number;
    /** Which transport was selected: `cli` or `openrouter`. */
    readonly transport: string;
    /** Character limit for this seat, from seat config or platform. */
    readonly seatLimit: number;
    /** Whether prompt compaction ran to stay below the limit. */
    readonly compacted: boolean;
}
/** A finished run, with everything an amendment needs to fill its holes. */
export interface RunRecord {
    readonly id: string;
    /** The question the run answered — the amendment asks the same one. */
    readonly query: string;
    /** Epoch ms the run finished. */
    readonly at: number;
    /** The agreed plan, so a recovered draft is written to the same direction. */
    readonly plan?: string | undefined;
    /** The shared evidence block as the first drafts saw it. */
    readonly evidenceBlock?: string | undefined;
    readonly evidenceUrls?: readonly string[] | undefined;
    /** Seats the run was configured with, by id. */
    readonly seatIds: readonly SeatId[];
    readonly drafts: readonly SeatReply[];
    readonly reviews: readonly SeatReview[];
    /** Amendments already spent on this run. */
    readonly amendments: number;
    /**
     * Explicit terminal state. Absent in records written before this field was
     * added; treated as `completed` by callers for backward compatibility.
     */
    readonly terminalState?: RunTerminalState | undefined;
    /** Quorum thresholds the run was configured with, when set. */
    readonly quorumConfig?: QuorumConfig | undefined;
    /** Per-seat prompt sizes, captured before each call. */
    readonly promptMetrics?: readonly PromptMetric[] | undefined;
    /** Planner choice beside the router's shadow pick and everything it refused. */
    readonly plannerRoute?: RoleRoute | undefined;
    /** Schema version, for future migrations. Absent means 1. */
    readonly schemaVersion?: number | undefined;
}
/**
 * Where run records live.
 * @returns the absolute path of the run-records directory under the user's home.
 */
export declare function runsDirectory(): string;
/**
 * A fresh run id.
 * @returns a random UUID, unique per run.
 */
export declare function newRunId(): string;
/**
 * Which seats came back empty, per round.
 * @param record - the run to inspect.
 * @returns the seats worth asking again.
 */
export declare function failedSeats(record: RunRecord): {
    readonly drafts: readonly SeatId[];
    readonly reviews: readonly SeatId[];
};
/**
 * Whether a run has any hole an amendment could fill.
 * @param record - the run to inspect.
 * @returns true when the amendment cap has not been reached and a draft or review is missing.
 */
export declare function isAmendable(record: RunRecord): boolean;
/**
 * Write a run record, pruning the oldest once the history is full.
 *
 * Never throws: a run that answered must not fail at the last step because its
 * record could not be filed. The caller learns from the returned path whether
 * amending is available.
 * @param record - the finished run.
 * @returns the file written, or undefined when the write failed.
 */
export declare function saveRun(record: RunRecord): string | undefined;
/**
 * A planner route held as JSON in settings, or undefined when absent or malformed.
 * @param text - the raw stored JSON, or undefined when nothing is held.
 * @returns the parsed and validated route, or undefined when there is nothing to parse or it fails validation.
 */
export declare function parseHeldRoute(text: string | undefined): RoleRoute | undefined;
/**
 * Load one run by id.
 * @param id - the run id, as the report printed it.
 * @returns the record, or undefined when it is unknown or unreadable.
 */
export declare function loadRun(id: string): RunRecord | undefined;
/**
 * The most recent run, for a user who says "try that again" without an id.
 * @returns the newest record, or undefined when none is stored.
 */
export declare function latestRun(): RunRecord | undefined;
/**
 * What the user has said about a run, kept beside the records rather than in
 * them: rewriting a record would change its mtime, and mtime is the order the
 * history prunes by, so renaming an old run must not make it look new.
 */
export interface RunMeta {
    readonly label?: string | undefined;
    readonly pinned?: boolean | undefined;
}
/** How many runs may be pinned, so pinning cannot grow the directory without bound. */
export declare const MAX_PINNED = 50;
/** The longest label a run may carry. */
export declare const MAX_RUN_LABEL = 120;
/**
 * Where run labels and pins live: a subdirectory, so the record listing and
 * the pruning never mistake it for a run.
 * @returns the absolute path of the metadata file.
 */
export declare function runMetaPath(): string;
/**
 * Labels and pins by run id; empty when none are stored or the file is unreadable.
 * @returns the metadata map.
 */
export declare function readRunMeta(): Readonly<Record<string, RunMeta>>;
/** One line of the run history, without the drafts. */
export interface RunSummary {
    readonly id: string;
    readonly query: string;
    readonly at: number;
    readonly terminalState: RunTerminalState;
    readonly drafts: number;
    readonly draftsOk: number;
    readonly label?: string | undefined;
    readonly pinned: boolean;
}
/**
 * Every stored run, newest first, with its label and pin.
 * @returns the summaries; empty when nothing is stored.
 */
export declare function listRuns(): readonly RunSummary[];
/** What a history edit produced. */
export interface RunEdit {
    readonly ok: boolean;
    readonly problem?: string | undefined;
}
/**
 * Give a run a label, or clear it with an empty string.
 * @param id - the run id.
 * @param label - the new label.
 * @returns whether it was written.
 */
export declare function renameRun(id: string, label: string): RunEdit;
/**
 * Pin a run so pruning keeps it, or unpin it.
 * @param id - the run id.
 * @param pinned - the new state.
 * @returns whether it was written.
 */
export declare function pinRun(id: string, pinned: boolean): RunEdit;
/**
 * Delete one run record and its label. The shared-brain line stays: it is a
 * log of what ran, and other machines have already read it. A filesystem
 * failure throws, for the calling tool to report.
 * @param id - the run id.
 * @returns whether it was removed.
 */
export declare function deleteRun(id: string): RunEdit;
//# sourceMappingURL=runs.d.ts.map