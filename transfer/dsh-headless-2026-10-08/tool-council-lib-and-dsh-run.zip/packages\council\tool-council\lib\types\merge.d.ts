import type { SeatConfig, SeatReply } from './seats.ts';
/** A quoted piece of a rival plan, supported by distinct seats. */
export interface PlanPiece {
    readonly source: string;
    readonly quote: string;
    readonly supporters: readonly string[];
}
/** The original winner remains the author even when integration fails. */
export interface PlanMerge {
    readonly plan: string;
    readonly accepted: readonly PlanPiece[];
    readonly nominations: readonly SeatReply[];
    readonly integration?: SeatReply | undefined;
}
/**
 * Count only exact, attributed excerpts and one endorsement per voter.
 * @param replies - each seat's nomination reply (a JSON array of `{source, quote}`).
 * @param drafts - the rival drafts a nomination may quote from.
 * @param winner - the winning seat, whose own plan cannot be nominated as a rival piece.
 * @returns the distinct pieces with at least two supporters, each with its supporter list.
 */
export declare function acceptedPieces(replies: readonly SeatReply[], drafts: readonly SeatReply[], winner: string): PlanPiece[];
/**
 * Ask for attributed nominations, then let only the winner revise its plan.
 * @param query - the original request, echoed into both prompts.
 * @param winner - the plan vote's winning reply.
 * @param drafts - every seat's draft, searched for the rival plans a nomination may quote.
 * @param seats - the seats asked to nominate pieces.
 * @param ask - sends one prompt to one seat and returns its reply.
 * @param sequential - ask seats one at a time instead of in parallel.
 * @returns the (possibly revised) plan, the accepted pieces, the raw nominations, and the winner's integration reply.
 */
export declare function mergePlan(query: string, winner: SeatReply, drafts: readonly SeatReply[], seats: readonly SeatConfig[], ask: (seat: SeatConfig, prompt: string) => Promise<SeatReply>, sequential?: boolean): Promise<PlanMerge>;
//# sourceMappingURL=merge.d.ts.map