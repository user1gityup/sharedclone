/**
 * The council's bridge to the weight router, in shadow.
 *
 * The council itself makes one routing decision: which seat writes the plan.
 * Every enabled seat drafts and every enabled seat reviews, because the point
 * of a council is hearing all of them, so there is nothing else to route
 * there. The swarm's unit contest makes the other one worth tracing: which
 * seat writes a unit and which seat reviews it, where the reviewer must never
 * be the author.
 *
 * Neither decision is handed to the router yet. The existing rules still
 * choose, and the router resolves the same field beside them, so a run record
 * shows what it would have picked and everything it refused. That trace is the
 * evidence for letting it decide later, and it is what answers "why did this
 * run plan on the metered seat" after the run is over.
 */
import type { ModelPrice } from './estimate.ts';
import type { Worker } from './roster.ts';
import type { SubTask } from './decompose.ts';
import type { SeatConfig } from './seats.ts';
import type { SeatState } from './route-swarm.ts';
import type { Rejection, RoutingPolicy } from './router/index.ts';
/** One role, the seat the existing rules chose, and the router's shadow pick. */
export interface RoleRoute {
    readonly roleId: string;
    /** Seat the existing rules chose; undefined when none was chosen. */
    readonly chosen?: string | undefined;
    /** Seat the router would pick; undefined when it could fill the role with nobody. */
    readonly routerPick?: string | undefined;
    readonly policy: RoutingPolicy;
    readonly rejections: readonly Rejection[];
}
/**
 * Shadow-route the council's planner.
 *
 * The planner role asks for no capability: every seat can write a plan, and
 * what separates them is cost, quota and whether they are up at all. The
 * council's own rule prefers a metered seat for its known price; the router
 * under TOKEN_EFFICIENT prefers the cheapest scarce resource, so the two are
 * expected to disagree, and that disagreement is what the trace is for.
 * @param seats - the active roster.
 * @param chosen - seat that actually wrote the plan, when one did.
 * @param pricing - OpenRouter price table; empty leaves metered seats unpriced.
 * @param state - live seat state keyed by seat id.
 * @returns the planner route.
 */
export declare function routePlanner(seats: readonly SeatConfig[], chosen: string | undefined, pricing?: ReadonlyMap<string, ModelPrice>, state?: Readonly<Record<string, SeatState>>): RoleRoute;
/**
 * Shadow-route a contest unit's author and reviewer.
 *
 * The coder role is pinned to the seat that actually produced the artifact, so
 * the reviewer's independence is judged against the real author rather than
 * against whoever the router would have preferred to write it. The reviewer
 * role carries `independentFrom: ['coder']`, which is the rule the contest
 * enforces by hand: a seat never marks its own candidate ACCEPT.
 * @param task - the unit.
 * @param workers - enabled workers for this run.
 * @param seats - configured seats, for models and prices.
 * @param coder - seat that produced the artifact under review.
 * @param reviewer - seat that reviewed it.
 * @param profile - the run's swarm profile; `fastest` routes under PAID_FASTEST.
 * @param pricing - OpenRouter price table.
 * @param state - live seat state keyed by seat id.
 * @returns one route per role, coder first.
 */
export declare function routeContest(task: SubTask, workers: readonly Worker[], seats: readonly SeatConfig[], coder: string, reviewer: string | undefined, profile: string | undefined, pricing: ReadonlyMap<string, ModelPrice>, state?: Readonly<Record<string, SeatState>>): readonly RoleRoute[];
//# sourceMappingURL=route-council.d.ts.map