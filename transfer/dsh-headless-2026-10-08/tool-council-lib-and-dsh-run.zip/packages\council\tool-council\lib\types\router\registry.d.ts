/**
 * The registry seam: where candidates and machine profiles come from.
 *
 * Routing behaviour changes when hardware changes, and it must change without
 * anyone editing policy code. So throughput, queue depth, context size and
 * quota live in data — a settings block, a machine registry note, or whatever
 * later supplies it — and the router reads that data through this one seam.
 *
 * The functions here are pure. Reading a file, calling a provider or polling a
 * seat broker belongs to the caller; the router must stay testable without any
 * of that.
 */
import type { Candidate, CapabilityLevel, RoutingCostClass } from './types.ts';
/**
 * A machine's measured performance.
 *
 * `throughputTokensPerSecond` is deliberately optional: a machine whose speed
 * has never been measured must not be given a guessed number, because the
 * guess would silently decide routing. A candidate on such a machine keeps
 * whatever throughput its own entry declares.
 */
export interface MachineProfile {
    readonly id: string;
    readonly throughputTokensPerSecond?: number | undefined;
    /** Units the machine will run at once. */
    readonly slots?: number | undefined;
    /** Units already queued on it. */
    readonly queueDepth?: number | undefined;
    /** False while the owner is using the machine or it is otherwise out of the pool. */
    readonly available?: boolean | undefined;
    readonly unavailableReason?: string | undefined;
}
/** Plain data a caller can hold in settings, a note, or a database row. */
export interface RegistryData {
    readonly candidates: readonly Candidate[];
    readonly machines?: readonly MachineProfile[] | undefined;
}
/** Candidates with their machine profiles already applied. */
export interface Registry {
    readonly candidates: readonly Candidate[];
    readonly machines: ReadonlyMap<string, MachineProfile>;
}
/**
 * Apply machine profiles to the candidates that run on them.
 *
 * A machine entry wins over the candidate's own figures, because the machine
 * is where the measurement was taken. An unmeasured machine changes nothing
 * except availability, so a deferred throughput figure cannot leak in as an
 * accidental zero.
 * @param data - the raw candidates and machine profiles as the caller stored them.
 * @returns the candidates with their machine's throughput, queue depth, and availability applied, plus the machine map.
 */
export declare function buildRegistry(data: RegistryData): Registry;
/**
 * The level a candidate offers for one capability. Anything unlisted is `none`.
 * @param candidate - the candidate to read.
 * @param capability - the capability key to look up.
 * @returns the candidate's declared level for that capability, or `'none'` when it declares none.
 */
export declare function capabilityOf(candidate: Candidate, capability: string): CapabilityLevel;
/**
 * True when this cost class spends no money and no subscription quota.
 * @param costClass - the routing cost class to classify.
 * @returns true for `local` or `free`.
 */
export declare function isZeroMarginalCost(costClass: RoutingCostClass): boolean;
//# sourceMappingURL=registry.d.ts.map