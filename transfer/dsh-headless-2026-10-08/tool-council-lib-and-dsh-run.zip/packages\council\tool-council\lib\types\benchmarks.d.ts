/**
 * Published coding-agent benchmark constants.
 *
 * Sourced from Artificial Analysis' Coding Agent Index v1.4 (composite of
 * DeepSWE, Terminal-Bench v2.1, and SWE-Atlas-QnA), read 2026-08-26. These are
 * measured figures for a specific harness/model pairing on a specific task
 * suite — they are a far better guide than token arithmetic for "how good, how
 * fast, how expensive", but they describe that suite, not your repository.
 *
 * Two limits worth carrying wherever these are used:
 *  - Cost is pay-per-token API cost. A seat billed through a subscription pays
 *    none of it, so a subscription seat's benchmark cost is what it WOULD cost
 *    metered, not what it costs you.
 *  - The benchmark pairs each model with one harness. A different harness moves
 *    the score; the site publishes a harness comparison showing exactly that.
 *
 * @see https://artificialanalysis.ai/agents/coding-agents
 */
/** One benchmarked agent/model pairing. */
export interface Benchmark {
    /** Harness and model, as the source names it. */
    readonly label: string;
    /** Coding Agent Index v1.4 composite; higher is better. */
    readonly index: number;
    /** Average pay-per-token API cost per task, USD. */
    readonly costPerTaskUsd: number;
    /** Average wall-clock runtime per task, minutes. */
    readonly minutesPerTask: number;
}
/** The published table, keyed by the council seat it informs. */
export declare const BENCHMARKS: Readonly<Record<string, Benchmark>>;
/** How a council compares with working through one seat alone. */
export interface CouncilComparison {
    /** Seats contributing a benchmarked figure. */
    readonly seats: readonly {
        id: string;
        benchmark: Benchmark;
        metered: boolean;
    }[];
    /** Best index among the participating seats. */
    readonly bestIndex: number;
    /** Mean index across participating seats. */
    readonly meanIndex: number;
    /** Metered API cost for one full council run, both rounds. */
    readonly meteredCostPerRun: number;
    /** What the same run would cost if every seat were billed per token. */
    readonly unmeteredEquivalent: number;
    /** Wall-clock minutes for one full run: rounds x slowest seat. */
    readonly minutesPerRun: number;
    /** Minutes the single best seat would take for one answer. */
    readonly soloMinutes: number;
    /** Distinct answers the council compares. */
    readonly perspectives: number;
}
/**
 * Compare a council configuration against its single strongest seat.
 *
 * Wall time assumes seats are asked concurrently, so a round costs the slowest
 * seat rather than the sum — which is the entire reason the council fans out.
 * @param seatIds - participating seat ids.
 * @param metered - which of those seats pay per token.
 * @returns the comparison, or undefined when no seat is benchmarked.
 */
export declare function compareCouncil(seatIds: readonly string[], metered: (id: string) => boolean): CouncilComparison | undefined;
/**
 * Render the comparison for the console.
 * @param comparison - the computed comparison.
 * @returns lines ready to print.
 */
export declare function renderComparison(comparison: CouncilComparison): readonly string[];
//# sourceMappingURL=benchmarks.d.ts.map