/**
 * Shared evidence for the drafting round.
 *
 * Only CLI seats carry tools. An OpenRouter seat is a bare chat completion —
 * no search, no fetch, no filesystem — so asked for something specific and
 * current it cannot know, it will often emit tool-call syntax it has no way to
 * execute and then report training data as though it had been verified. The
 * seat is not being dishonest; nothing ever told it the tools were absent.
 *
 * Rather than buy every seat its own metered search, the council runs one
 * search through the harness web seam, whose router prefers a route already
 * paid for by subscription, and hands the same sources to every seat. One
 * search, shared evidence, and no seat needs to invent a citation.
 */
/** One retrieved source. Mirrors the web seam's shape, structurally. */
export interface EvidenceSource {
    readonly url: string;
    readonly title?: string | undefined;
    readonly snippet?: string | undefined;
    readonly publishedAt?: string | undefined;
}
/** The subset of the web seam this module needs, so tests need no host. */
export interface SearchSeam {
    search(request: {
        readonly query: string;
        readonly maxResults?: number;
    }, signal?: AbortSignal): Promise<{
        readonly content?: string | undefined;
        readonly sources: readonly EvidenceSource[];
    }>;
}
/** Retrieved evidence, ready to paste into a prompt. */
export interface Evidence {
    /** Prompt-ready block, numbered so seats can cite by index. */
    readonly block: string;
    /** Source URLs in citation order, for later verification. */
    readonly urls: readonly string[];
}
/**
 * Run one search and render it as shared evidence.
 *
 * Failure is not fatal: a council that cannot search is still a council, and a
 * seat told plainly that no evidence was retrieved behaves far better than one
 * left to guess whether it has tools. Returns undefined so the caller can say
 * exactly that.
 * @param seam - the web seam, or undefined when the host mounts none.
 * @param query - the user's question.
 * @param signal - cancellation from the run.
 * @returns the evidence, or undefined when nothing could be retrieved.
 */
export declare function gatherEvidence(seam: SearchSeam | undefined, query: string, signal?: AbortSignal): Promise<Evidence | undefined>;
/** Search queries requested per seat. Bounds one seat from spending the round. */
export declare const MAX_QUERIES_PER_SEAT = 3;
/** Total queries run per council, however many seats asked. */
export declare const MAX_QUERIES_TOTAL = 8;
/**
 * Searches the research round runs at once.
 *
 * The round's cost is fixed by the query count; its wall time is not. Run one
 * at a time — which is what this did — five seats asking for three lookups
 * each becomes eight sequential CLI searches at roughly 15-25s apiece, so the
 * council sits idle for two to three minutes before a single draft starts.
 *
 * Three rather than two: the seam routes across two authenticated CLI lanes,
 * and a third in flight keeps a lane from going idle in the gap while another
 * finishes. Higher spawns more CLI processes than the lanes can absorb, which
 * buys nothing and risks a provider's own rate limit.
 */
export declare const DEFAULT_RESEARCH_CONCURRENCY = 3;
/**
 * Prompt asking a seat what it wants looked up.
 *
 * Deliberately cheap: a seat answers with query lines, not prose, so this
 * round costs a few hundred tokens and buys searches that are free. The
 * alternative — giving every seat its own metered web plugin — costs roughly
 * 25x per call for the same information.
 * @param query - the user's question.
 * @param plan - the agreed approach, when there is one.
 * @param extra - a further request section, such as the one asking for files.
 *   Empty when the host grants nothing beyond search.
 * @returns the prompt.
 */
export declare function researchPrompt(query: string, plan: string | undefined, extra?: string): string;
/**
 * Pull search requests out of a seat's reply.
 * @param text - the seat's reply.
 * @param max - most queries to accept from this seat.
 * @returns the requested queries, trimmed and deduplicated.
 */
export declare function parseSearchRequests(text: string, max?: number): readonly string[];
/** One seat's requested queries. */
export interface SeatQueries {
    readonly seat: string;
    readonly queries: readonly string[];
}
/**
 * Run every requested query through the seam and render one shared block.
 *
 * All searches go through the same seam the council already uses, whose router
 * prefers a route already paid for by subscription — so a seat asking for
 * three lookups costs nothing beyond the tokens it used to ask.
 * @param seam - the web seam, or undefined when the host mounts none.
 * @param requests - what each seat asked for.
 * @param signal - cancellation from the run.
 * @param concurrency - how many deduplicated queries run at once.
 * @returns the evidence, or undefined when nothing could be retrieved.
 */
export declare function gatherRequested(seam: SearchSeam | undefined, requests: readonly SeatQueries[], signal?: AbortSignal, concurrency?: number): Promise<Evidence | undefined>;
//# sourceMappingURL=evidence.d.ts.map