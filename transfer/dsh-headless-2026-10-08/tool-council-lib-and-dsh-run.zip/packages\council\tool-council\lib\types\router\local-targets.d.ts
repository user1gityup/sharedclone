/**
 * Local model targets: which machine on the network serves which local model,
 * and how this machine reaches it.
 *
 * Not every machine has a GPU. A machine that serves a local model publishes
 * one target record (the brain's `relay/llm-targets/<host>.json`, written by
 * `.sync/llama-relay.mjs publish`); a machine without one publishes nothing.
 * This module turns those records into a concrete endpoint for one request:
 * the serving host itself goes straight to its loopback router, any other host
 * goes through that host's token-gated relay, and no usable target at all
 * returns undefined so the caller's policy escalates to a free or included
 * class instead.
 *
 * Pure, like the rest of the router: records and liveness come in, a choice
 * comes out. Reading the directory and probing hosts is the caller's job.
 */
import type { Candidate, CapabilityLevel } from './types.ts';
/** One model a target serves, with whatever was measured on that host. */
export interface LocalTargetModel {
    readonly id: string;
    /** Measured decode tokens per second on this host. */
    readonly tokensPerSecond?: number | undefined;
    /** Measured seconds to load this model cold. */
    readonly loadSeconds?: number | undefined;
    /** Context window this host can actually run the model at. */
    readonly contextTokens?: number | undefined;
    /** Capability levels, e.g. `{ coding: 'medium' }`. */
    readonly capabilities?: Readonly<Record<string, CapabilityLevel>> | undefined;
}
/** One serving host, as published in `relay/llm-targets/<host>.json`. */
export interface LocalTarget {
    readonly host: string;
    /** The router on the serving host's loopback, e.g. `http://127.0.0.1:8090`. */
    readonly upstream: string;
    /** Models that fit in VRAM at once; one GPU means one. */
    readonly maxLoaded?: number | undefined;
    readonly relay?: {
        readonly port?: number | undefined;
        /** Credential reference holding this machine's relay token. */
        readonly tokenRef?: string | undefined;
        readonly routes?: Readonly<Record<string, string | null | undefined>> | undefined;
    } | undefined;
    readonly models: readonly LocalTargetModel[];
}
/** What a liveness probe learned about one host. */
export interface TargetHealth {
    readonly live: boolean;
    /** The model the router has in VRAM now, when it reports one. */
    readonly loadedModel?: string | undefined;
    /** Requests the relay is serving right now. */
    readonly inflight?: number | undefined;
    readonly reason?: string | undefined;
}
/** One request for a local model. */
export interface LocalTargetRequest {
    /** This machine's host name, as the records spell it. */
    readonly machine: string;
    /** An exact model id, when the caller pins one. */
    readonly model?: string | undefined;
    /** A capability the model must list at `low` or better. */
    readonly capability?: string | undefined;
    /** Context the request needs; a model with no measured context does not qualify. */
    readonly minContext?: number | undefined;
    /** Relay route to prefer for another host. Defaults to `lan`, then `tunnel`. */
    readonly route?: string | undefined;
    /** Liveness by host. A host marked not live is skipped; an unprobed host is tried. */
    readonly health?: ReadonlyMap<string, TargetHealth> | undefined;
}
/** Where one request should go. */
export interface ResolvedLocalTarget {
    readonly host: string;
    readonly model: string;
    /** Origin to append `/v1/...` to, with no trailing slash. */
    readonly baseUrl: string;
    /** True when the request crosses the network to another host's relay. */
    readonly viaRelay: boolean;
    /** Credential reference for the relay token, when `viaRelay`. */
    readonly tokenRef?: string | undefined;
    /** The model is already in VRAM, so no 13-57 s swap. */
    readonly warm: boolean;
    readonly inflight: number;
    readonly tokensPerSecond?: number | undefined;
}
/** Credential reference the relay token is kept under by default. */
export declare const DEFAULT_RELAY_TOKEN_REF = "LLAMA_RELAY_TOKEN";
/**
 * Every endpoint that could serve the request, best first.
 *
 * Order: a model already in VRAM first (a swap costs 13-57 s, the LAN costs
 * milliseconds), then the host with fewer requests in flight (one GPU serves
 * one at a time), then this machine's own host, then measured throughput.
 * @param targets - every published target record.
 * @param request - what the caller needs and where it runs.
 * @returns every qualifying endpoint, best first.
 */
export declare function rankLocalTargets(targets: readonly LocalTarget[], request: LocalTargetRequest): ResolvedLocalTarget[];
/**
 * The one endpoint a request should use, or undefined when no host can serve it.
 * @param targets - every published target record.
 * @param request - what the caller needs and where it runs.
 * @returns the chosen endpoint, or undefined so the caller escalates.
 */
export declare function resolveLocalTarget(targets: readonly LocalTarget[], request: LocalTargetRequest): ResolvedLocalTarget | undefined;
/**
 * Router candidates for every reachable local model, for callers that route
 * through `resolveRoster` rather than asking for one endpoint.
 *
 * A model's cold load becomes `startupSeconds` unless it is already warm, and
 * the host's in-flight count becomes `queueDepth`, so the existing score terms
 * price the swap and the single-GPU queue without a local-only rule.
 * @param targets - every published target record.
 * @param request - where the caller runs; its model/capability/context terms are ignored so every model is offered as a candidate.
 * @param provider - the provider id every returned candidate is tagged with.
 * @returns one routing candidate per reachable model, ranked the same way `rankLocalTargets` orders endpoints.
 */
export declare function localCandidates(targets: readonly LocalTarget[], request: LocalTargetRequest, provider?: string): Candidate[];
//# sourceMappingURL=local-targets.d.ts.map