/**
 * ANSI palette for the council report.
 *
 * Colour is a presentation concern only: every helper degrades to the identity
 * function when the sink cannot render escapes, so the same report code writes
 * a TTY, a redirected file, and a CI log without branching.
 */
/**
 * A seat identity. The four shipped seats have fixed colours; any additional
 * seat the user configures is also a valid id and is assigned a colour from
 * the rotation below.
 */
export type SeatId = string;
/** The shipped seats, whose colours are fixed by the council specification. */
export type BuiltinSeatId = 'claude' | 'openai' | 'kimi' | 'deepseek';
/** A painter that either wraps text in SGR codes or returns it unchanged. */
export interface Palette {
    /** True when escapes are being emitted. */
    readonly enabled: boolean;
    /** Paint text in one seat's colour. */
    seat(seat: SeatId, text: string): string;
    /** Paint a seat's name in its colour and bold. */
    seatName(seat: SeatId, text: string): string;
    /** Bold white, reserved for the collective answer. */
    headline(text: string): string;
    /** Dim, for separators and secondary labels. */
    muted(text: string): string;
    /** Red, for seat failures. */
    failure(text: string): string;
}
/** Inputs that decide whether escapes are safe to emit. */
export interface ColorSupportInput {
    /** Explicit opt-out, from `--no-color` or the tool argument. */
    readonly noColor?: boolean | undefined;
    /** Whether the sink is an interactive terminal. */
    readonly isTty?: boolean | undefined;
    /** Process environment, read for the NO_COLOR and FORCE_COLOR conventions. */
    readonly env?: Readonly<Record<string, string | undefined>> | undefined;
}
/**
 * Decide whether to emit ANSI escapes.
 *
 * Order matters: an explicit request beats the environment, `NO_COLOR` beats a
 * TTY (it exists precisely to override capability detection), and `FORCE_COLOR`
 * beats a non-TTY so piping into a pager still colours.
 * @param input - the explicit flag, TTY state, and environment.
 * @returns true when escapes should be written.
 */
export declare function supportsColor(input?: ColorSupportInput): boolean;
/**
 * Build a palette for the given capability decision.
 * @param enabled - whether escapes should be emitted.
 * @returns a painting palette, or the identity palette when disabled.
 */
export declare function createPalette(enabled: boolean): Palette;
/**
 * Build a palette by detecting support from the ambient process.
 * @param input - explicit flag, TTY state, and environment.
 * @returns a palette honouring the detection result.
 */
export declare function detectPalette(input?: ColorSupportInput): Palette;
//# sourceMappingURL=colors.d.ts.map