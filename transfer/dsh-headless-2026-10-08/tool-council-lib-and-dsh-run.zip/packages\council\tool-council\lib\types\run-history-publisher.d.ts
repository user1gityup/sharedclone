/**
 * Council run history, reachable from the pipeline panel.
 *
 * Run records live on the host in `$HOME/.dsh/council-runs`, and the panel is a
 * browser. The host gateway's RPC map is a closed, host-owned list that no
 * plugin can extend, and the host package must not depend on this plugin, so
 * the panel reaches the history through the council settings namespace, the
 * same route the CheaperInference budget Refresh already uses: the panel writes
 * one request field, this publisher applies it with runs.ts and writes the
 * answer and the refreshed list into one result field.
 *
 * Both fields are JSON strings because settings fields stay flat scalars. A
 * request carries a `seq` the panel raises on every press; the answer echoes
 * it, so the panel can tell its own answer from an older one. Nothing here
 * spends or approves: the request can only list, label, pin or delete records.
 */
import type { RunEdit, RunSummary } from './runs.ts';
/** The settings fields this surface reads and writes. */
export interface RunHistoryFields {
    /** The panel's request, as JSON: `{seq, op, id?, label?}`. */
    runHistoryRequest?: string | undefined;
    /** The host's answer, as JSON: {@link RunHistoryAnswer}. */
    runHistoryJson?: string | undefined;
}
/** Every operation a request may name. */
export declare const RUN_HISTORY_OPS: readonly ["list", "rename", "pin", "unpin", "delete"];
/** One of {@link RUN_HISTORY_OPS}. */
export type RunHistoryOp = typeof RUN_HISTORY_OPS[number];
/** A request after validation. */
export interface RunHistoryRequest {
    readonly seq: number;
    readonly op: RunHistoryOp;
    readonly id: string;
    readonly label: string;
}
/** What the host publishes in `runHistoryJson`. */
export interface RunHistoryAnswer {
    /** The `seq` of the request this answers; 0 for the boot listing. */
    readonly seq: number;
    readonly ok: boolean;
    readonly problem?: string | undefined;
    /** Every stored run, newest first, with queries cut to {@link QUERY_PREVIEW} characters. */
    readonly runs: readonly RunSummary[];
}
/**
 * How much of a run's query the settings document carries. The whole request
 * stays in the record; the panel only needs enough to recognise the run.
 */
export declare const QUERY_PREVIEW = 240;
/** The run-history operations, injected so tests need no filesystem. */
export interface RunHistoryStore {
    readonly list: () => readonly RunSummary[];
    readonly rename: (id: string, label: string) => RunEdit;
    readonly pin: (id: string, pinned: boolean) => RunEdit;
    /** May throw on a filesystem failure. */
    readonly remove: (id: string) => RunEdit;
}
/** Everything the publisher needs from the host. */
export interface RunHistoryHost {
    /** The current settings. */
    readonly live: () => RunHistoryFields;
    /** Publish a patch; rejections are treated as a read-only settings provider. */
    readonly update: (patch: RunHistoryFields) => Promise<void>;
    /** Observe settings changes. Returns an unwatch. */
    readonly watch?: ((listener: (next: RunHistoryFields) => void) => () => void) | undefined;
    readonly store: RunHistoryStore;
}
/**
 * Validate the panel's request field.
 * @param text - the stored JSON.
 * @returns the request, or a problem naming what is wrong with it; undefined when the field is empty.
 */
export declare function parseRunHistoryRequest(text: string | undefined): RunHistoryRequest | {
    readonly seq: number;
    readonly problem: string;
} | undefined;
/**
 * Apply one validated request.
 * @param store - the run-history operations.
 * @param request - the request.
 * @returns the edit outcome; a thrown filesystem error becomes a problem.
 */
export declare function applyRunHistoryRequest(store: RunHistoryStore, request: RunHistoryRequest): RunEdit;
/**
 * The answer as the settings field stores it.
 * @param store - the run-history operations, for the refreshed list.
 * @param seq - the request being answered.
 * @param edit - its outcome.
 * @returns the JSON text.
 */
export declare function runHistoryAnswer(store: RunHistoryStore, seq: number, edit: RunEdit): string;
/**
 * Publish the run history now, then answer every new request the panel writes.
 * @param host - settings access and the run-history operations.
 * @returns a disposer that stops watching.
 */
export declare function startRunHistoryPublisher(host: RunHistoryHost): () => void;
//# sourceMappingURL=run-history-publisher.d.ts.map