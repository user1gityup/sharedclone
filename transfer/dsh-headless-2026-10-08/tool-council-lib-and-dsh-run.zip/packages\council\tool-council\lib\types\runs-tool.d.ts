/**
 * The `runs` tool: one door through which a user, talking to any DSH agent,
 * manages what they have run and what they can run again.
 *
 * Two things answer to "a run" here, and the tool keeps them apart by action
 * name rather than guessing: a saved run (a preset, the button under **Saved
 * runs**) is text the user will press later, and a council run is a finished
 * record on disk. Presets reach settings through the same narrow write as
 * `save_pipeline_preset` — exactly `pipelinePresets`, never an approval slot —
 * and council runs are edited through runs.ts, which never rewrites a record.
 *
 * Deleting is the one action that cannot be undone, so it needs `confirm` and
 * says what it would remove when that is missing.
 */
import type { Context } from '@deepseek-ai/cordis';
import { type PresetEntry, type PresetMap } from './presets.ts';
/** Every action the tool takes. */
export declare const RUNS_ACTIONS: readonly ["list", "show", "save_preset", "update_preset", "duplicate_preset", "delete_preset", "save_current", "rename_run", "pin_run", "unpin_run", "delete_run"];
/** One of {@link RUNS_ACTIONS}. */
export type RunsAction = typeof RUNS_ACTIONS[number];
/** The in-flight pipeline, as far as saving it as a preset needs. */
export interface HeldPipeline {
    readonly query?: string | undefined;
    readonly stages?: string | undefined;
    readonly profile?: string | undefined;
    readonly auto?: boolean | undefined;
}
/** What the tool reads and writes, injected so it can be tested without a host. */
export interface RunsToolDeps {
    /** The presets settings hold now. */
    readonly presets: () => PresetMap;
    /** The pipeline settings hold now. */
    readonly pipeline: () => HeldPipeline;
    /** Persist a new preset map; false when there is nowhere to write it. */
    readonly writePresets: (next: PresetMap) => Promise<boolean>;
}
/** Arguments, as the tool schema delivers them. */
export interface RunsArgs {
    readonly action: RunsAction;
    readonly id?: string | undefined;
    readonly new_id?: string | undefined;
    readonly name?: string | undefined;
    readonly query?: string | undefined;
    readonly mode?: PresetEntry['mode'];
    readonly autoAdvance?: boolean | undefined;
    readonly stages?: string | undefined;
    readonly label?: string | undefined;
    readonly confirm?: boolean | undefined;
}
/** What every action reports. */
export interface RunsOutcome {
    readonly ok: boolean;
    readonly action: string;
    readonly report: string;
}
/**
 * Carry out one action.
 * @param args - the validated tool arguments.
 * @param deps - settings access.
 * @returns what happened, as a report the model shows the user.
 */
export declare function runRunsAction(args: RunsArgs, deps: RunsToolDeps): Promise<RunsOutcome>;
/**
 * Register the `runs` tool.
 * @param ctx - the plugin context.
 * @param deps - settings access.
 */
export declare function registerRunsTool(ctx: Context, deps: RunsToolDeps): void;
//# sourceMappingURL=runs-tool.d.ts.map