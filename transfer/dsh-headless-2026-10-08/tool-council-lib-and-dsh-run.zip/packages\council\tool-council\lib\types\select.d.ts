/**
 * The round that picks which seat's code is implemented.
 *
 * Four seats each wrote their own version of the same change into their own
 * tree. None of it has touched the real repository, and exactly one version
 * should. That choice is a vote, not a merge: taking the best parts of four
 * candidates would produce a fifth version nobody wrote and nobody reviewed.
 *
 * The vote reuses the council's existing machinery — `parseReview` and
 * `tally`, self-votes already discounted — because a vote on code is the same
 * shape as a vote on prose, and a second tallier would be a second set of
 * rules to keep in step with the first.
 *
 * The prompt is capped hard. Four candidates at their full size would be a
 * prompt no seat reads carefully and every metered seat charges for, so each
 * candidate is shown up to a fixed budget and the cut is stated. A voter that
 * cannot see all of a candidate is told so, rather than left to assume the
 * file simply ended.
 */
import type { SeatId } from './colors.ts';
import type { SeatConfig } from './seats.ts';
import type { SeatReview, Verdict } from './council.ts';
import type { FileSeam } from './files.ts';
import type { Candidate } from './writes.ts';
/** Characters shown from one candidate, across all of its files. */
export declare const CANDIDATE_CHARS = 12000;
/** What one selection round produced. */
export interface SelectionResult {
    /** Seat whose code won, or undefined when no vote settled it. */
    readonly winner?: SeatId | undefined;
    /** The winning candidate, when there is one. */
    readonly chosen?: Candidate | undefined;
    readonly reviews: readonly SeatReview[];
    readonly verdict: Verdict;
    /** Markdown for the main window. */
    readonly report: string;
}
/** Everything one selection round needs. */
export interface SelectionOptions {
    /** What the seats were asked to implement, in the user's own terms. */
    readonly task: string;
    /** One per seat that proposed code. */
    readonly candidates: readonly Candidate[];
    /** Every seat that may vote. */
    readonly seats: readonly SeatConfig[];
    /** Seam used to read candidate files back out of the seat trees. */
    readonly files: FileSeam;
    readonly apiKey?: string | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly timeoutMs: number;
    readonly sequential?: boolean | undefined;
    readonly memory?: {
        file?: string | undefined;
        text?: string | undefined;
    } | undefined;
}
/**
 * The prompt asking a seat to vote on which candidate is implemented.
 * @param task - what the seats were asked to implement.
 * @param rendered - each candidate, already rendered and capped.
 * @param ids - seat ids that may be voted for.
 * @returns the prompt.
 */
export declare function selectionPrompt(task: string, rendered: readonly string[], ids: readonly string[]): string;
/**
 * Run the vote that picks which candidate is implemented.
 * @param options - the candidates, the voters, and the transport settings.
 * @returns the winner, the votes, and a report.
 */
export declare function runSelection(options: SelectionOptions): Promise<SelectionResult>;
//# sourceMappingURL=select.d.ts.map