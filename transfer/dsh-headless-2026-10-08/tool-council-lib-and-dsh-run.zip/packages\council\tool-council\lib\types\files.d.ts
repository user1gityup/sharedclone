/**
 * Shared file evidence for the drafting round.
 *
 * An OpenRouter seat is a bare chat completion — no search, no fetch, no
 * filesystem. `evidence.ts` already solves that for the web: the seat says
 * what it wants looked up, a privileged route fulfils the request, and one
 * shared block goes to every seat. The seat never touches the network.
 *
 * This module is the same trade for local files. A seat names a path; it does
 * not get a filesystem handle, a directory listing, or a glob. The host reads
 * the file, and only inside roots the user configured. So a seat can ask for
 * `lib/auth.js` and be given it, and can ask for `~/.ssh/id_rsa` and be told
 * no, and the difference is decided here rather than by the seat's manners.
 *
 * Two caps matter more than they look. A file's content rides in every seat's
 * prompt for the rest of the run, so an unbounded read is not one expensive
 * call, it is a surcharge on all of them — hence the per-file and per-run
 * character limits, and hence truncation being marked rather than silent.
 */
/** Paths one seat may request. Bounds one seat from filling the round. */
export declare const MAX_READS_PER_SEAT = 3;
/** Files read per run, however many seats asked. */
export declare const MAX_READS_TOTAL = 8;
/** Characters kept from one file, before truncation is marked. */
export declare const MAX_FILE_CHARS = 6000;
/** Characters kept across the whole block, so the prompt cannot be flooded. */
export declare const MAX_TOTAL_CHARS = 40000;
/**
 * The subset of the filesystem this module needs, so tests need no disk.
 *
 * A seam takes a path already resolved and already checked against the roots.
 * Keeping the allowlist out here would put the security decision in whatever
 * the host happened to pass, which is exactly where it should not live.
 */
export interface FileSeam {
    read(path: string, signal?: AbortSignal): Promise<string>;
}
/** Retrieved file evidence, ready to paste into a prompt. */
export interface FileEvidence {
    /** Prompt-ready block, numbered so seats can cite by index. */
    readonly block: string;
    /** Paths included, in citation order, for later verification. */
    readonly paths: readonly string[];
    /** Requests that were refused, and why. Shown to the seats. */
    readonly refused: readonly string[];
}
/** One seat's requested paths. */
export interface SeatPaths {
    readonly seat: string;
    readonly paths: readonly string[];
}
/**
 * Split a configured root list into absolute roots.
 *
 * Roots arrive as one comma-separated string rather than an array because a
 * nested schemastery default materialises an empty object and fails its own
 * required fields before any code runs.
 * @param setting - the configured value, comma-separated.
 * @returns absolute roots, empty when nothing is configured.
 */
export declare function parseRoots(setting: string | undefined): readonly string[];
/**
 * Every directory a run may serve READ from.
 *
 * `fileRoots` is what the user typed, and it is not the whole story: a run
 * that may commit into a writer repository plainly may also read it, and a
 * host that configured three repositories and one root had seats asking for
 * files in the other two and being refused. Tool-less seats have no other way
 * in — someone else reads the file and hands them the text — so a repository
 * they can write but not read is a seat inventing the code it cannot see.
 *
 * The union is deduplicated on the resolved path and keeps `fileRoots` first,
 * so the prompt still lists the user's own root at the top.
 * @param setting - the raw `fileRoots` setting.
 * @param repoPaths - paths of the configured writer repositories.
 * @returns absolute roots, in order, without duplicates.
 */
export declare function readRoots(setting: string | undefined, repoPaths?: readonly string[]): readonly string[];
/**
 * The section of the research prompt that asks for files.
 *
 * Returns an empty string when no root is configured, so a host that has not
 * opted in never tells seats about a capability they do not have — a seat told
 * it may read files and then refused every time will start inventing content.
 * @param roots - absolute roots the seats may read inside.
 * @returns the prompt section, or an empty string.
 */
export declare function readRequestSection(roots: readonly string[]): string;
/**
 * Pull file requests out of a seat's reply.
 * @param text - the seat's reply.
 * @param max - most paths to accept from this seat.
 * @returns the requested paths, trimmed and deduplicated.
 */
export declare function parseReadRequests(text: string, max?: number): readonly string[];
/** Where a requested path landed. */
interface Resolved {
    /** Absolute path to read. */
    readonly path: string;
    /** Path as shown to seats, relative to its root. */
    readonly label: string;
}
/**
 * Resolve a requested path inside the configured roots.
 *
 * The check is on the resolved absolute path, not on the text of the request,
 * because `a/../../b` and `b` are the same file and only one of them looks
 * suspicious. A path that resolves outside every root is refused, and so is an
 * absolute path that happens to point outside — naming a root explicitly is
 * allowed, escaping one is not.
 * @param request - the path as the seat wrote it.
 * @param roots - absolute roots.
 * @returns the resolved path and its label, or undefined when out of bounds.
 */
export declare function resolveWithinRoots(request: string, roots: readonly string[]): Resolved | undefined;
/**
 * A seam backed by the real filesystem.
 * @returns a seam reading UTF-8 from disk.
 */
export declare function diskSeam(): FileSeam;
/**
 * Read every requested file the roots allow, and render one shared block.
 *
 * Refusals are reported rather than dropped. A seat whose request silently
 * vanished will assume the file was empty or that it was not listening; told
 * plainly that the path was outside the granted roots, it asks for a different
 * one or says what it could not check.
 * @param seam - the file seam, or undefined when reading is switched off.
 * @param roots - absolute roots the seats may read inside.
 * @param requests - what each seat asked for.
 * @param signal - cancellation from the run.
 * @returns the evidence, or undefined when nothing could be read.
 */
export declare function gatherFiles(seam: FileSeam | undefined, roots: readonly string[], requests: readonly SeatPaths[], signal?: AbortSignal): Promise<FileEvidence | undefined>;
export {};
//# sourceMappingURL=files.d.ts.map