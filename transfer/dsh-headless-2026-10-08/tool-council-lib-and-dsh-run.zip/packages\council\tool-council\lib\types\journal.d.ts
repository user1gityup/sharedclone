/**
 * Journal of seat answers, so an aborted run resumes instead of starting over.
 *
 * A pipeline saves its state only when a stage returns, and the standalone
 * council files its record only when the run finishes. A run cut off part way
 * — the host restarted, the window closed — used to lose every answer it had
 * already collected. Measured 2026-09-12: a council stage was killed by a host
 * restart fourteen minutes and two full rounds in, and the only way back was
 * to ask every seat everything again.
 *
 * So while a run is in flight, every successful seat answer is appended here
 * under the run's journal id, keyed by the seat's routing and the exact prompt.
 * When the run is entered again under the same id, a call whose prompt is
 * identical gets the recorded answer back without asking the seat. A later
 * round's prompt embeds the earlier answers, so as long as those came back from
 * the journal its prompts match too, and the resumed run walks through the work
 * already done for free and pays only for what was missing.
 *
 * Only answers are kept. An error or an empty reply is never recorded: those
 * are exactly the calls a resume should make again.
 *
 * Lines are appended one per answer, so a crash mid-write costs at most the
 * answer being written; a torn last line is skipped on load.
 */
import type { SeatConfig, SeatReply } from './seats.ts';
/** How many run journals are kept before the oldest are pruned. */
export declare const JOURNAL_HISTORY = 20;
/**
 * How long a recorded answer may be handed back. A resume happens within the
 * hour; a question asked again tomorrow deserves a fresh answer.
 */
export declare const JOURNAL_MAX_AGE_MS: number;
/** One run's journal, as loaded for the run in flight. */
export interface Journal {
    readonly runId: string;
    readonly path: string;
    readonly entries: Map<string, SeatReply>;
    /** Answers handed back from the journal during this call. */
    hits: number;
}
/**
 * Where run journals live.
 * @returns the absolute path of the journal directory under the user's home.
 */
export declare function journalDirectory(): string;
/**
 * A journal id for a run that has no id of its own until it finishes — the
 * standalone council, which a model re-calls with the same question after an
 * abort. The same question maps to the same journal.
 * @param question - the question the run answers.
 * @returns a 32-character hex id.
 */
export declare function journalIdFor(question: string): string;
/**
 * The key one call is recorded under.
 *
 * The routing is part of it: the same prompt re-aimed at a different model is
 * a different question. Shared memory is not — the digest is refreshed at every
 * host start, and a resume after a restart must still match.
 * @param seat - the seat asked.
 * @param prompt - the prompt, before any memory is added.
 * @returns a hex digest.
 */
export declare function journalKey(seat: SeatConfig, prompt: string): string;
/**
 * Load a run's journal, creating nothing until the first answer is recorded.
 * @param runId - the run's journal id.
 * @param directory - where journals live.
 * @param now - epoch ms, for the age limit.
 * @returns the journal, or undefined for an id that cannot name a file.
 */
export declare function openJournal(runId: string, directory?: string, now?: number): Journal | undefined;
/**
 * Run work with its journal in scope.
 * @param journal - the run's journal; undefined runs the work unjournalled.
 * @param work - the run.
 * @returns whatever the work returns.
 */
export declare function withJournal<T>(journal: Journal | undefined, work: () => Promise<T>): Promise<T>;
/**
 * The recorded answer to this exact call, when the run in scope has one.
 * @param seat - the seat about to be asked.
 * @param prompt - the prompt about to be sent.
 * @returns the answer, or undefined when the seat has to be asked.
 */
export declare function recallReply(seat: SeatConfig, prompt: string): SeatReply | undefined;
/**
 * Record an answer for the run in scope.
 *
 * Never throws: a seat that answered must not fail because its answer could
 * not be journalled. Usage is left out on purpose — a recalled answer costs
 * nothing, and carrying the original cost would bill it twice.
 * @param seat - the seat that answered.
 * @param prompt - the prompt it was sent.
 * @param reply - what came back.
 */
export declare function recordReply(seat: SeatConfig, prompt: string, reply: SeatReply): void;
/**
 * Delete a run's journal, once the run is finished or abandoned.
 * @param runId - the run's journal id.
 * @param directory - where journals live.
 */
export declare function discardJournal(runId: string, directory?: string): void;
/**
 * The line a report carries when answers came back from the journal.
 * @param journal - the journal the call ran with.
 * @returns the note, or '' when nothing was reused.
 */
export declare function resumedNote(journal: Journal | undefined): string;
//# sourceMappingURL=journal.d.ts.map