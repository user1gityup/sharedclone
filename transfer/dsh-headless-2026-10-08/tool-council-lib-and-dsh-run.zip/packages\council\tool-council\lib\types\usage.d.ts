/**
 * Local usage accounting for the CLI-backed seats.
 *
 * Neither Claude Code nor Codex exposes remaining quota programmatically —
 * `/usage` in print mode returns only that session's cost, and the JSON
 * envelope carries no rate-limit fields. What they do leave behind is a
 * per-message usage record in their session logs, so consumption is measurable
 * locally even though the provider's quota ceiling is not.
 *
 * Percentages therefore read against a budget the user sets, not against an
 * account limit this process can see. That distinction is deliberate: a
 * fabricated "83% of your Anthropic quota" would be worse than no number.
 */
/** Token counts folded over one window. */
export interface UsageTotals {
    /** Uncached prompt tokens. */
    readonly inputTokens: number;
    /** Completion tokens. */
    readonly outputTokens: number;
    /** Tokens served from cache. */
    readonly cacheReadTokens: number;
    /** Tokens written to cache. */
    readonly cacheWriteTokens: number;
    /** Assistant messages counted. */
    readonly messages: number;
    /** Per-model split, keyed by model id. */
    readonly byModel: ReadonlyMap<string, number>;
}
/**
 * Fold Claude Code's session logs over a time window.
 * @param sinceMs - epoch milliseconds; records older than this are ignored.
 * @param root - Claude Code project root; defaults to `~/.claude/projects`.
 * @returns token totals for the window.
 */
export declare function readClaudeUsage(sinceMs: number, root?: string): UsageTotals;
/**
 * Start of the current UTC day.
 * @param now - the instant to measure from, as epoch milliseconds (defaults to the current time).
 * @returns the epoch millisecond timestamp of that day's UTC midnight.
 */
export declare function startOfDay(now?: number): number;
/**
 * Start of the trailing seven-day window.
 * @param now - the instant to measure from, as epoch milliseconds (defaults to the current time).
 * @returns the epoch millisecond timestamp six days before that day's UTC midnight.
 */
export declare function startOfWeek(now?: number): number;
/** A consumption reading against a user-set allowance. */
export interface QuotaReading {
    /** Billable tokens counted in the window (input + output). */
    readonly tokens: number;
    /** The allowance this is measured against, when one is configured. */
    readonly budgetTokens?: number | undefined;
    /** Percentage of the allowance consumed, when one is configured. */
    readonly percent?: number | undefined;
}
/**
 * Express a window's consumption against a configured allowance.
 *
 * Cache reads are excluded because they are billed at a small fraction of the
 * uncached rate; counting them at parity would make a heavily-cached session
 * look far more expensive than it is.
 * @param totals - the folded window.
 * @param budgetTokens - the user's allowance for that window.
 * @returns tokens used and, when an allowance exists, the percentage.
 */
export declare function quotaReading(totals: UsageTotals, budgetTokens?: number | undefined): QuotaReading;
//# sourceMappingURL=usage.d.ts.map