/**
 * Reservation ledger for seats whose allowance is a number that runs down.
 *
 * A provider reports what a seat has left only after the fact: AWS billing
 * settles hours behind the spend, and Kiro's credit count moves once a task has
 * finished. Two dispatches that each read "5 left" and each spend 4 overspend
 * the seat, and on a seat backed by promotional credit the overspend lands on
 * real money. So a dispatch reserves its estimate here first, against the last
 * reading the provider gave, and holds it until the task commits what it
 * actually cost or releases the reservation unspent.
 *
 * The ledger is keyed by seat key — the seat and the account behind it — never
 * by machine: two DSH hosts on one AWS account draw on one allowance. Each
 * entry records the machine and session it came from so a report can say who
 * is holding what.
 *
 * What counts against a seat:
 * - a reservation, active or with its lease run out, for its full amount. An
 *   expired lease is not proof that nothing was spent — the task may have run
 *   and died before it could commit — so it keeps counting until a provider
 *   reading taken `settleLagMs` after the lease ended would already show it;
 * - a committed entry, for its actual cost, until a reading taken
 *   `settleLagMs` after the commit would show it;
 * - a released entry, for nothing.
 *
 * `reconcile` is the only step that drops entries: a fresh reading replaces the
 * snapshot, and whatever that reading already reflects is pruned from the list.
 * A seat with no reading refuses every reservation — guessing an allowance is
 * how the overspend this ledger exists to stop happens.
 *
 * Every change reads the whole ledger with its version, computes the next
 * state, and writes it back through the store's compare-and-swap; a lost race
 * re-reads and recomputes, a bounded number of times. The ledger is therefore
 * only as shared as its store: the local file store serialises the processes of
 * one host. DSH has no transport that can carry a compare-and-swap between
 * hosts (the shared brain syncs through git, which is eventual), so which host
 * holds the fleet's ledger is still to be decided.
 */
import type { LedgerStore } from './quota-ledger-store.ts';
/** The provider's last reading of what a seat has left. */
export interface LedgerSnapshot {
    /** Units left when the reading was taken. */
    readonly remaining: number;
    /** What the number counts — 'USD', 'credits', 'requests'. Every entry on the seat uses the same unit. */
    readonly unit: string;
    /** Epoch ms the reading describes. */
    readonly asOf: number;
}
/** What a dispatch asks to hold before it runs. */
export interface ReservationRequest {
    /** The unit of work the reservation pays for. */
    readonly taskId: string;
    /** The session that dispatched it. */
    readonly sessionId: string;
    /** The DSH host that dispatched it; recorded for the report, never part of the key. */
    readonly originMachineId: string;
    /** The estimate to hold, in the seat's unit. */
    readonly amount: number;
    /** The unit the estimate is in; refused unless it matches the seat's reading. */
    readonly unit: string;
    /** How long the reservation holds without a renew. */
    readonly leaseMs: number;
}
/** Fields every ledger entry carries, whatever its state. */
interface EntryFields {
    /** The reservation's own id, handed back by `reserve`. */
    readonly id: string;
    /** The unit of work the reservation pays for. */
    readonly taskId: string;
    /** The session that dispatched it. */
    readonly sessionId: string;
    /** The DSH host that dispatched it. */
    readonly originMachineId: string;
    /** The estimate held. */
    readonly amount: number;
    /** The unit of `amount`. */
    readonly unit: string;
    /** Epoch ms the reservation was granted. */
    readonly reservedAt: number;
    /** Epoch ms the lease ends unless renewed. */
    readonly leaseExpiresAt: number;
}
/** A reservation still waiting for its task to finish. */
export interface ReservedEntry extends EntryFields {
    /** The entry's state. */
    readonly state: 'reserved';
}
/** A reservation whose task reported what it actually cost. */
export interface CommittedEntry extends EntryFields {
    /** The entry's state. */
    readonly state: 'committed';
    /** What the task actually cost, in the seat's unit. */
    readonly actual: number;
    /** Epoch ms the cost was reported. */
    readonly committedAt: number;
}
/** A reservation given back unspent. */
export interface ReleasedEntry extends EntryFields {
    /** The entry's state. */
    readonly state: 'released';
    /** Epoch ms it was given back. */
    readonly releasedAt: number;
}
/** One reservation on a seat, in whichever state it has reached. */
export type LedgerEntry = ReservedEntry | CommittedEntry | ReleasedEntry;
/** Everything the ledger holds for one seat. */
export interface SeatLedger {
    /** The provider's last reading; a seat exists only once it has one. */
    readonly snapshot: LedgerSnapshot;
    /** Entries the reading does not reflect yet. */
    readonly entries: readonly LedgerEntry[];
}
/** Why the ledger refused a change. */
export type LedgerRefusal = 'no-snapshot' | 'unit-mismatch' | 'insufficient' | 'unknown-reservation' | 'not-reserved' | 'stale-snapshot';
/** What `reserve`, `renew`, `commit` and `release` report. */
export type EntryOutcome = {
    /** The change was made. */
    readonly ok: true;
    /** The entry as it now stands. */
    readonly entry: LedgerEntry;
    /** What the seat has left to reserve after the change. */
    readonly available: number;
} | {
    /** The change was refused and nothing was written. */
    readonly ok: false;
    /** Why it was refused. */
    readonly reason: LedgerRefusal;
    /** What the seat has left to reserve; undefined when it has no reading. */
    readonly available: number | undefined;
};
/** What `reconcile` reports. */
export type ReconcileOutcome = {
    /** The reading was taken. */
    readonly ok: true;
    /** Entries the reading already reflects, now dropped. */
    readonly pruned: number;
    /** What the seat has left to reserve under the new reading. */
    readonly available: number;
} | {
    /** The reading was refused and the old one kept. */
    readonly ok: false;
    /** Why it was refused. */
    readonly reason: LedgerRefusal;
    /** What the seat has left to reserve under the reading it kept. */
    readonly available: number;
};
/** How a ledger is set up. */
export interface QuotaLedgerOptions {
    /** Where the ledger's state lives and how it is swapped. */
    readonly store: LedgerStore;
    /** How long a provider takes to show a spend in its reading, in ms. */
    readonly settleLagMs: number;
    /** The clock; defaults to `Date.now`. */
    readonly now?: () => number;
    /** How many lost compare-and-swap races a change survives before it fails; defaults to 8. */
    readonly maxCasRetries?: number;
    /** Where reservation ids come from; defaults to `randomUUID`. */
    readonly newId?: () => string;
}
/** A reservation ledger over a store; see the module comment for what it counts. */
export declare class QuotaLedger {
    private readonly store;
    private readonly settleLagMs;
    private readonly now;
    private readonly maxCasRetries;
    private readonly newId;
    /**
     * @param options - the store, the settle lag, and optional clock, retry bound and id source.
     */
    constructor(options: QuotaLedgerOptions);
    /**
     * What a seat has left to reserve right now.
     * @param seatKey - the seat.
     * @returns the units left, or undefined when the seat has no reading.
     */
    available(seatKey: string): Promise<number | undefined>;
    /**
     * Hold an estimate against a seat before dispatching the task.
     * @param seatKey - the seat.
     * @param request - who is asking, how much, and for how long.
     * @returns the granted entry, or why it was refused.
     */
    reserve(seatKey: string, request: ReservationRequest): Promise<EntryOutcome>;
    /**
     * Extend a reservation whose task is still running. A lease that has run out
     * but not yet been pruned can be renewed: it never stopped counting.
     * @param seatKey - the seat.
     * @param id - the reservation.
     * @param leaseMs - how long from now it holds.
     * @returns the renewed entry, or why it was refused.
     */
    renew(seatKey: string, id: string, leaseMs: number): Promise<EntryOutcome>;
    /**
     * Record what a task actually cost. The actual may exceed the estimate; it
     * counts in full until a reading shows it.
     * @param seatKey - the seat.
     * @param id - the reservation.
     * @param actual - the cost, in the seat's unit.
     * @returns the committed entry, or why it was refused.
     */
    commit(seatKey: string, id: string, actual: number): Promise<EntryOutcome>;
    /**
     * Give a reservation back because its task never ran or spent nothing.
     * @param seatKey - the seat.
     * @param id - the reservation.
     * @returns the released entry, or why it was refused.
     */
    release(seatKey: string, id: string): Promise<EntryOutcome>;
    /**
     * Take a fresh provider reading and drop what it already reflects. A reading
     * older than the one held, or in a different unit, is refused.
     * @param seatKey - the seat.
     * @param snapshot - the reading.
     * @returns how many entries were pruned, or why the reading was refused.
     */
    reconcile(seatKey: string, snapshot: LedgerSnapshot): Promise<ReconcileOutcome>;
    /**
     * Move a reserved entry on, refusing anything else.
     * @param seatKey - the seat.
     * @param id - the reservation.
     * @param change - the entry it becomes.
     * @returns the changed entry, or why it was refused.
     */
    private settle;
    /**
     * Read, compute, compare-and-swap; on a lost race, again from a fresh read.
     * @param seatKey - the seat the change touches.
     * @param change - computes one attempt from the seat as read and the time.
     * @returns what the winning attempt reported.
     */
    private mutate;
}
export {};
//# sourceMappingURL=quota-ledger.d.ts.map