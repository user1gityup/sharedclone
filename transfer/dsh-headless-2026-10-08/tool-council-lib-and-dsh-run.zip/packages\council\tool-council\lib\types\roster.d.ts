/**
 * Who does what in a swarm.
 *
 * Two things decide an assignment, and they are not equally weighted. The
 * first is fit: a worker declared for `code` should get the code. The second,
 * and the reason this module exists at all, is cost — and cost has three
 * tiers, not two. A free worker spends nothing at all; a subscription worker
 * bills nothing but draws down a finite monthly quota; a metered worker bills
 * per token. Any tie therefore breaks toward the cheapest scarce resource,
 * which means free first and the subscription held in reserve.
 *
 * The user owns the roster. This module never invents a worker or silently
 * promotes a disabled one; if nothing is eligible it says so rather than
 * quietly falling back to whatever is cheapest to reach.
 */
import type { CostClass } from './execution-cost.ts';
import type { SubTask } from './decompose.ts';
import type { SeatConfig } from './seats.ts';
/** Kinds of work a unit can be, used only to match workers to units. */
export declare const workKinds: readonly ["code", "tests", "docs", "research", "review", "image", "any"];
/** One kind of work. */
export type WorkKind = (typeof workKinds)[number];
/** One configured worker in the swarm roster. */
export interface Worker {
    /**
     * Routing key this worker runs on: a council seat id for a seat-backed
     * roster, a subagent provider name for a provider-backed one.
     */
    readonly provider: string;
    /** Display name for the panel. */
    readonly name: string;
    /** Off workers are never assigned, whatever a decomposition suggests. */
    readonly enabled: boolean;
    /** How the worker bills. Subscription workers are preferred on ties. */
    readonly costClass: CostClass;
    /** Kinds this worker should be preferred for. `any` matches everything. */
    readonly kinds: readonly WorkKind[];
    /**
     * Units this worker may hold at once. Bounds a wide wave from stacking on
     * one subscription and exhausting its quota in a single run.
     */
    readonly maxConcurrent?: number | undefined;
}
/** A unit with the worker that will run it. */
export interface Assignment {
    readonly task: SubTask;
    /** Chosen provider, or undefined when no worker was eligible. */
    readonly provider?: string | undefined;
    /** Why this worker, in one phrase, for the panel. */
    readonly reason: string;
}
/** Result of assigning a whole decomposition. */
export interface AssignmentPlan {
    readonly assignments: readonly Assignment[];
    /** Units nobody could take. Non-empty means the roster cannot run this job. */
    readonly unassigned: readonly string[];
    /** Per-provider unit counts, for the panel. */
    readonly load: ReadonlyMap<string, number>;
}
/**
 * Guess the kind of work a unit is, from its own words.
 *
 * Deliberately shallow. A decomposition that wants precise routing should name
 * a provider outright; this only has to be good enough to prefer a code worker
 * for something that says "implement".
 * @param task - the unit.
 * @returns the inferred kind.
 */
export declare function inferKind(task: SubTask): WorkKind;
/**
 * Whether a declared set of kinds covers one kind of work.
 *
 * The single place the `any` rule lives. Every caller that used to spell
 * `kinds.includes('any') || kinds.includes(kind)` goes through this instead,
 * so an exclusive kind cannot be honoured in one router and ignored in the
 * next.
 * @param kinds - what the worker or seat declares it will take.
 * @param kind - the kind of work on offer.
 * @returns true when the work may go to it.
 */
export declare function takesKind(kinds: readonly string[], kind: WorkKind): boolean;
/**
 * A preference for one unit kind, earned by this run rather than configured.
 *
 * Kept separate from `Worker.kinds`: the roster's kinds are a user or
 * default setting that outlasts the run, while an earned preference is
 * evidence from THIS run — a plan vote, a code sample the user picked — and
 * applies only to it. Neither is an opinion this module holds about which
 * model is better at what.
 */
export interface EarnedPreference {
    /** Skip cost entirely when ranking candidates; fit and load decide alone. */
    readonly ignoreCost?: boolean | undefined;
    /** Kind to the provider that earned first refusal on it this run. */
    readonly specialists?: ReadonlyMap<WorkKind, string> | undefined;
}
/**
 * First refusal on every kind of work, for the agents the user chose.
 *
 * Walked per kind rather than handed out wholesale: an agent the user kept for
 * its layout is still the wrong place to send an image unit it does not take,
 * and a specialist entry naming a worker that would refuse the kind sends the
 * unit nowhere. The first chosen agent that accepts a kind takes it, so the
 * order the user kept them in decides ties — they were asked, and nothing else
 * in the run knows better.
 * @param chosen - provider ids the user kept, strongest first.
 * @param roster - configured workers.
 * @returns kind to provider, empty when no chosen agent is enabled.
 */
export declare function chosenSpecialists(chosen: readonly string[], roster: readonly Worker[]): ReadonlyMap<WorkKind, string>;
/**
 * Assign every unit of a decomposition to a worker.
 *
 * Order of preference, strongest first:
 *  1. A provider the decomposition named explicitly, if that worker is enabled.
 *  2. The provider that earned this kind this run (`earned.specialists`), if
 *     it accepts the kind and has room.
 *  3. A worker declaring this kind of work, cheapest cost class first unless
 *     `earned.ignoreCost` is set.
 *  4. Any enabled worker accepting `any`, ranked the same way.
 *
 * Within a cost class (or, with cost ignored, across the whole tier), the
 * least-loaded worker wins, so one subscription is not drained while another
 * sits idle.
 * @param tasks - the decomposition.
 * @param roster - configured workers.
 * @param earned - this run's own signals for preferring a worker, if any.
 * @returns the assignment plan.
 */
export declare function assignWorkers(tasks: readonly SubTask[], roster: readonly Worker[], earned?: EarnedPreference): AssignmentPlan;
/**
 * Default roster for a fresh install.
 *
 * Subscription workers first and doing the code, which is the whole point:
 * the seats already paid for should carry the load, and metered providers
 * should pick up what is left rather than lead.
 * @param available - provider names actually registered on this host.
 * @returns a roster covering only providers that exist.
 */
export declare function defaultRoster(available: readonly string[]): readonly Worker[];
/**
 * The swarm roster built from the council's own seats.
 *
 * The workers a swarm may use ARE the seats the user configured. There is no
 * second registry to keep in step and no worker that exists only in the swarm:
 * re-point a seat's model, add an OpenRouter seat, switch one off, and the
 * swarm sees exactly that. `swarmRoster` overrides then say which of those
 * seats may take work and which kinds, without touching whether the seat sits
 * on the council — wanting a model to debate is not the same as wanting it to
 * carry a unit.
 *
 * A seat declaring itself free counts as `free` and wins ties outright; a CLI
 * seat bills a subscription already paid for, so it counts as `included` and
 * is held in reserve behind the free seats; an OpenRouter seat is metered and
 * picks up what is left.
 * @param seats - every configured seat, shipped and user-added.
 * @param overrides - per-seat swarm state, keyed by seat id.
 * @returns the roster, in seat order.
 */
export declare function seatRoster(seats: readonly SeatConfig[], overrides?: Readonly<Record<string, {
    enabled?: boolean | undefined;
    kinds?: readonly string[] | undefined;
}>>): readonly Worker[];
//# sourceMappingURL=roster.d.ts.map