/**
 * Turning a council decision into an executable task graph.
 *
 * The council settles *what to do*; a swarm needs *who does which part, in
 * what order*. That translation is its own step, deliberately separate from
 * both: the council's output is prose, and the team's task board wants named
 * units with dependencies. Nothing may execute straight off a winning draft.
 *
 * Two modes, chosen per run rather than configured once, because the right
 * one depends on the job:
 *
 *  - `single` — one seat parses the agreed answer. Cheap, and usually enough,
 *    since the council has already agreed the approach.
 *  - `council` — every seat proposes a decomposition and they vote. Costs a
 *    full extra round; worth it when the split itself is the hard part.
 */
/** One unit of parallelisable work. */
export interface SubTask {
    /** Stable lower-kebab-case identifier, referenced by dependants. */
    readonly id: string;
    /** One-line statement of the unit. */
    readonly title: string;
    /** Everything a teammate needs to do it without further context. */
    readonly detail: string;
    /** Ids that must finish first. Empty means it can start immediately. */
    readonly dependsOn: readonly string[];
    /** Subagent provider suggested for this unit, when one is a better fit. */
    readonly provider?: string | undefined;
    readonly tier?: 'ui' | 'general' | undefined;
    readonly acceptance?: readonly string[] | undefined;
    readonly files?: readonly string[] | undefined;
}
/** How the decomposition is produced. */
export type DecomposeMode = 'single' | 'council';
/** A parsed decomposition and anything wrong with it. */
export interface Decomposition {
    readonly tasks: readonly SubTask[];
    /** Problems that make the graph unsafe to execute. Empty means usable. */
    readonly problems: readonly string[];
}
/**
 * Prompt asking for a decomposition of an already-agreed answer.
 * @param query - the original question.
 * @param answer - the answer the council settled on.
 * @param providers - provider names a teammate may run on.
 * @returns the prompt.
 */
export declare function decomposePrompt(query: string, answer: string, providers: readonly string[]): string;
/**
 * Prompt asking for a decomposition of a request no council has discussed.
 *
 * The council path decomposes an answer the seats already agreed on. This one
 * has no such answer: the user asked for work directly and wants it split and
 * run. The split therefore has to be read out of the request itself, which is
 * why the prompt says so rather than leaving the model to infer an approach
 * and quietly decompose something nobody asked for.
 * @param query - what the user asked for.
 * @param providers - worker names a unit may name.
 * @param profile - the swarm profile a unit's contest style targets, when the split feeds a swarm run.
 * @returns the prompt.
 */
export declare function directDecomposePrompt(query: string, providers: readonly string[], profile?: 'economy' | 'fastest'): string;
/**
 * Check a task graph for the faults that make it unsafe to run.
 *
 * Reported rather than thrown: a partly-wrong decomposition is worth showing
 * to the user alongside what is wrong with it, so they can reject it knowingly
 * instead of watching a swarm deadlock.
 * @param tasks - the parsed units.
 * @param profile - the swarm profile whose extra requirements to enforce (economy demands acceptance conditions); omitted skips them.
 * @returns human-readable problems; empty when the graph is executable.
 */
export declare function validateGraph(tasks: readonly SubTask[], profile?: 'economy' | 'fastest'): readonly string[];
/**
 * Parse a decomposition reply into a validated task graph.
 * @param text - the model's reply.
 * @returns the tasks and any problems found.
 */
export declare function parseDecomposition(text: string): Decomposition;
/**
 * Group units into waves that may run concurrently.
 * @param tasks - a validated task graph.
 * @returns waves, each safe to run in parallel, in execution order.
 */
export declare function executionWaves(tasks: readonly SubTask[]): readonly (readonly SubTask[])[];
//# sourceMappingURL=decompose.d.ts.map