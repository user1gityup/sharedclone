/**
 * Console report rendering.
 *
 * The renderer takes a palette rather than deciding colour itself, so the same
 * function produces the coloured terminal view and the plain text handed back
 * to the model as the tool result.
 */
import type { Palette } from './colors.ts';
import type { CouncilResult } from './council.ts';
/**
 * Render a full council report.
 * @param result - the completed run.
 * @param palette - painter deciding whether escapes are emitted.
 * @returns the report as a single string, newline separated.
 */
export declare function renderReport(result: CouncilResult, palette: Palette): string;
//# sourceMappingURL=report.d.ts.map