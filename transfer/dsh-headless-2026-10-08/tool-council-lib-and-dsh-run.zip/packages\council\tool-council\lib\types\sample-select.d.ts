/**
 * The one-at-a-time selection round: the user, not a vote, picks the winners.
 *
 * The proposing round already has a selection in it, and that selection is a
 * council vote — every seat reads every candidate and argues for one. That is
 * the right answer when the question is "which of these is correct", and the
 * wrong one when the question is "which of these do I want", because taste is
 * not a thing a seat can be asked about on the user's behalf. A vote that
 * overrides the user is worse than no selection at all: it spends a call per
 * seat to produce an answer that has to be thrown away the moment the user
 * disagrees with it.
 *
 * So this module holds no opinion about which sample is better. It decides one
 * thing only: which sample the user has not seen yet. The stage shows that one,
 * on its own, and stops at its own gate; the user's verdict comes back as
 * settings and lands here as a record; the stage runs again and shows the next.
 * When none are left the round is over and the winners — plural, because the
 * user may keep several — travel on to the building swarm.
 *
 * Two things are recorded per sample, not one. **Which agents won** is what
 * routes the production work, and **what the user picked out of each** is what
 * the production work is actually built from: a user who says "this one, but
 * only its sidebar" has said something a bare winner list cannot carry, and
 * losing it means the build re-invents a decision that was already made.
 *
 * Nothing here spends, reads a file, or calls a seat. Presenting a sample is
 * assembling text from a candidate that was written in an earlier stage, which
 * is why the round can be walked, re-walked and revised for free.
 */
/** What the user said about one sample. */
export type SampleVerdict = 
/** Keep it: its agent is a winner, and `elements` says what was taken. */
'won'
/** Not this one. Its agent does not route production work. */
 | 'passed';
/** One sample's decision, as it survives between calls. */
export interface SampleSelection {
    /** Seat whose sample this was. */
    readonly seat: string;
    readonly verdict: SampleVerdict;
    /**
     * What the user wanted out of this sample, in their own words.
     *
     * Empty means "all of it" on a win, and nothing on a pass. Kept verbatim
     * rather than parsed into structure: the phrase the user typed is the
     * instruction the production swarm should read, and any schema this module
     * imposed on it would be this module deciding what counts as an element.
     */
    readonly elements: string;
    /** Epoch ms the verdict was recorded. */
    readonly at: number;
}
/** The sample about to be shown, and where it sits in the round. */
export interface SamplePosition {
    readonly seat: string;
    /** 0-based index into the candidate list. */
    readonly index: number;
    readonly total: number;
}
/** Just enough of a candidate to present it; the files stay on disk. */
export interface SampleCandidate {
    readonly seat: string;
    /** Absolute root the seat's files were written under. */
    readonly root: string;
    /** How many files it wrote. */
    readonly files: number;
}
/**
 * Read selections stored as JSON text, tolerating anything that is not a list.
 *
 * A settings field can hold an empty string, a value written by an older
 * build, or something a hand edit broke. None of those should end a run: a
 * round whose record cannot be read starts again from the first sample, which
 * costs nothing but the user's time, while a throw would lose the samples too.
 * @param text - the stored JSON, or an empty string.
 * @returns the selections that parsed, oldest first.
 */
export declare function readSelections(text: string | undefined): readonly SampleSelection[];
/**
 * Record one verdict, replacing any earlier verdict for the same seat.
 *
 * Replacing rather than appending is what makes a decision revisable: a user
 * who goes back to a sample they passed on and keeps it should end with one
 * record saying they kept it, not two records disagreeing. The position in the
 * list is kept so the round still reads in the order the samples were shown.
 * @param selections - what has been decided so far.
 * @param selection - the new verdict.
 * @returns the updated list.
 */
export declare function recordSelection(selections: readonly SampleSelection[], selection: SampleSelection): readonly SampleSelection[];
/**
 * The next sample the user has not ruled on, in candidate order.
 * @param candidates - every sample the swarm produced.
 * @param selections - verdicts so far.
 * @returns the position, or undefined when the round is over.
 */
export declare function nextSample(candidates: readonly SampleCandidate[], selections: readonly SampleSelection[]): SamplePosition | undefined;
/**
 * The seats the user kept, in the order they were shown.
 * @param selections - verdicts so far.
 * @returns the winning seat ids.
 */
export declare function winners(selections: readonly SampleSelection[]): readonly string[];
/**
 * One sample, presented on its own.
 *
 * Deliberately one sample and not a table of all of them: a user shown four
 * samples at once compares them, and comparing is the thing this round exists
 * to avoid — it pushes them toward the sample that is easiest to skim rather
 * than the one they want. The agent is named because the user is choosing who
 * builds as much as what gets built.
 * @param candidate - the sample to show.
 * @param position - where it sits in the round.
 * @returns markdown for the main window.
 */
export declare function renderSample(candidate: SampleCandidate, position: SamplePosition): string;
/**
 * The round's closing summary, once every sample has a verdict.
 * @param candidates - every sample the swarm produced.
 * @param selections - the verdicts.
 * @returns markdown for the main window.
 */
export declare function renderSelections(candidates: readonly SampleCandidate[], selections: readonly SampleSelection[]): string;
/**
 * The selections as the building swarm is told about them.
 *
 * Written as instructions rather than as data because the swarm's planner is a
 * model reading a query, and a model handed a JSON blob of verdicts tends to
 * summarise it back rather than build from it. The wording refuses the two
 * failure modes seen in the proposing chain: starting over from scratch, and
 * quietly folding in a version the user passed on.
 * @param candidates - every sample the swarm produced.
 * @param selections - the verdicts.
 * @returns a prompt section, or an empty string when nothing was kept.
 */
export declare function selectionBrief(candidates: readonly SampleCandidate[], selections: readonly SampleSelection[]): string;
//# sourceMappingURL=sample-select.d.ts.map